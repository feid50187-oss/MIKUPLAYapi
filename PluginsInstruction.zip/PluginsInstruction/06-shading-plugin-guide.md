# 着色插件开发指南

着色插件（`type: 'functional'`, `target: 'shading'`）通过提供材质适配器（MaterialAdapter）来扩展着色系统的材质类型支持，允许注册新的材质风格（如 PBR），使着色面板能动态适配不同材质类型的参数编辑。

---

## 一、着色插件概述

### 1.1 工作原理

着色插件的核心是 `IMaterialAdapter` 接口实现。每个适配器负责一种材质类型的参数读写、控件声明和材质转换。宿主在加载着色插件时，会自动将适配器注册到 `materialAdapterRegistry`，着色面板据此动态生成参数编辑 UI 和渲染风格选择器。

**明确约束**：材质插件不支持轮廓线（outline）和材质变形（morph），接受对着色 Panel 及相关模块的调整代价。

### 1.2 两种适配器模式

| 模式 | `createsMaterial` | 行为 | 风格选择器 |
|------|-------------------|------|-----------|
| **参数编辑型** | `false` | 仅提供参数编辑能力，不替换材质 | 不显示 |
| **材质创建型** | `true` | 创建新材质替换原始 `MmdStandardMaterial` | 显示 |

- **参数编辑型**适配器仅扩展参数编辑能力，着色面板行为不变
- **材质创建型**适配器会在着色面板顶部显示"渲染风格"下拉选择器，用户可在"MMD 标准"和注册的材质风格之间切换

### 1.2.1 内置适配器一览

`BuiltinPluginRegistrar.registerBuiltinShadings()` 注册 3 个内置着色适配器：

| 内置 ID | 适配器类 | `typeId` | `displayName` | `createsMaterial` | `supportsOutline` | `supportsMorph` |
|---------|---------|----------|---------------|-------------------|-------------------|-----------------|
| `builtin.shading.mmd-standard` | `MmdStandardMaterialAdapter` | `mmd-standard` | `'MMD 标准'` | `false` | `true` | `true` |
| `builtin.shading.pbr` | `PbrMaterialAdapter` | `pbr-advanced` | `'PBR材质'` | `true` | `false` | `false` |
| `builtin.shading.toon` | `ToonShadingMaterialAdapter` | `toon-shading` | `'Toon卡通(Dev)'` | `true` | `true` | `true` |

> 注意：文档与代码中所有 `typeId` / `displayName` / `supportsXxx` 属性均以 `BuiltinPluginRegistrar.ts` 注册版本为准；早期文档中 Toon 的 `displayName` 写作 `'Toon 卡通'`、`supportsMorph=false`，实际代码为 `displayName='Toon卡通(Dev)'`、`supportsMorph=true`。

**ToonShadingMaterialAdapter 独有特性**：
- 使用自定义 GLSL 实现 `ShaderMaterial`，集成自阴影接收（与项目 `ShadowGenerator` 协同，编译期 `TOON_SHADOW_DEPTH` / `TOON_SHADOW_CLOSEESM` define，按 `filteringQuality` 切换 PCF1/PCF3/PCF5 三档多 tap）
- 边缘光参数（`rimLightWidth` / `rimLightIntensity`，共享全局 `ToonShadingSharedParams`，所有 toon 材质同时生效）
- 共享风格参数：`rimLightWidth` / `rimLightIntensity` / `ambient` / `unlit`，通过 `ToonShadingSharedParams` 全局单例同步
- 每材质变体贴图：`normalMap`（每材质作用域，空串回退白色兜底；切换风格时通过 `disposeMaterial` 释放）

### 1.3 与地面/粒子插件的区别

| 特性 | 地面/粒子插件 | 着色插件 |
|------|-------------|---------|
| 导出接口 | `FunctionalPluginExports` | `ShadingPluginExports` |
| 核心导出 | `preset` + `createInstance` | `adapter` |
| 控件声明位置 | `preset.controls` | `adapter.getControlDeclarations()` |
| 参数默认值 | `preset.defaultParams` | `adapter.getDefaultState()` |
| 宿主集成 | 下拉框选择 | 风格选择器 + 动态参数面板 |

---

## 二、材质适配器接口 (IMaterialAdapter)

### 2.1 接口定义

```typescript
interface IMaterialAdapter {
    readonly typeId: string;              // 适配器唯一标识
    readonly displayName: string;         // 显示名称
    readonly supportsOutline: boolean;    // 是否支持轮廓线
    readonly supportsMorph: boolean;      // 是否支持材质变形
    readonly createsMaterial: boolean;    // 是否需要创建新材质替换原始材质

    canHandle(material: Material): boolean;
    readState(material: Material): Record<string, ParamValue>;
    writeState(material: Material, state: Record<string, ParamValue>): void;
    getControlDeclarations(): ControlDeclaration[];
    getDefaultState(): Record<string, ParamValue>;
    convertFromMmd?(mmdMaterial: Material, scene: Scene, textureMap?: Map<string, Texture>): Material;
    convertToMmd?(material: Material, scene: Scene): Material;
    disposeMaterial(material: Material): void;
}
```

完整接口说明详见 [02-api-reference.md](02-api-reference.md) 第六章。

### 2.2 ParamValue 类型

适配器读写的参数值类型：

```typescript
type ParamValue = number | string | boolean | { r: number; g: number; b: number } | number[];
```

| 值类型 | 对应控件 | 示例 |
|--------|---------|------|
| `number` | slider | `alpha: 0.8` |
| `string` | dropdown | `alphaBlendMode: 'alphaBlend'` |
| `boolean` | toggle | `isVisible: true` |
| `{ r, g, b }` | color | `diffuse: { r: 1, g: 0.5, b: 0.3 }` |
| `number[]` | vector | `position: [0, 1, 2]` |

### 2.3 属性详解

| 属性 | 说明 |
|------|------|
| `typeId` | 适配器唯一标识，全局唯一。用于风格选择器、状态管理中的 `adapterTypeId`。建议使用简短标识如 `'pbr'`、`'toon'` |
| `displayName` | 用户可见的显示名称，出现在风格选择器下拉框中 |
| `supportsOutline` | 设为 `false` 时，切换到该风格后着色面板的描边宽度控件会隐藏 |
| `supportsMorph` | 设为 `false` 时，切换到该风格后 VMD 材质变形动画将停止生效 |
| `createsMaterial` | `true` 时着色面板显示"渲染风格"选择器；`false` 时仅扩展参数编辑能力 |

### 2.4 方法详解

#### canHandle(material)

判定给定材质是否由该适配器处理。通常使用 `instanceof` 检查：

```javascript
MyAdapter.prototype.canHandle = function(material) {
    return material instanceof BABYLON.PBRMaterial;
};
```

#### readState(material)

从材质实例读取参数状态，返回键值对。键名需与 `getControlDeclarations()` 中的 `param` 字段对应：

```javascript
MyAdapter.prototype.readState = function(material) {
    return {
        albedoColor: { r: material.albedoColor.r, g: material.albedoColor.g, b: material.albedoColor.b },
        metallic: material.metallic,
        roughness: material.roughness,
        alpha: material.alpha
    };
};
```

#### writeState(material, state)

将参数状态写入材质实例。注意对颜色类型需要创建 `BABYLON.Color3` 实例：

```javascript
MyAdapter.prototype.writeState = function(material, state) {
    if (state.albedoColor) {
        material.albedoColor = new BABYLON.Color3(
            state.albedoColor.r, state.albedoColor.g, state.albedoColor.b
        );
    }
    if (state.metallic !== undefined) material.metallic = state.metallic;
    if (state.roughness !== undefined) material.roughness = state.roughness;
    if (state.alpha !== undefined) material.alpha = state.alpha;
};
```

#### getControlDeclarations()

声明该材质类型的参数控件。宿主据此动态生成 UI。支持 `group` 字段将多个控件合并到一个分组容器中：

```javascript
MyAdapter.prototype.getControlDeclarations = function() {
    return [
        { param: 'albedoColor', type: 'color', label: '基色', group: '基色' },
        { param: 'metallic', type: 'slider', label: '金属度', min: 0, max: 1, step: 0.01, group: '基色' },
        { param: 'roughness', type: 'slider', label: '粗糙度', min: 0, max: 1, step: 0.01, group: '基色' },
        { param: 'alpha', type: 'slider', label: 'Alpha', min: 0, max: 1, step: 0.01 },
        { param: 'emissiveColor', type: 'color', label: '自发光色' },
        { param: 'emissiveIntensity', type: 'slider', label: '自发光强度', min: 0, max: 10, step: 0.1 }
    ];
};
```

控件类型包括：`slider`、`color`、`vector`、`dropdown`、`toggle`。详见 [02-api-reference.md](02-api-reference.md) 第十章。

#### getDefaultState()

获取参数默认值，用于初始化新材质的状态：

```javascript
MyAdapter.prototype.getDefaultState = function() {
    return {
        albedoColor: { r: 0.8, g: 0.8, b: 0.8 },
        metallic: 0.0,
        roughness: 0.5,
        alpha: 1,
        emissiveColor: { r: 0, g: 0, b: 0 },
        emissiveIntensity: 0
    };
};
```

#### convertFromMmd(mmdMaterial, scene, textureMap?)（可选）

将 `MmdStandardMaterial` 转换为该适配器的材质类型。`createsMaterial=true` 时建议实现，否则用户无法从 MMD 标准风格切换到该风格：

```javascript
MyAdapter.prototype.convertFromMmd = function(mmdMaterial, scene) {
    var newMat = new BABYLON.PBRMaterial(mmdMaterial.name + '_pbr', scene);

    // 迁移基础颜色
    if (mmdMaterial.diffuseTexture) {
        newMat.albedoTexture = mmdMaterial.diffuseTexture;
    }
    newMat.albedoColor = mmdMaterial.diffuseColor.clone();

    // 迁移透明度
    newMat.alpha = mmdMaterial.alpha;
    if (mmdMaterial.alpha < 1) {
        newMat.transparencyMode = BABYLON.PBRMaterial.PBRMATERIAL_ALPHABLEND;
    }

    // 迁移双面
    newMat.backFaceCulling = mmdMaterial.backFaceCulling;

    // 设置默认值
    newMat.metallic = 0.0;
    newMat.roughness = 0.8;

    return newMat;
};
```

#### disposeMaterial(material)

释放该适配器创建的材质资源：

```javascript
MyAdapter.prototype.disposeMaterial = function(material) {
    material.dispose();
};
```

---

## 三、着色插件导出接口

着色插件使用 `ShadingPluginExports` 导出接口，核心是提供 `adapter` 实例：

```javascript
exports.adapter = new MyAdapter();

// 可选的生命周期方法
exports.onActivate = function(ctx) { /* 插件激活时调用 */ };
exports.onDeactivate = function(ctx) { /* 插件停用时调用 */ };
exports.dispose = function() { /* 释放资源 */ };
```

**关键点**：
- 着色插件**不使用** `preset` 和 `createInstance`，而是通过 `adapter` 提供材质适配器
- 宿主在加载着色插件时会自动将 `adapter` 注册到 `materialAdapterRegistry`
- 宿主在卸载着色插件时会自动从 `materialAdapterRegistry` 注销适配器

---

## 四、完整示例：PBR 着色插件

### 4.1 manifest.json

```json
{
    "id": "com.example.shading-pbr",
    "name": "PBR 材质",
    "version": "1.0.0",
    "type": "functional",
    "target": "shading",
    "author": "Example Author",
    "description": "基于物理的渲染材质风格"
}
```

### 4.2 index.js

```javascript
/**
 * PBR Shading Plugin - PBR着色插件
 *
 * 功能：提供基于物理的渲染材质风格，
 *       用户可在着色面板的"渲染风格"选择器中切换到 PBR 材质
 */

var exports = {};

(function() {

    // ========== PBR 适配器 ==========
    var PBRAdapter = function() {
        this.typeId = 'pbr';
        this.displayName = 'PBR 材质';
        this.supportsOutline = false;    // PBR 不支持轮廓线
        this.supportsMorph = false;      // PBR 不支持材质变形
        this.createsMaterial = true;     // 需要创建新材质替换 MMD 材质
    };

    // 判定材质是否由该适配器处理
    PBRAdapter.prototype.canHandle = function(material) {
        return material instanceof BABYLON.PBRMaterial;
    };

    // 从材质读取参数状态
    PBRAdapter.prototype.readState = function(material) {
        return {
            albedoColor: {
                r: material.albedoColor.r,
                g: material.albedoColor.g,
                b: material.albedoColor.b
            },
            metallic: material.metallic,
            roughness: material.roughness,
            alpha: material.alpha,
            emissiveColor: {
                r: material.emissiveColor.r,
                g: material.emissiveColor.g,
                b: material.emissiveColor.b
            },
            emissiveIntensity: material.emissiveIntensity,
            environmentIntensity: material.environmentIntensity
        };
    };

    // 将参数状态写入材质
    PBRAdapter.prototype.writeState = function(material, state) {
        if (state.albedoColor) {
            material.albedoColor = new BABYLON.Color3(
                state.albedoColor.r, state.albedoColor.g, state.albedoColor.b
            );
        }
        if (state.metallic !== undefined) material.metallic = state.metallic;
        if (state.roughness !== undefined) material.roughness = state.roughness;
        if (state.alpha !== undefined) material.alpha = state.alpha;
        if (state.emissiveColor) {
            material.emissiveColor = new BABYLON.Color3(
                state.emissiveColor.r, state.emissiveColor.g, state.emissiveColor.b
            );
        }
        if (state.emissiveIntensity !== undefined) {
            material.emissiveIntensity = state.emissiveIntensity;
        }
        if (state.environmentIntensity !== undefined) {
            material.environmentIntensity = state.environmentIntensity;
        }
    };

    // 声明参数控件
    PBRAdapter.prototype.getControlDeclarations = function() {
        return [
            { param: 'albedoColor', type: 'color', label: '基色', group: '基色' },
            { param: 'metallic', type: 'slider', label: '金属度', min: 0, max: 1, step: 0.01, group: '基色' },
            { param: 'roughness', type: 'slider', label: '粗糙度', min: 0, max: 1, step: 0.01, group: '基色' },
            { param: 'alpha', type: 'slider', label: 'Alpha', min: 0, max: 1, step: 0.01 },
            { param: 'emissiveColor', type: 'color', label: '自发光色' },
            { param: 'emissiveIntensity', type: 'slider', label: '自发光强度', min: 0, max: 10, step: 0.1 },
            { param: 'environmentIntensity', type: 'slider', label: '环境光强度', min: 0, max: 2, step: 0.01 }
        ];
    };

    // 获取参数默认值
    PBRAdapter.prototype.getDefaultState = function() {
        return {
            albedoColor: { r: 0.8, g: 0.8, b: 0.8 },
            metallic: 0.0,
            roughness: 0.5,
            alpha: 1,
            emissiveColor: { r: 0, g: 0, b: 0 },
            emissiveIntensity: 0,
            environmentIntensity: 1
        };
    };

    // 将 MMD 标准材质转换为 PBR 材质
    PBRAdapter.prototype.convertFromMmd = function(mmdMaterial, scene) {
        var pbr = new BABYLON.PBRMaterial(mmdMaterial.name + '_pbr', scene);

        // 迁移基础颜色
        if (mmdMaterial.diffuseTexture) {
            pbr.albedoTexture = mmdMaterial.diffuseTexture;
        }
        pbr.albedoColor = mmdMaterial.diffuseColor.clone();

        // 迁移自发光
        if (mmdMaterial.emissiveTexture) {
            pbr.emissiveTexture = mmdMaterial.emissiveTexture;
        }
        pbr.emissiveColor = mmdMaterial.emissiveColor.clone();

        // 迁移透明度
        pbr.alpha = mmdMaterial.alpha;
        if (mmdMaterial.alpha < 1) {
            pbr.transparencyMode = BABYLON.PBRMaterial.PBRMATERIAL_ALPHABLEND;
        }

        // 迁移双面
        pbr.backFaceCulling = mmdMaterial.backFaceCulling;
        pbr.twoSidedLighting = mmdMaterial.twoSidedLighting;

        // PBR 默认值
        pbr.metallic = 0.0;
        pbr.roughness = 0.8;

        return pbr;
    };

    // 释放材质资源
    PBRAdapter.prototype.disposeMaterial = function(material) {
        material.dispose();
    };

    // ========== 导出 ==========
    exports.adapter = new PBRAdapter();

})();
```

---

## 五、着色插件模板

### manifest.json

```json
{
    "id": "com.author.shading-name",
    "name": "材质名称",
    "version": "1.0.0",
    "type": "functional",
    "target": "shading",
    "author": "作者名",
    "description": "着色插件描述"
}
```

### index.js

```javascript
/**
 * 着色插件模板
 */

var exports = {};

(function() {

    // ========== 材质适配器 ==========
    var MyAdapter = function() {
        this.typeId = 'my-material';         // 全局唯一标识
        this.displayName = '我的材质';        // 显示名称
        this.supportsOutline = false;         // 是否支持轮廓线
        this.supportsMorph = false;           // 是否支持材质变形
        this.createsMaterial = true;          // 是否需要创建新材质
    };

    /**
     * 判定材质是否由该适配器处理
     * @param {BABYLON.Material} material - 材质实例
     * @returns {boolean}
     */
    MyAdapter.prototype.canHandle = function(material) {
        return material instanceof BABYLON.PBRMaterial;  // 替换为你的材质类型
    };

    /**
     * 从材质读取参数状态
     * @param {BABYLON.Material} material - 材质实例
     * @returns {Object} 参数键值对
     */
    MyAdapter.prototype.readState = function(material) {
        return {
            // 在此读取材质参数
            // 颜色值使用 { r, g, b } 格式
            // 数值直接返回
            // 字符串用于 dropdown 类型
            // 布尔值用于 toggle 类型
        };
    };

    /**
     * 将参数状态写入材质
     * @param {BABYLON.Material} material - 材质实例
     * @param {Object} state - 参数键值对
     */
    MyAdapter.prototype.writeState = function(material, state) {
        // 在此将 state 中的值写入材质属性
        // 注意：颜色值需要创建 BABYLON.Color3 实例
    };

    /**
     * 声明参数控件
     * @returns {Array} 控件声明数组
     */
    MyAdapter.prototype.getControlDeclarations = function() {
        return [
            // 示例：带分组的颜色 + 滑块
            // { param: 'baseColor', type: 'color', label: '基色', group: '基础' },
            // { param: 'intensity', type: 'slider', label: '强度', min: 0, max: 1, step: 0.01, group: '基础' },
            //
            // 示例：下拉选择
            // { param: 'blendMode', type: 'dropdown', label: '混合模式', options: ['opaque', 'blend'], optionLabels: ['不透明', '半透明'] },
            //
            // 示例：开关
            // { param: 'enabled', type: 'toggle', label: '启用' },
        ];
    };

    /**
     * 获取参数默认值
     * @returns {Object} 默认参数键值对
     */
    MyAdapter.prototype.getDefaultState = function() {
        return {
            // 在此返回默认参数值
        };
    };

    /**
     * 将 MmdStandardMaterial 转换为该适配器的材质类型（可选）
     * createsMaterial=true 时建议实现
     * @param {BABYLON.Material} mmdMaterial - MMD 标准材质
     * @param {BABYLON.Scene} scene - 场景
     * @returns {BABYLON.Material} 转换后的材质
     */
    MyAdapter.prototype.convertFromMmd = function(mmdMaterial, scene) {
        // 在此创建新材质并迁移 MMD 材质的属性
        // 建议迁移：diffuseColor/Texture, emissiveColor/Texture, alpha, backFaceCulling
        var newMaterial = new BABYLON.PBRMaterial(mmdMaterial.name + '_custom', scene);
        // ... 迁移属性 ...
        return newMaterial;
    };

    /**
     * 释放材质资源
     * @param {BABYLON.Material} material - 要释放的材质
     */
    MyAdapter.prototype.disposeMaterial = function(material) {
        material.dispose();
    };

    // ========== 导出 ==========
    exports.adapter = new MyAdapter();

})();
```

---

## 六、风格切换流程

了解宿主的风格切换流程有助于正确实现适配器：

### 6.1 切换到自定义风格

```
用户在着色面板选择 "PBR 材质"
    │
    ▼
ShadingPanel 查找 adapter = materialAdapterRegistry.get('pbr')
    │
    ▼
遍历模型所有材质:
    ├─ MmdStandardMaterial → adapter.convertFromMmd()
    │   ├─ 创建新材质，迁移 diffuseColor → albedoColor 等
    │   ├─ 保存原始 MmdStandardMaterial 引用（不 dispose，保持 Proxy 有效）
    │   ├─ 替换 mesh.material = newMaterial
    │   └─ 更新 metadata.materials[i] = newMaterial
    │
    ├─ 隐藏描边宽度控件 (supportsOutline=false)
    ├─ 刷新材质参数面板 → 显示 PBR 控件
    └─ VMD 材质变形动画停止生效 (supportsMorph=false)
```

### 6.2 切换回 MMD 标准风格

```
用户在着色面板选择 "MMD 标准"
    │
    ▼
遍历模型所有材质:
    ├─ 从 ShadingStateManager 恢复原始 MmdStandardMaterial 引用
    ├─ 释放转换后的材质 (adapter.disposeMaterial)
    ├─ 恢复 mesh.material = 原始MmdStandardMaterial
    └─ 更新 metadata.materials[i] = 原始MmdStandardMaterial
    │
    ├─ 显示描边宽度控件
    ├─ 刷新材质参数面板 → 显示 MMD 标准控件
    └─ VMD 材质变形动画恢复生效
```

### 6.3 关键行为

| 场景 | 风格选择器 | 描边宽度 | 材质参数面板 |
|------|-----------|---------|------------|
| 无着色插件 | 隐藏 | 显示 | MMD 标准控件 |
| 仅 createsMaterial=false 插件 | 隐藏 | 显示 | MMD 标准控件 + 插件扩展控件 |
| createsMaterial=true 插件注册 | 显示 | 显示 | 取决于当前选中风格 |
| 切换到自定义风格（如 PBR / Toon） | 显示（选中该风格） | 取决于 `supportsOutline`（Toon/默认均 `true`；PBR `false`） | 自定义控件（PBR 完整 IBL/SSS 参数；Toon：光照/边缘光/透明度/法线贴图） |
| 切换回 MMD 标准 | 显示（选中 MMD） | 显示 | MMD 标准控件 |
| createsMaterial=true 插件注销 | 隐藏（自动恢复 MMD） | 显示 | MMD 标准控件 |
| Toon 风格切换时的特殊行为 | `displayName='Toon卡通(Dev)'` | 显示 | 通过 `ToonShadingSharedParams` 同步全局共享风格参数，每材质 `normalMap` 独立加载/释放 |

---

## 七、控件分组

`getControlDeclarations()` 返回的控件声明支持 `group` 字段，用于将多个控件合并到一个分组容器中显示。分组容器的行为：

- **toggle 类型**：放入标题栏
- **color 类型**：标题栏显示颜色预览块，点击弹窗编辑
- **slider / dropdown 类型**：放入内容区

```javascript
// 示例：分组控件
[
    // "反射" 分组：颜色 + 滑块
    { param: 'specular', type: 'color', label: '反射色', group: '反射' },
    { param: 'shininess', type: 'slider', label: '强度', min: 0, max: 100, step: 1, group: '反射' },

    // "自发光" 分组：颜色 + 滑块
    { param: 'emissive', type: 'color', label: '自发光', group: '自发光' },
    { param: 'emissiveIntensity', type: 'slider', label: '强度', min: 0, max: 1, step: 0.01, group: '自发光' },

    // 无分组：独立显示
    { param: 'alpha', type: 'slider', label: 'Alpha', min: 0, max: 1, step: 0.01 }
]
```

---

## 八、开发注意事项

### 8.1 convertFromMmd 实现要点

- **必须迁移的属性**：`diffuseColor`/`diffuseTexture`、`emissiveColor`/`emissiveTexture`、`alpha`、`backFaceCulling`
- **原始材质保留**：宿主会保存原始 `MmdStandardMaterial` 引用但不 dispose，以保持 `MmdStandardMaterialProxy` 有效。切换回 MMD 标准时自动恢复
- **材质命名**：建议使用 `mmdMaterial.name + '_suffix'` 格式，避免命名冲突
- **不实现此方法**：如果 `convertFromMmd` 未实现，用户将无法从 MMD 标准风格切换到该风格

### 8.2 资源管理

- `disposeMaterial()` 必须释放所有创建的 Babylon.js 资源
- `convertFromMmd()` 中创建的新材质，其纹理引用（如 `diffuseTexture`）是共享的，不要在 `disposeMaterial()` 中释放共享纹理
- 使用 `scene.onBeforeRenderObservable` 等观察者时，务必在 `dispose()` 中取消注册

### 8.3 性能考虑

- `readState()` 和 `writeState()` 会在用户操作控件时频繁调用，避免在其中创建新对象
- 颜色值使用 `{ r, g, b }` 对象而非 `BABYLON.Color3` 实例，减少 GC 压力
- `convertFromMmd()` 中使用 `clone()` 复制颜色，避免引用共享

### 8.4 适配器注册/注销

宿主自动处理适配器的注册和注销，插件开发者无需手动操作 `materialAdapterRegistry`：

- **注册**：插件加载时，宿主检测 `manifest.target === 'shading'` 且 `exports` 包含 `adapter`，自动调用 `materialAdapterRegistry.register(adapter)` 并发出 `shading:adapter_registered` 事件
- **注销**：插件卸载时，宿主自动调用 `materialAdapterRegistry.unregister(typeId)` 并发出 `shading:adapter_unregistered` 事件。如果当前有模型使用该风格，会先自动恢复为 MMD 标准

### 8.5 代码风格

- 插件代码使用纯 JavaScript（非 TypeScript），在宿主全局作用域中执行（黑名单模式，见 [01-overview.md](01-overview.md)）
- 使用 `var exports = {};` 作为导出对象
- 推荐使用 IIFE 包裹代码，避免全局变量污染
- 推荐使用原型链风格定义适配器类

### 8.6 错误处理

- 宿主通过 `safeCall()` 统一捕获插件方法异常，不会影响其他插件和宿主
- 建议在 `writeState()` 中检查 `state` 中的值是否存在再写入，避免 `undefined` 导致异常
- 控制台是浏览器原生 console（宿主不包装），无自动前缀；建议日志自行加标签（如 `[MyPlugin]`）便于过滤

---

## 九、文档信息

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | §1.2 新增 §1.2.1 "内置适配器一览"，列出 3 个内置适配器的 `typeId` / `displayName` / `supportsOutline` / `supportsMorph`；校正 `ToonShadingMaterialAdapter` 实际属性（`displayName='Toon卡通(Dev)'`、`supportsMorph=true`、`typeId='toon-shading'`）；§6.3 "关键行为"表新增 Toon 风格切换行的特殊行为说明（共享风格参数、每材质 normalMap 等） |
| v2.0 | 2026-08-15 | 与黑名单模式重构同步 |
| v1.0 | - | 初始版本 |
