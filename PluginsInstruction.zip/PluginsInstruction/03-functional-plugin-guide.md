# 功能型插件开发指南

功能型插件（`type: 'functional'`）不创建 UI，而是通过 `target` 字段声明作用模块，由宿主自动生成控件并集成到对应的界面区域。

---

## 一、功能型插件概述

### 1.1 工作原理

功能型插件通过 `manifest.json` 中的 `target` 字段声明作用模块。宿主应用在对应的界面区域（如地面下拉框、粒子效果选择器）自动发现并集成该插件。

当前支持的 `target` 值（联合类型共 5 种，已实现 4 种 + 1 种预留）：

| target | 说明 | 宿主集成位置 | 导出接口 | 状态 |
|--------|------|-------------|---------|------|
| `ground` | 地面插件 | 世界面板 → 地面区域 → 类型下拉框 | `FunctionalPluginExports` | ✅ 已实现 |
| `particle` | 粒子插件 | 世界面板 → 粒子区域 → 类型下拉框 | `FunctionalPluginExports` | ✅ 已实现 |
| `shading` | 着色插件 | 着色面板 → 渲染风格选择器 / 材质参数区 | `ShadingPluginExports` | ✅ 已实现（含 3 个内置适配器） |
| `postproc` | 后处理插件 | 后处理面板 → 动态插件效果区域 | `PostProcessPluginExports` | ⚠️ 核心已实现（适配器/注册表/事件），UI 集成待实现 |
| `background` | 背景插件 | 背景面板（预留） | （未定义） | ⏳ 仅类型联合预留，**当前无 `PluginExecutor` shape 校验**，声明后会被宿主忽略 |

> **着色插件**使用独立的导出接口 `ShadingPluginExports`，开发方式与地面/粒子插件有本质区别。着色插件的完整开发指南请参阅 [06-shading-plugin-guide.md](06-shading-plugin-guide.md)。
>
> **后处理插件**使用独立的导出接口 `PostProcessPluginExports`，开发方式与地面/粒子插件也有本质区别。后处理插件的完整开发指南请参阅 [07-postproc-plugin-design.md](07-postproc-plugin-design.md)。
>
> 本文档仅涵盖地面和粒子插件。`background` target 在 `src/core/IPlugin.ts` 的 `PluginTarget` 联合类型中已声明但尚未配套 `PluginExecutor` 校验，**外部插件暂勿使用**。

### 1.2 地面与粒子插件

地面插件和粒子插件都使用 `FunctionalPluginExports` 导出接口，但需要实现的内容不同：

- **地面插件**（`target: 'ground'`）：必须提供 `createInstance()` 工厂方法，返回 `IGroundPluginInstance` 实现
- **粒子插件**（`target: 'particle'`）：通过 `preset.renderConfig` 声明渲染配置，无需 `createInstance()`

---

## 二、地面插件开发

### 2.1 必须实现的接口

地面插件必须导出以下内容：

```javascript
exports.preset = {
    name: '显示名称',
    defaultParams: {},
    controls: []
};

exports.createInstance = function() {
    return new MyGroundInstance();
};
```

其中 `MyGroundInstance` 必须实现 `IGroundPluginInstance` 接口：

| 方法 | 必填 | 说明 |
|------|------|------|
| `create(scene, scale, height)` | 是 | 创建地面网格和材质 |
| `dispose()` | 是 | 销毁地面，释放所有资源 |
| `setScale(scale)` | 是 | 设置地面缩放 |
| `setHeight(height)` | 是 | 设置地面高度（Y 坐标） |
| `createPrivateParams()` | 否 | 返回自定义参数 UI 的 HTMLElement |

### 2.2 完整示例：简单纯色地面

#### manifest.json

```json
{
    "id": "test.ground.simple",
    "name": "Test Ground",
    "version": "1.0.0",
    "type": "functional",
    "target": "ground",
    "author": "Test Author",
    "description": "A test ground plugin that creates a simple colored plane"
}
```

#### index.js

```javascript
/**
 * Test Ground Plugin - 测试地面插件
 * 
 * 功能：创建一个简单的纯色地面
 */

var exports = {};

(function() {
    
    var TestGroundInstance = function() {
        this.mesh = null;
        this.material = null;
        this.scene = null;
        this.currentScale = 1;
        this.currentHeight = 0;
        this.color = { r: 0.5, g: 0.8, b: 0.5 };
    };
    
    // 创建地面
    TestGroundInstance.prototype.create = function(scene, scale, height) {
        this.scene = scene;
        this.currentScale = scale;
        this.currentHeight = height;
        
        this.mesh = BABYLON.MeshBuilder.CreateGround(
            'testGround',
            { width: 100 * scale, height: 100 * scale },
            scene
        );
        
        this.material = new BABYLON.StandardMaterial('testGroundMat', scene);
        this.material.diffuseColor = new BABYLON.Color3(
            this.color.r, this.color.g, this.color.b
        );
        this.material.specularColor = new BABYLON.Color3(0.1, 0.1, 0.1);
        
        this.mesh.material = this.material;
        this.mesh.position.y = height;
    };
    
    // 销毁地面
    TestGroundInstance.prototype.dispose = function() {
        if (this.mesh) {
            this.mesh.dispose();
            this.mesh = null;
        }
        if (this.material) {
            this.material.dispose();
            this.material = null;
        }
    };
    
    // 设置缩放
    TestGroundInstance.prototype.setScale = function(scale) {
        this.currentScale = scale;
        if (this.mesh) {
            this.mesh.scaling.x = scale;
            this.mesh.scaling.z = scale;
        }
    };
    
    // 设置高度
    TestGroundInstance.prototype.setHeight = function(height) {
        this.currentHeight = height;
        if (this.mesh) {
            this.mesh.position.y = height;
        }
    };
    
    // 设置颜色
    TestGroundInstance.prototype.setColor = function(r, g, b) {
        this.color = { r: r, g: g, b: b };
        if (this.material) {
            this.material.diffuseColor = new BABYLON.Color3(r, g, b);
        }
    };
    
    // 创建自定义参数 UI（可选）
    TestGroundInstance.prototype.createPrivateParams = function() {
        var container = document.createElement('div');
        container.style.cssText = 'display: flex; flex-direction: column; gap: 8px; padding: 8px 0;';
        
        var self = this;
        
        // 创建滑块辅助函数
        var createSlider = function(label, getValue, setValue, min, max, step) {
            var item = document.createElement('div');
            item.style.cssText = 'display: flex; justify-content: space-between; align-items: center; gap: 8px;';
            
            var labelEl = document.createElement('span');
            labelEl.textContent = label;
            labelEl.style.cssText = 'font-size: 12px; color: var(--text-secondary);';
            
            var sliderContainer = document.createElement('div');
            sliderContainer.style.cssText = 'display: flex; align-items: center; gap: 4px; flex: 1;';
            
            var slider = document.createElement('input');
            slider.type = 'range';
            slider.min = min;
            slider.max = max;
            slider.step = step;
            slider.value = getValue();
            slider.style.cssText = 'flex: 1;';
            
            var valueDisplay = document.createElement('span');
            valueDisplay.textContent = parseFloat(getValue()).toFixed(2);
            valueDisplay.style.cssText = 'font-size: 12px; color: var(--text-primary); min-width: 40px; text-align: right;';
            
            slider.addEventListener('input', function() {
                var val = parseFloat(slider.value);
                valueDisplay.textContent = val.toFixed(2);
                setValue(val);
            });
            
            sliderContainer.appendChild(slider);
            sliderContainer.appendChild(valueDisplay);
            item.appendChild(labelEl);
            item.appendChild(sliderContainer);
            
            return item;
        };
        
        container.appendChild(createSlider(
            'Red',
            function() { return self.color.r; },
            function(v) { self.setColor(v, self.color.g, self.color.b); },
            0, 1, 0.01
        ));
        
        container.appendChild(createSlider(
            'Green',
            function() { return self.color.g; },
            function(v) { self.setColor(self.color.r, v, self.color.b); },
            0, 1, 0.01
        ));
        
        container.appendChild(createSlider(
            'Blue',
            function() { return self.color.b; },
            function(v) { self.setColor(self.color.r, self.color.g, v); },
            0, 1, 0.01
        ));
        
        return container;
    };
    
    // 导出预设
    exports.preset = {
        name: 'Test Ground',
        defaultParams: {},
        controls: []
    };
    
    // 导出实例工厂
    exports.createInstance = function() {
        return new TestGroundInstance();
    };
    
})();
```

### 2.3 地面插件开发要点

1. **命名规范**：网格和材质的名称建议使用唯一前缀，避免与其他插件冲突
2. **资源释放**：`dispose()` 必须释放所有创建的 Babylon.js 资源（mesh、material、texture 等）
3. **缩放实现**：`setScale()` 应同时缩放 X 和 Z 轴，保持地面为正方形
4. **高度实现**：`setHeight()` 设置 mesh 的 `position.y`
5. **自定义参数**：`createPrivateParams()` 返回的 DOM 元素会被插入到地面区域的参数区
6. **纹理路径**：如果需要加载纹理，使用 `context.assetsDir + '/texture.png'` 拼接路径

---

## 三、粒子插件开发

### 3.1 必须导出的内容

粒子插件通过 `preset.renderConfig` 声明渲染配置，宿主根据此配置创建粒子系统：

```javascript
exports.preset = {
    name: '显示名称',
    defaultParams: {
        emitRate: 100,
        minSize: 0.1,
        maxSize: 0.5,
        // ... 其他参数
    },
    controls: [
        { param: 'emitRate', type: 'slider', label: '发射速率', min: 0, max: 500, step: 10 },
        { param: 'minSize', type: 'slider', label: '最小尺寸', min: 0, max: 1, step: 0.01 },
        // ... 其他控件声明
    ],
    renderConfig: {
        textureSource: 'external',
        texture: 'flare.png',
        blendMode: 'standard',
        depthWrite: false,
        enableRotation: true,
        defaultMaxParticles: 1000
    }
};
```

### 3.2 ParticleRenderConfig 详解

| 字段 | 类型 | 说明 |
|------|------|------|
| `textureSource` | `string` | 纹理来源：`'procedural'`（程序化）、`'builtin'`（内置）、`'external'`（外部 URL） |
| `texture` | `string` | 纹理路径或类型名。`procedural` 时为 `'rain'`/`'sakura'`/`'snow'`；`builtin` 时为纹理注册表中的名称；`external` 时为 URL |
| `blendMode` | `string` | 混合模式：`'standard'`（标准 Alpha 混合）或 `'oneOne'`（加法混合） |
| `depthWrite` | `boolean` | 是否写入深度缓冲 |
| `enableRotation` | `boolean` | 是否启用粒子旋转 |
| `defaultMaxParticles` | `number` | 默认最大粒子数 |

### 3.3 控件声明 (ControlDeclaration)

粒子插件的 `controls` 数组声明了宿主自动生成的参数控件。每个控件对应 `defaultParams` 中的一个参数：

#### 滑块控件

```javascript
{
    param: 'emitRate',     // 对应 defaultParams 中的 key
    type: 'slider',        // 控件类型
    label: '发射速率',      // 显示标签
    min: 0,                // 最小值
    max: 500,              // 最大值
    step: 10               // 步进值
}
```

#### 颜色控件

```javascript
{
    param: 'colorStart',   // 对应 defaultParams 中的 key
    type: 'color',         // 控件类型
    label: '起始颜色'       // 显示标签
}
```

#### 向量控件

```javascript
{
    param: 'emitterPosition', // 对应 defaultParams 中的 key
    type: 'vector',           // 控件类型
    label: '发射器位置'        // 显示标签
}
```

### 3.4 粒子参数 (ParticleParams)

宿主支持以下粒子参数（可在 `defaultParams` 中声明）：

| 参数 | 类型 | 说明 |
|------|------|------|
| `emitNormal` | `number[]` | 发射方向 |
| `lifeTime` | `number[]` | 生命周期范围 [min, max] |
| `minSize` | `number` | 最小尺寸 |
| `maxSize` | `number` | 最大尺寸 |
| `emitRate` | `number` | 每秒发射数量 |
| `speed` | `number[]` | 速度范围 [min, max] |
| `gravity` | `number[]` | 重力向量 [x, y, z] |
| `turbulence` | `number` | 扰动强度 |
| `colorStart` | `number[]` | 起始颜色 [r, g, b]（0-1 范围） |
| `colorEnd` | `number[]` | 结束颜色 [r, g, b]（0-1 范围） |
| `emitterPosition` | `number[]` | 发射器位置 [x, y, z] |
| `emitterSize` | `number[]` | 发射器尺寸 [x, y, z] |
| `rotationSpeed` | `number` | 旋转速度 |
| `maxParticles` | `number` | 最大粒子数 |

### 3.5 完整示例：自定义粒子效果

#### manifest.json

```json
{
    "id": "com.example.fire-particles",
    "name": "火焰粒子",
    "version": "1.0.0",
    "type": "functional",
    "target": "particle",
    "author": "Example Author",
    "description": "向上飘散的火焰粒子效果"
}
```

#### index.js

```javascript
var exports = {};

(function() {

    exports.preset = {
        name: '火焰粒子',
        defaultParams: {
            emitRate: 200,
            minSize: 0.1,
            maxSize: 0.4,
            speed: [1, 3],
            lifeTime: [0.5, 1.5],
            colorStart: [1, 0.6, 0.1],
            colorEnd: [0.8, 0.1, 0],
            gravity: [0, 2, 0],
            turbulence: 0.5
        },
        controls: [
            { param: 'emitRate', type: 'slider', label: '发射速率', min: 10, max: 500, step: 10 },
            { param: 'minSize', type: 'slider', label: '最小尺寸', min: 0.01, max: 1, step: 0.01 },
            { param: 'maxSize', type: 'slider', label: '最大尺寸', min: 0.01, max: 2, step: 0.01 },
            { param: 'colorStart', type: 'color', label: '起始颜色' },
            { param: 'colorEnd', type: 'color', label: '结束颜色' }
        ],
        renderConfig: {
            textureSource: 'builtin',
            texture: 'flare',
            blendMode: 'oneOne',
            depthWrite: false,
            enableRotation: false,
            defaultMaxParticles: 2000
        }
    };

})();
```

---

## 四、功能型插件模板

### 4.1 地面插件模板

#### manifest.json

```json
{
    "id": "com.author.ground-name",
    "name": "地面名称",
    "version": "1.0.0",
    "type": "functional",
    "target": "ground",
    "author": "作者名",
    "description": "地面插件描述"
}
```

#### index.js

```javascript
/**
 * 地面插件模板
 */

var exports = {};

(function() {

    // ========== 地面实例类 ==========
    var MyGroundInstance = function() {
        this.mesh = null;
        this.material = null;
        this.scene = null;
        this.currentScale = 1;
        this.currentHeight = 0;
        // 在此初始化自定义参数
    };

    /**
     * 创建地面
     * @param {BABYLON.Scene} scene - 场景
     * @param {number} scale - 缩放
     * @param {number} height - 高度
     */
    MyGroundInstance.prototype.create = function(scene, scale, height) {
        this.scene = scene;
        this.currentScale = scale;
        this.currentHeight = height;

        // 创建地面网格
        this.mesh = BABYLON.MeshBuilder.CreateGround(
            'myGround',
            { width: 100 * scale, height: 100 * scale },
            scene
        );

        // 创建材质
        this.material = new BABYLON.StandardMaterial('myGroundMat', scene);
        // ... 配置材质

        this.mesh.material = this.material;
        this.mesh.position.y = height;
    };

    /**
     * 销毁地面，释放所有资源
     */
    MyGroundInstance.prototype.dispose = function() {
        if (this.mesh) {
            this.mesh.dispose();
            this.mesh = null;
        }
        if (this.material) {
            this.material.dispose();
            this.material = null;
        }
    };

    /**
     * 设置缩放
     * @param {number} scale - 缩放值
     */
    MyGroundInstance.prototype.setScale = function(scale) {
        this.currentScale = scale;
        if (this.mesh) {
            this.mesh.scaling.x = scale;
            this.mesh.scaling.z = scale;
        }
    };

    /**
     * 设置高度
     * @param {number} height - 高度值
     */
    MyGroundInstance.prototype.setHeight = function(height) {
        this.currentHeight = height;
        if (this.mesh) {
            this.mesh.position.y = height;
        }
    };

    /**
     * 创建自定义参数 UI（可选）
     * @returns {HTMLElement} 参数面板 DOM 元素
     */
    MyGroundInstance.prototype.createPrivateParams = function() {
        var container = document.createElement('div');
        container.style.cssText = 'display: flex; flex-direction: column; gap: 8px; padding: 8px 0;';

        // 在此添加自定义参数控件
        // 可使用 CSS 自定义属性（如 var(--text-secondary)）保持主题一致

        return container;
    };

    // ========== 导出 ==========
    exports.preset = {
        name: '地面名称',
        defaultParams: {},
        controls: []
    };

    exports.createInstance = function() {
        return new MyGroundInstance();
    };

})();
```

### 4.2 粒子插件模板

#### manifest.json

```json
{
    "id": "com.author.particle-name",
    "name": "粒子名称",
    "version": "1.0.0",
    "type": "functional",
    "target": "particle",
    "author": "作者名",
    "description": "粒子插件描述"
}
```

#### index.js

```javascript
/**
 * 粒子插件模板
 */

var exports = {};

(function() {

    exports.preset = {
        name: '粒子名称',
        defaultParams: {
            emitRate: 100,
            minSize: 0.1,
            maxSize: 0.5,
            speed: [1, 3],
            lifeTime: [1, 3],
            colorStart: [1, 1, 1],
            colorEnd: [1, 1, 1],
            gravity: [0, -9.8, 0],
            turbulence: 0
        },
        controls: [
            { param: 'emitRate', type: 'slider', label: '发射速率', min: 0, max: 500, step: 10 },
            { param: 'minSize', type: 'slider', label: '最小尺寸', min: 0.01, max: 1, step: 0.01 },
            { param: 'maxSize', type: 'slider', label: '最大尺寸', min: 0.01, max: 2, step: 0.01 }
        ],
        renderConfig: {
            textureSource: 'external',
            texture: 'flare.png',
            blendMode: 'standard',
            depthWrite: false,
            enableRotation: false,
            defaultMaxParticles: 1000
        }
    };

})();
```

---

## 五、开发注意事项

### 5.1 代码风格

- 插件代码使用纯 JavaScript（非 TypeScript），在宿主全局作用域中执行（黑名单模式，见 [01-overview.md](01-overview.md)）
- 使用 `var exports = {};` 作为导出对象，代码末尾通过 `exports` 返回导出内容
- 推荐使用 IIFE（立即执行函数）包裹代码，避免全局变量污染
- 推荐使用原型链风格定义类（如示例中的 `MyGroundInstance.prototype.method`）

### 5.2 资源管理

- 所有创建的 Babylon.js 资源必须在 `dispose()` 中释放
- 使用 `scene.onBeforeRenderObservable` 等观察者时，务必在 `dispose()` 中取消注册
- 使用 `context.eventBus.on()` 订阅事件时，保存返回的取消函数，在 `dispose()` 中调用

### 5.3 错误处理

- 宿主通过 `safeCall()` 统一捕获插件方法异常，不会影响其他插件和宿主
- 建议在关键操作中添加 try-catch，使用 `console.error()` 输出错误信息
- 控制台是浏览器原生 console（宿主不包装），无自动前缀；建议日志自行加标签（如 `[MyPlugin]`）便于过滤

### 5.4 性能考虑

- 避免在每帧回调中创建新对象（如 `new BABYLON.Vector3`）
- 地面网格的面数应控制在合理范围内（建议细分不超过 128）
- 粒子数量应根据设备性能合理设置 `defaultMaxParticles`

### 5.5 兼容性

- 插件运行在 Capacitor WebView 中，支持现代浏览器 API
- 触摸操作需要同时处理 mouse 和 touch 事件
- 文件路径需要通过 `context.assetsDir` 拼接，不能使用相对路径

---

## 六、文档信息

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | §1.1 `target` 表格扩充为 5 种，新增 `background` 行（标注当前仅联合类型预留、`PluginExecutor` 尚无 shape 校验、外部插件暂勿使用）；将原"4 种"措辞改为"联合类型共 5 种，已实现 4 种 + 1 种预留" |
| v2.0 | 2026-08-15 | 与黑名单模式重构同步：插件与宿主同 realm，可自由访问场景 |
| v1.0 | - | 初始版本 |
