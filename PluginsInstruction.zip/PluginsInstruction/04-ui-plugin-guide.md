# UI 型插件开发指南

UI 型插件（`type: 'ui'`）自建 UI，通过 `mount` 字段声明挂载位置，可以创建自定义的面板或叠加层。

---

## 一、UI 型插件概述

### 1.1 挂载方式

UI 型插件通过 `manifest.json` 中的 `mount` 字段声明挂载方式：

| mount | 说明 | 位置 | 生命周期 |
|-------|------|------|---------|
| `tab` | 标签页 | 底部 NavBar 中添加一个标签项，点击展开面板 | 切换标签时调用 `onShown`/`onHidden` |
| `overlay` | 叠加层 | 悬浮在 3D 视口上方 | 始终可见，随视口显示/隐藏 |

### 1.2 必须导出的接口

```javascript
exports.createPanel = function(context) {
    // 创建并返回面板的 DOM 元素
    var container = document.createElement('div');
    // ... 构建 UI
    return container;
};

// 可选的生命周期方法
exports.onShown = function() { /* 面板显示时调用 */ };
exports.onHidden = function() { /* 面板隐藏时调用 */ };
exports.dispose = function() { /* 释放资源 */ };
```

---

## 二、Tab 型插件开发

### 2.1 工作原理

Tab 型插件在底部 NavBar 中注册一个标签项。用户点击标签时：
1. 旧面板调用 `unmount()` + `onHidden()`
2. 新面板调用 `mount()` + `onShown()`

标签的图标和文本由宿主自动生成（使用插件 manifest 中的 `name` 首字符作为标签文本）。

### 2.2 完整示例：简单信息面板

#### manifest.json

```json
{
    "id": "test.ui.panel1",
    "name": "测试1",
    "version": "1.0.0",
    "type": "ui",
    "mount": "tab",
    "author": "Test Author",
    "description": "测试面板1"
}
```

#### index.js

```javascript
var exports = {};

exports.createPanel = function(context) {
    var container = document.createElement('div');
    container.style.cssText = 'padding: 20px; color: #fff;';
    container.textContent = '测试面板 1';
    return container;
};

exports.onShown = function() {
    console.log('[TestPanel1] 显示');
};

exports.onHidden = function() {
    console.log('[TestPanel1] 隐藏');
};

exports.dispose = function() {
    console.log('[TestPanel1] 释放');
};
```

### 2.3 进阶示例：带交互的面板

```javascript
var exports = {};

(function() {

    var container = null;
    var unsubscribers = [];

    exports.createPanel = function(context) {
        container = document.createElement('div');
        container.style.cssText = 'padding: 16px; color: var(--text-primary); display: flex; flex-direction: column; gap: 12px;';

        // 标题
        var title = document.createElement('h3');
        title.textContent = '模型信息';
        title.style.cssText = 'margin: 0; font-size: 16px; color: var(--text-primary);';
        container.appendChild(title);

        // 模型列表
        var listContainer = document.createElement('div');
        listContainer.style.cssText = 'display: flex; flex-direction: column; gap: 8px;';
        container.appendChild(listContainer);

        // 监听模型加载事件
        var unsub = context.eventBus.on('model:loaded', function(modelInfo) {
            var item = document.createElement('div');
            item.style.cssText = 'padding: 8px; background: var(--color-surface); border-radius: var(--radius-md);';
            item.textContent = modelInfo.name || '未知模型';
            listContainer.appendChild(item);
        });
        unsubscribers.push(unsub);

        // 按钮
        var btn = document.createElement('button');
        btn.className = 'mp-btn primary';
        btn.textContent = '刷新列表';
        btn.addEventListener('click', function() {
            listContainer.innerHTML = '';
        });
        container.appendChild(btn);

        return container;
    };

    exports.onShown = function() {
        console.log('[ModelInfo] 面板已显示');
    };

    exports.onHidden = function() {
        console.log('[ModelInfo] 面板已隐藏');
    };

    exports.dispose = function() {
        // 取消所有事件订阅
        unsubscribers.forEach(function(unsub) { unsub(); });
        unsubscribers = [];
        container = null;
    };

})();
```

---

## 三、Overlay 型插件开发

### 3.1 工作原理

Overlay 型插件悬浮在 3D 视口上方，适合实现工具按钮、信息显示等常驻 UI 元素。

- 面板元素会被放置在视口容器内，使用 `position: absolute` 定位
- 需要自行处理定位、大小和样式
- 始终可见，不受标签切换影响

### 3.2 完整示例：相机重置按钮

#### manifest.json

```json
{
    "id": "test.ui.camera-reset",
    "name": "相机重置按钮",
    "version": "1.0.0",
    "type": "ui",
    "mount": "overlay",
    "author": "Test Author",
    "description": "悬浮在3D视口右上角的相机重置按钮"
}
```

#### index.js

```javascript
/**
 * Camera Reset UI Plugin - 相机重置UI插件
 * 
 * 功能：在3D视口右上角显示一个方形叠加层，包含相机重置按钮
 */

var exports = {};

(function() {

    /**
     * 创建面板
     * @param {Object} context - 插件上下文
     * @returns {HTMLElement} 面板元素
     */
    exports.createPanel = function(context) {
        // 创建容器 - 方形叠加层，固定在右上角
        var container = document.createElement('div');
        container.className = 'camera-reset-overlay';
        container.style.cssText = [
            'position: absolute',
            'top: 16px',
            'right: 16px',
            'width: 80px',
            'height: 80px',
            'background: rgba(30, 30, 30, 0.85)',
            'border-radius: 12px',
            'display: flex',
            'flex-direction: column',
            'align-items: center',
            'justify-content: center',
            'pointer-events: auto',
            'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3)',
            'border: 1px solid rgba(255, 255, 255, 0.1)',
            'z-index: 10'
        ].join(';');

        // 创建重置按钮
        var resetButton = document.createElement('button');
        resetButton.innerHTML = '⟲';
        resetButton.title = '重置相机视角';
        resetButton.style.cssText = [
            'width: 48px',
            'height: 48px',
            'border-radius: 50%',
            'border: none',
            'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'color: white',
            'font-size: 24px',
            'cursor: pointer',
            'display: flex',
            'align-items: center',
            'justify-content: center',
            'transition: transform 0.2s, box-shadow 0.2s',
            'box-shadow: 0 2px 8px rgba(102, 126, 234, 0.4)'
        ].join(';');

        // 悬停效果
        resetButton.addEventListener('mouseenter', function() {
            resetButton.style.transform = 'scale(1.1)';
        });
        resetButton.addEventListener('mouseleave', function() {
            resetButton.style.transform = 'scale(1)';
        });

        // 点击事件 - 重置相机视角
        resetButton.addEventListener('click', function() {
            try {
                resetCamera(context);
            } catch (error) {
                console.error('[CameraResetPlugin] 重置相机失败:', error);
            }
        });

        container.appendChild(resetButton);
        return container;
    };

    /**
     * 重置相机视角
     */
    function resetCamera(context) {
        var scene = context.scene;
        var camera = scene.activeCamera;

        if (!camera) return;

        // 检查是否为MMD相机
        if (camera.getClassName && camera.getClassName() === 'MmdCamera') {
            camera.position = new BABYLON.Vector3(0, 10, -40);
            camera.target = new BABYLON.Vector3(0, 10, 0);
            camera.rotation = new BABYLON.Vector3(-0.22, 0, 0);
            camera.distance = 30;
            if (typeof camera.updatePosition === 'function') {
                camera.updatePosition();
            }
        } else {
            camera.position = new BABYLON.Vector3(0, 10, -30);
            if (camera.setTarget) {
                camera.setTarget(BABYLON.Vector3.Zero());
            }
        }

        // 触发自定义事件
        if (context.eventBus && context.eventBus.emit) {
            context.eventBus.emit('camera:reset', {
                position: camera.position.clone(),
                target: camera.target ? camera.target.clone() : null
            });
        }
    }

    exports.onShown = function() {
        console.log('[CameraResetPlugin] 面板已显示');
    };

    exports.onHidden = function() {
        console.log('[CameraResetPlugin] 面板已隐藏');
    };

    exports.dispose = function() {
        console.log('[CameraResetPlugin] 插件已释放');
    };

})();
```

---

## 四、UI 型插件模板

### 4.1 Tab 型插件模板

#### manifest.json

```json
{
    "id": "com.author.tab-plugin",
    "name": "插件名称",
    "version": "1.0.0",
    "type": "ui",
    "mount": "tab",
    "author": "作者名",
    "description": "Tab 型插件描述"
}
```

#### index.js

```javascript
/**
 * Tab 型插件模板
 */

var exports = {};

(function() {

    var container = null;
    var unsubscribers = [];

    /**
     * 创建面板
     * @param {Object} context - 插件上下文
     * @returns {HTMLElement} 面板元素
     */
    exports.createPanel = function(context) {
        container = document.createElement('div');
        container.style.cssText = 'padding: 16px; color: var(--text-primary); display: flex; flex-direction: column; gap: 12px; overflow-y: auto; height: 100%;';

        // ===== 标题区 =====
        var header = document.createElement('div');
        header.style.cssText = 'font-size: 16px; font-weight: bold; color: var(--text-primary);';
        header.textContent = '我的插件';
        container.appendChild(header);

        // ===== 内容区 =====
        var content = document.createElement('div');
        content.style.cssText = 'display: flex; flex-direction: column; gap: 8px;';

        // 示例：添加一个按钮
        var actionBtn = document.createElement('button');
        actionBtn.className = 'mp-btn primary';
        actionBtn.textContent = '执行操作';
        actionBtn.addEventListener('click', function() {
            // 操作逻辑
            console.log('按钮被点击');
        });
        content.appendChild(actionBtn);

        container.appendChild(content);

        // ===== 事件订阅 =====
        // 示例：监听模型加载事件
        var unsub = context.eventBus.on('model:loaded', function(info) {
            // 响应模型加载
        });
        unsubscribers.push(unsub);

        return container;
    };

    /**
     * 面板显示时调用
     */
    exports.onShown = function() {
        // 面板变为可见时执行初始化或刷新
    };

    /**
     * 面板隐藏时调用
     */
    exports.onHidden = function() {
        // 面板变为不可见时执行暂停或清理
    };

    /**
     * 释放资源
     */
    exports.dispose = function() {
        // 取消所有事件订阅
        unsubscribers.forEach(function(unsub) { unsub(); });
        unsubscribers = [];
        container = null;
    };

})();
```

### 4.2 Overlay 型插件模板

#### manifest.json

```json
{
    "id": "com.author.overlay-plugin",
    "name": "插件名称",
    "version": "1.0.0",
    "type": "ui",
    "mount": "overlay",
    "author": "作者名",
    "description": "Overlay 型插件描述"
}
```

#### index.js

```javascript
/**
 * Overlay 型插件模板
 */

var exports = {};

(function() {

    var container = null;
    var unsubscribers = [];

    /**
     * 创建叠加层面板
     * @param {Object} context - 插件上下文
     * @returns {HTMLElement} 面板元素
     */
    exports.createPanel = function(context) {
        container = document.createElement('div');
        container.style.cssText = [
            'position: absolute',
            'bottom: 16px',
            'left: 16px',
            'background: rgba(30, 30, 30, 0.85)',
            'border-radius: 12px',
            'padding: 12px',
            'pointer-events: auto',
            'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3)',
            'border: 1px solid rgba(255, 255, 255, 0.1)',
            'z-index: 10',
            'color: var(--text-primary)',
            'font-size: 12px'
        ].join(';');

        // ===== 内容区 =====
        var label = document.createElement('div');
        label.textContent = '叠加层内容';
        container.appendChild(label);

        // ===== 事件订阅 =====
        var unsub = context.eventBus.on('frame:updated', function(frameInfo) {
            // 响应帧更新
        });
        unsubscribers.push(unsub);

        return container;
    };

    exports.onShown = function() {
        // 叠加层变为可见
    };

    exports.onHidden = function() {
        // 叠加层变为不可见
    };

    exports.dispose = function() {
        unsubscribers.forEach(function(unsub) { unsub(); });
        unsubscribers = [];
        container = null;
    };

})();
```

---

## 五、UI 开发技巧

### 5.1 使用宿主 UI 组件工厂

插件可以直接使用 `mp.ui` 中的宿主 UI 组件工厂创建风格一致的交互元素，无需手动创建 DOM 并应用样式类：

```javascript
// 使用宿主 Slider 组件（config 对象构造，通过 .element 访问 DOM）
var slider = new mp.ui.Slider({
    label: '强度',
    min: 0,
    max: 1,
    step: 0.01,
    value: 0.5
});
slider.onChange(function(value) {
    // 处理值变化
});
container.appendChild(slider.element);

// 使用宿主 ToggleSwitch 组件
var toggle = new mp.ui.ToggleSwitch({
    label: '启用',
    initialState: true
});
toggle.onChange(function(enabled) {
    // 处理开关变化
});
container.appendChild(toggle.element);

// 使用宿主 Dropdown 组件
var dropdown = new mp.ui.Dropdown({
    label: '选项',
    options: [
        { label: 'A', value: 'a' },
        { label: 'B', value: 'b' }
    ],
    selectedValue: 'a'
});
dropdown.onChange(function(value) {
    // 处理选择变化
});
container.appendChild(dropdown.element);

// 使用宿主 CollapsibleSection 组件
var section = new mp.ui.CollapsibleSection({
    title: '分组',
    initiallyExpanded: true
});
// 通过 getContentContainer() 获取内部容器并添加子元素
section.getContentContainer().appendChild(slider.element);
container.appendChild(section.element);

// 使用宿主 RGBColorPicker 组件
var picker = new mp.ui.RGBColorPicker({
    label: '颜色',
    color: { r: 1, g: 1, b: 1 },
    mode: 'inline'
});
picker.onChange(function(color) {
    // color = { r, g, b, a }
});
container.appendChild(picker.element);

// 使用提示消息（type 可选：info / success / error / loading）
mp.ui.toast.success('操作成功');
mp.ui.toast.error('操作失败');

// 使用确认对话框（实际签名：接收 ConfirmDialogConfig 对象）
mp.ui.showConfirmDialog({
    title: '确认',
    message: '确定要执行此操作吗？',
    confirmText: '确认',
    cancelText: '取消'
}).then(function (confirmed) {
    if (confirmed) { /* 用户点击确认 */ }
});
```

> ⚠️ **API 注意**：
> - 所有组件均使用 **config 对象**构造（`new mp.ui.Xxx(config)`），而非位置参数。
> - 通过 `component.element`（属性）获取 DOM 元素，旧版 `getElement()` 已废弃。
> - `onChange(callback)` 返回取消订阅函数；在 `dispose()` 中应调用 `component.dispose()` 释放资源（`Dropdown`、`RGBColorPicker` 等注册了全局文档事件）。

### 5.2 使用宿主样式类

宿主应用已注入以下样式类，插件可直接使用以保持视觉一致性：

```html
<!-- 按钮 -->
<button class="mp-btn">默认按钮</button>
<button class="mp-btn primary">主要按钮</button>
<button class="mp-btn danger">危险按钮</button>
<button class="mp-btn small">小按钮</button>

<!-- 输入框 -->
<input class="mp-input" type="text" placeholder="请输入...">
```

### 5.3 使用 CSS 自定义属性

```css
/* 在插件的内联样式中使用宿主主题变量 */
color: var(--text-primary);
background: var(--color-surface);
border: 1px solid var(--color-border);
border-radius: var(--radius-md);
```

### 5.4 事件订阅最佳实践

```javascript
var unsubscribers = [];

// 订阅事件时保存取消函数
var unsub = context.eventBus.on('model:loaded', handler);
unsubscribers.push(unsub);

// dispose 时统一取消
exports.dispose = function() {
    unsubscribers.forEach(function(unsub) { unsub(); });
    unsubscribers = [];
};
```

### 5.5 触摸支持

由于应用运行在移动端 WebView 中，需要同时处理鼠标和触摸事件：

```javascript
// 方式一：分别监听
element.addEventListener('click', handler);
element.addEventListener('touchstart', function(e) {
    e.preventDefault(); // 防止触发两次
    handler(e);
});

// 方式二：使用 pointer 事件（推荐）
element.addEventListener('pointerdown', handler);
```

### 5.6 动画帧循环

如果需要每帧执行逻辑，使用 `requestAnimationFrame`：

```javascript
var animationFrameId = null;

function loop() {
    // 每帧逻辑
    animationFrameId = requestAnimationFrame(loop);
}

// 开始循环
animationFrameId = requestAnimationFrame(loop);

// 停止循环（在 dispose 中调用）
exports.dispose = function() {
    if (animationFrameId !== null) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
    }
};
```

### 5.7 使用插件存储持久化设置

```javascript
exports.createPanel = function(context) {
    var container = document.createElement('div');

    // 读取保存的设置
    context.storage.get('mySettings').then(function(settings) {
        if (settings) {
            // 恢复设置
        }
    });

    // 保存设置
    function saveSettings() {
        context.storage.set('mySettings', { /* ... */ });
    }

    return container;
};
```

### 5.8 安全保存文件（mp.file.save）

UI 插件**没有文件系统权限**，不能直接写文件。若需要导出/保存文件（如烘焙结果），通过宿主的安全文件保存桥 `mp.file.save` 完成：

- 插件只发起保存请求 → 宿主弹窗询问 → 用户同意后插件上交文件 → 宿主写入。
- 写入位置为外部共享存储 `MikuPlay/PluginOutput/<插件ID>/`，用户可在文件管理器中直接访问。
- 只允许**新增**文件，绝不覆盖/修改/删除；同名冲突时宿主自动追加 `_1`、`_2`… 序号。

```javascript
// 惰性数据生成器：确认框弹出后才调用，避免昂贵的编码（如 8K 图 toBlob）阻塞确认框
mp.file.save({
    dataProducer: function () {
        return new Promise(function (resolve) {
            canvas.toBlob(function (blob) { resolve(blob); }, 'image/png');
        });
    },
    filename: 'bake-result.png',
    mime: 'image/png'
}).then(function (res) {
    if (res.ok) {
        console.log('已保存:', res.filename, res.path);
    } else if (res.canceled) {
        console.log('用户拒绝保存');
    } else {
        console.error('保存失败:', res.reason);
    }
});
```

完整入参/返回值定义与安全模型详见 [02-api-reference.md](02-api-reference.md) 的 `mp.file` 章节。

### 5.9 读取模型信息（mp.model）

UI 插件可通过宿主提供的 `mp.model` 读取当前场景中的 MMD 模型信息，用于模型下拉选择、信息展示等场景。黑名单模式下返回**真实的 `ModelInfo`**（含 `mesh`/`container` 引用），插件可自由访问模型数据。

```javascript
// 读取全部模型（返回真实 ModelInfo，含 mesh/container 引用）
var models = mp.model.list();
models.forEach(function (m) {
    console.log('模型:', m.name, 'ID:', m.id, '类型:', m.fileType);
    // m.mesh / m.container 可直接访问
});

// 按 ModelId 查询单个模型
var target = mp.model.get('model_1715xxxx');

// 订阅模型增删（返回取消函数，dispose 时应调用）
var unsub = mp.model.onChanged(function (model, added) {
    console.log(added ? '新增模型:' : '移除模型:', model.name);
});
```

> ⚠️ **注意**：
> - `mp.model` 返回真实 `ModelInfo`（含 `mesh`/`container` 引用），黑名单模式下可据此操纵场景中的模型。
> - 该 API 仅提供"读取 + 订阅"，不含导入/删除方法；模型导入/删除由用户在宿主界面完成，插件通过 `onChanged` 感知变化。
> - 完整 API 定义见 [02-api-reference.md](02-api-reference.md) 的 `mp.model` 章节。

---

## 六、开发注意事项

### 6.1 DOM 操作

- 插件通过 `document.createElement` 创建 DOM 元素
- Tab 型插件的面板会被插入到侧边面板容器中，宽度有限
- Overlay 型插件的面板会被插入到视口容器中，使用 `position: absolute` 定位
- 避免使用 `document.body.appendChild` 等操作宿主 DOM

### 6.2 内存泄漏

- 所有事件订阅必须在 `dispose()` 中取消
- 所有 `requestAnimationFrame` / `setInterval` 必须在 `dispose()` 中清除
- 所有 Babylon.js 观察者注册必须在 `dispose()` 中移除

### 6.3 性能

- Tab 型面板在隐藏时不会销毁 DOM，但 `onHidden` 中应暂停耗时操作
- Overlay 型面板始终存在，避免在其中执行重计算
- 使用 `requestAnimationFrame` 而非 `setInterval` 进行动画

### 6.4 布局约束

- Tab 型面板高度为视口减去 TopBar(48px) 和 NavBar(48px) 的剩余空间
- Tab 型面板宽度为侧边面板宽度（约 300px）
- Overlay 型面板覆盖在 3D 视口上方，不应遮挡过多视口区域
- 移动端需考虑安全区域（`env(safe-area-inset-*)`）

---

## 七、文档信息

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | §5.1 末尾"使用确认对话框"示例修正：实际签名 `mp.ui.showConfirmDialog(config: ConfirmDialogConfig) => Promise<boolean>`，入参为 `{ title, message, confirmText?, cancelText?, danger? }` 对象（而非旧的 `(title, message)` 位置参数），并补充完整的 `.then(confirmed => ...)` 用法 |
| v2.0 | 2026-08-15 | 5.9 节更新：黑名单模式下 `mp.model` 返回真实 `ModelInfo`（含 mesh/container 引用），移除"只读桥"说法 |
| v1.3 | 2026-08-13 | 新增 5.9 节：读取模型信息（`mp.model`），说明插件可通过模型只读桥读取 MMD 模型名称与 ModelId、订阅模型增删，且该 API 只读、不能导入/删除/修改模型 |
| v1.2 | 2026-08-13 | 新增 5.8 节：安全保存文件（`mp.file.save`），说明插件无文件系统权限、由宿主弹窗确认后写入 `MikuPlay/PluginOutput/<插件ID>/`、只新增不覆盖的安全模型 |
| v1.1 | 2026-08-13 | 5.1 节更新：宿主 UI 组件工厂示例改为 config 对象构造（`new mp.ui.Xxx(config)`），统一使用 `component.element` 属性访问 DOM（废弃旧版 `getElement()`）；补充 `Dropdown`、`CollapsibleSection`、`RGBColorPicker` 示例及 dispose 约定 |
| v1.0 | - | 初始版本 |
