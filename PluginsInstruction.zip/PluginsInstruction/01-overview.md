# 系统设计理念与项目模块简介

## 一、设计理念

### 1.1 核心原则

MikuPlay Reburn 是一个基于 Babylon.js + babylon-mmd 的 MMD 播放器/渲染器，采用 Capacitor 实现跨平台（Web/Android）。插件系统遵循以下设计原则：

- **开闭原则**：通过插件扩展功能，无需修改宿主代码
- **黑名单安全**：插件与宿主同 realm 运行，可自由访问场景；仅文件系统写入等极度危险操作被禁止，写文件只能经 `mp.file.save` 由宿主确认后落盘
- **统一契约**：内置功能与外部插件使用相同的接口，内置插件仅以 `builtIn: true` 标记区分
- **事件驱动**：插件间、插件与宿主间通过 EventBus 松耦合通信
- **存储隔离**：每个插件拥有独立的持久化存储命名空间

### 1.2 插件分类体系

插件系统支持两种类型，四种 target：

| 类型 | manifest.type | 说明 | 挂载方式 |
|------|--------------|------|---------|
| **功能型插件** | `functional` | 不创建 UI，由宿主自动生成控件，通过 `target` 字段声明作用模块 | 由宿主根据 `target` 自动集成 |
| **UI 型插件** | `ui` | 自建 UI，通过 `mount` 字段声明挂载位置 | `tab`（NavBar 标签页）或 `overlay`（视口叠加层） |

功能型插件根据 `target` 分为四种子类型：

| target | 说明 | 宿主集成位置 | 导出接口 | 状态 |
|--------|------|-------------|---------|------|
| `ground` | 地面插件 | 世界面板 → 地面区域 → 类型下拉框 | `FunctionalPluginExports` | 已实现 |
| `particle` | 粒子插件 | 世界面板 → 粒子区域 → 类型下拉框 | `FunctionalPluginExports` | 已实现 |
| `shading` | 着色插件 | 着色面板 → 渲染风格选择器 / 材质参数区 | `ShadingPluginExports` | 已实现（含内置 mmd-standard / pbr / toon） |
| `postproc` | 后处理插件 | 后处理面板 → 动态插件效果区域 | `PostProcessPluginExports` | 核心已实现（适配器/注册表/事件），UI 集成待实现 |
| `background` | 背景插件 | 背景面板（预留） | （未定义专用导出） | 仅类型联合预留，尚未实现具体导出校验与宿主集成 |

> 备注：`target: 'background'` 已加入 `PluginTarget` 联合类型用于未来扩展，当前 `PluginExecutor.validateExports()` 暂未为该 target 添加 shape 校验，因此即使 manifest 声明也无法被宿主识别加载；如有需求需先在 `src/core/IPlugin.ts` 与 `src/plugins/PluginExecutor.ts` 配套定义导出契约。

### 1.3 执行模型（黑名单模式）

**v2.0 起，插件不再运行在隔离沙箱中**。插件代码通过 `new Function()` 在**宿主同一 realm** 中执行，与宿主共享 `window`/`document`/全部全局对象，可自由读写场景、DOM 与全局状态。宿主唯一的防线是**黑名单**：绝不在全局暴露文件系统（`@capacitor/filesystem`）等极度危险对象；插件若要写文件，只能通过 `mp.file.save` 发起请求，由宿主弹窗确认后安全落盘（只新增、不覆盖/修改/删除）。

插件代码以严格模式执行，宿主在全局命名空间挂载以下变量，最终返回 `exports` 对象作为插件导出：

| 全局变量 | 说明 |
|---------|------|
| `context` | 插件运行上下文（PluginContext） |
| `BABYLON` | Babylon.js 核心模块（精简 re-export，详见后文列表） |
| `mp` | 宿主扩展对象（宿主主动暴露的白名单 API 面），详见下方表格 |
| `console` | 控制台（浏览器原生 console，宿主不包装、无前缀） |
| `document` | DOM 文档对象（宿主原生） |
| `window` | 窗口对象（宿主原生） |
| `setTimeout` / `clearTimeout` | 定时器（宿主原生） |
| `setInterval` / `clearInterval` | 循环定时器（宿主原生） |
| `requestAnimationFrame` / `cancelAnimationFrame` | 帧动画（宿主原生） |

> **重要**：黑名单模式下插件拥有宿主全部全局能力（含 `window` 上挂载的内部状态管理器）。这些对象属于宿主内部状态管理 API，插件可读取但不建议随意写入。

### window 透传的全局对象

宿主在 `main.ts` 中将以下对象挂载到 `window`，插件可通过 `window.xxx` 访问：

| window 属性 | 说明 | 类型 |
|-------------|------|------|
| `window.eventBus` | 全局事件总线单例（与 `context.eventBus` 同一实例） | `EventBus` |
| `window.BackgroundStateManager` | 背景状态管理器类（使用 `getInstance()` 获取单例） | `typeof BackgroundStateManager` |
| `window.GroundStateManager` | 地面状态管理器类 | `typeof GroundStateManager` |
| `window.ParticleStateManager` | 粒子状态管理器类 | `typeof ParticleStateManager` |
| `window.PostProcStateManager` | 后处理状态管理器类 | `typeof PostProcStateManager` |
| `window.ModelOptStateManager` | 模型操作状态管理器类 | `typeof ModelOptStateManager` |
| `window.WorldPanel` | 世界面板类（UI 组件） | `typeof WorldPanel` |

使用示例：
```javascript
// 通过 window 访问背景状态管理器
const bgState = window.BackgroundStateManager.getInstance().getState();
console.log('当前背景类型:', bgState.type);
```

`mp` 宿主扩展对象包含以下子对象：

| mp 子对象 | 说明 |
|-----------|------|
| `mp.particlePresetRegistry` | 粒子预设注册表，查询和注册粒子预设 |
| `mp.materialAdapterRegistry` | 材质适配器注册表，查询和注册材质适配器 |
| `mp.postProcessAdapterRegistry` | 后处理适配器注册表，查询和注册后处理适配器 |
| `mp.model` | 模型读取便利层：`list/get/count/onChanged`，返回真实 `ModelInfo`（含 mesh/container 引用） |
| `mp.file` | 安全文件保存桥：唯一的写文件入口，经宿主弹窗确认后落盘 |
| `mp.ui.Slider` | 滑块 UI 组件构造函数 |
| `mp.ui.ToggleSwitch` | 开关 UI 组件构造函数 |
| `mp.ui.Dropdown` | 下拉选择 UI 组件构造函数 |
| `mp.ui.RGBColorPicker` | RGB 颜色选择器 UI 组件构造函数 |
| `mp.ui.VectorInput` | 向量输入 UI 组件构造函数 |
| `mp.ui.CollapsibleSection` | 折叠区域 UI 组件构造函数 |
| `mp.ui.toast` | Toast 消息服务（`ToastService` 单例）：`show(message, type?, duration?)`、`info(message, duration?)`、`success(message, duration?)`、`error(message, duration?)`、`loading(message)`；均返回 `{ dismiss }` 可手动关闭；`type` ∈ `'info' \| 'success' \| 'error' \| 'loading'` |
| `mp.ui.showConfirmDialog` | 确认对话框函数：`(config: ConfirmDialogConfig) => Promise<boolean>`，入参 `{ title, message, confirmText?, cancelText?, danger? }` |
| `mp.ui.icons` | SVG 图标对象集合（按需导入 `IconRegistry` 中已注册的图标，`IconName` 导出） |

### 1.4 架构分层

```
┌─────────────────────────────────────────────────┐
│                  宿主应用层                       │
│  (UI 框架, 场景管理, 渲染管线)                     │
└──────────┬──────────────────┬────────────────────┘
           │                  │
     PluginContext        EventBus
   (依赖注入上下文)      (事件通信总线)
           │                  │
┌──────────▼──────────────────▼────────────────────┐
│              插件运行时核心                        │
│  ┌─────────────┐  ┌──────────────┐               │
│  │PluginRegistry│  │ PluginLoader │               │
│  │ (内存注册表) │◄─┤ (加载引擎)   │               │
│  └──────┬──────┘  └──────┬───────┘               │
│         │                │                        │
│  ┌──────▼──────┐  ┌──────▼───────┐               │
│  │PluginStorage│  │BuiltinPlugin │               │
│  │ (持久化存储) │  │  Registrar   │               │
│  └─────────────┘  │ (内置注册)   │               │
│                    └──────────────┘               │
└──────────────────────────────────────────────────┘
           │
     Capacitor Filesystem
     (磁盘持久化: registry.json, 插件代码, 存储数据)

扩展注册表（插件加载时动态维护）：
  ┌────────────────────────┐
  │ MaterialAdapterRegistry │  (target=shading 时注册)
  ├────────────────────────┤
  │ PostProcessAdapterRegistry│  (target=postproc 时注册)
  └────────────────────────┘
```

---

## 二、项目模块简介

> 注意：以下按逻辑模块（类/功能单元）组织，而非按文件目录。编译后的源代码文件分布与模块逻辑不完全对应。

### 2.1 核心模块 (`src/core/`)

#### EventBus（事件总线）

发布-订阅模式的事件通信总线，用于插件之间、插件与宿主之间的松耦合通信。

- **单例**：`eventBus`
- **方法**：
  - `on<T>(event, handler)` — 订阅事件，返回取消订阅函数
  - `emit<T>(event, ...args)` — 发布事件
  - `removeAll(event?)` — 移除指定事件或所有事件的订阅
- **特点**：handler 执行异常会被捕获，不影响其他 handler；使用 `Set` 存储处理器，天然去重

#### Events（事件常量）

全局事件名称常量字典，提供类型安全的事件名。详见 [02-api-reference.md](02-api-reference.md) 中的事件列表。

#### PluginLoader（插件加载器·门面）

负责插件加载 / 安装 / 卸载 / 启停的**编排门面**，本身不再包含实现细节，而是委托给一组职责单一的组件：

| 组件 | 职责 |
|------|------|
| `RegistryIO` | 注册表（`plugins/registry.json`）读写与内存缓存 |
| `PluginFileSaver` | 黑名单模式下唯一的写文件桥（弹窗确认 + 惰性数据生成） |
| `ModelReadBridge` | `mp.model` 模型读取便利层 |
| `PluginApiFactory` | 组装 `mp` 全局 API 面（宿主主动暴露的白名单） |
| `PluginExecutor` | 在宿主 realm 中执行插件代码 + 导出 shape 校验 |
| `PluginInstaller` | ZIP 解压安装（委托原生层） |

- **单例**：`pluginLoader`
- **核心方法**：
  - `loadFromDisk(contextFactory)` — 遍历注册表，逐一读取 manifest.json + index.js，经 `PluginExecutor` 执行并注册
  - `loadFromDevFolder(contextFactory)` — 从开发插件文件夹（`testPlugins/`）加载（仅 Web DEV 环境）
  - `installPlugin(sourcePath)` — 安装新插件（委托给 PluginInstaller）
  - `uninstallPlugin(pluginId)` — 卸载插件，删除插件目录、存储目录、注册条目
  - `setPluginEnabled(pluginId, enabled)` — 设置插件启用/禁用
  - `readRegistry / writeRegistry / updateRegistryEntry / removeRegistryEntry` — 注册表读写（委托 RegistryIO）
- **注册表持久化**：`plugins/registry.json`，存储每个插件的版本、启用状态、安装时间
- **着色/后处理插件自动处理**：加载 `target: 'shading'` 插件时自动注册适配器到 `materialAdapterRegistry`；加载 `target: 'postproc'` 插件时自动注册适配器到 `postProcessAdapterRegistry`；卸载时自动注销对应适配器
- **资源释放**：`PluginRegistry.disposeAll()` 在应用退出时逐个调用插件 `dispose()`，释放 setInterval / 观察者 / ObjectURL 等资源

#### PluginRegistry（插件注册表）

内存中的插件注册表，管理所有已加载插件的条目。

- **单例**：`pluginRegistry`
- **核心方法**：
  - `register(entry)` — 注册插件条目
  - `unregister(id)` — 注销插件，自动调用 `dispose()`
  - `disposeAll()` — 释放全部已注册插件（应用退出时调用，逐个 safeCall dispose）
  - `get(id)` — 按 ID 获取插件条目
  - `getByTarget(target)` — 获取指定 target 的已启用功能型插件
  - `getByType(type)` — 获取指定类型的已启用插件
  - `getByMount(mount)` — 获取指定挂载方式的已启用 UI 插件
  - `getAll()` — 获取所有插件条目
  - `safeCall(pluginId, fn, method)` — 安全调用插件方法，捕获异常
  - `notifyHosts()` — 通知宿主刷新

#### PluginStorage（插件存储）

为每个插件提供隔离的键值对持久化存储。

- **存储路径**：`plugins/_storage/${pluginId}/${key}.json`
- **核心方法**：
  - `set(key, value)` — 将值序列化为 JSON 写入
  - `get<T>(key)` — 读取并反序列化 JSON，不存在返回 undefined
  - `remove(key)` — 删除指定 key 的存储文件
  - `clear()` — 清空该插件的所有存储

#### BuiltinPluginRegistrar（内置插件注册器）

注册所有内置插件，包括地面插件、粒子插件和着色插件。

- **入口函数**：`registerBuiltinPlugins()`
- **注册的内置地面插件**（3 个）：
  - `builtin.ground.basic` — 基础地面（BasicGround）
  - `builtin.ground.reflective` — 反射地面（ReflectiveGround）
  - `builtin.ground.water` — 水面（WaterGround）
- **注册的内置粒子插件**（4 个）：从 `particlePresetRegistry` 动态获取，ID 格式为 `builtin.particle.${type}`
  - `builtin.particle.rain` — 雨滴
  - `builtin.particle.sakura` — 樱花
  - `builtin.particle.snow` — 雪花
  - `builtin.particle.basic` — 基础
- **注册的内置着色插件**（3 个）：
  - `builtin.shading.mmd-standard` — MMD 标准材质（`MmdStandardMaterialAdapter`，`typeId='mmd-standard'`，`createsMaterial=false`，`supportsOutline=true`，`supportsMorph=true`）
  - `builtin.shading.pbr` — PBR 材质（`PbrMaterialAdapter`，`typeId='pbr-advanced'`，`createsMaterial=true`，`supportsOutline=false`，`supportsMorph=false`）
  - `builtin.shading.toon` — Toon 卡通（`ToonShadingMaterialAdapter`，`typeId='toon-shading'`，`displayName='Toon卡通(Dev)'`，`createsMaterial=true`，`supportsOutline=true`，`supportsMorph=true`）

#### PostProcessAdapterRegistry（后处理适配器注册表）

管理所有已注册的后处理适配器，支持按管线顺序排序。

- **单例**：`postProcessAdapterRegistry`
- **核心方法**：
  - `register(adapter)` — 注册适配器
  - `unregister(typeId)` — 注销适配器
  - `get(typeId)` — 按类型 ID 获取适配器
  - `getAll()` — 获取所有适配器（按 `order` 升序排列，带缓存）
  - `hasAdapters()` — 是否存在已注册适配器

后处理插件（`target: 'postproc'`）在加载时自动注册适配器，卸载时自动注销。

---

### 2.2 MMD 模块 (`src/features/mmd/`)

#### ModelManager（模型管理器）

管理 MMD 模型（PMX/PMD/BPMX 格式）的加载、查询、可见性控制和删除。

- **核心方法**：
  - `loadModel(filePath, fileName, options?)` — 异步加载模型（队列串行化）
  - `deleteModel(modelId)` — 删除模型并释放资源
  - `getAllModels()` / `getModel(modelId)` / `hasModel(modelId)` — 查询
  - `setModelVisible(modelId, visible)` / `isModelVisible(modelId)` — 可见性控制
  - `setTextureDownsampleEnabled(enabled)` — 纹理降采样开关

#### AnimationManager（动画管理器）

MMD 动画的核心管理器，负责初始化 MMD 运行时（含 WASM 物理引擎）、加载 VMD 动画、控制播放。

- **核心方法**：
  - `waitForInitialization()` — 等待初始化完成
  - `createMmdModel(modelId, mmdMesh)` — 为模型创建 MmdModel 运行时实例
  - `destroyMmdModel(modelId)` — 销毁 MmdModel
  - `loadAnimation(filePath, fileName, modelId, mmdMesh)` — 加载 VMD 动画
  - `playAnimation()` / `pauseAnimation()` / `stopAnimation()` — 播放控制
  - `seekAnimation(frameTime)` — 跳转到指定帧
  - `getCurrentAnimationTime()` / `getMaxAnimationFrames()` — 帧信息查询
  - `setPhysicsPrecision(maxSubSteps, fixedTimeStep)` — 物理精度控制

#### BoneManager（骨骼管理器）

管理模型骨骼的变换操作（平移、旋转、缩放），支持骨骼变换的恢复和重置。单例模式。

- **核心方法**：
  - `applyBoneTranslation(modelId, boneName, axis, value)` — 应用骨骼平移
  - `applyBoneRotation(modelId, boneName, axis, value)` — 应用骨骼旋转
  - `applyBoneScale(modelId, boneName, axis, value)` — 应用骨骼缩放
  - `restoreBoneTransform(modelId, boneName)` — 恢复骨骼变换
  - `resetBoneTransform(modelId, boneName)` — 重置骨骼到初始状态

#### CameraManager（相机管理器）

管理 MMD 相机动画的加载、播放控制、手动控制以及身高校正。

- **核心方法**：
  - `loadCameraAnimation(filePath, fileName)` — 加载 VMD 相机动画
  - `enableManualControl()` / `disableManualControl()` — 启用/禁用手动相机控制
  - `startAnimation()` / `pauseAnimation()` / `stopAnimation()` — 动画播放控制
  - `setHeightCorrectionOffset(offset)` — 身高校正偏移
  - `getMainCamera()` / `getMmdCamera()` / `getInputManager()` — 获取器

#### MmdCameraInputManager（相机输入管理器）

统一管理 MmdCamera 的指针输入和滚轮输入，提供灵敏度、惯性和距离限制的配置接口。

#### PhysicsManager（物理管理器）

物理模拟管理器，提供物理启用/禁用、重力设置和精度控制。单例模式。

- **核心方法**：
  - `enablePhysics(modelId, enabled)` — 启用/禁用模型物理
  - `setGravity(x, y, z)` / `getGravity()` — 重力控制
  - `setPhysicsPrecision(maxSubSteps, fixedTimeStep)` — 精度控制

#### ModelStateManager（模型状态管理器）

管理导入面板的状态持久化，记录已加载的模型和动画信息。单例模式。

- **核心方法**：
  - `addModel(model)` / `removeModel(modelId)` / `getModels()` — 模型操作
  - `addAnimation(modelId, animation)` / `removeAnimation(modelId, fileName?)` — 动画操作
  - `onStateChange(callback)` — 状态变更监听

#### TextureDownsampler（纹理降采样器）

对超过 1M 像素的纹理进行降采样以减少显存占用。单例模式。

#### DownsampleMaterialBuilder（降采样材质构建器）

继承 `MmdStandardMaterialBuilder`，重写纹理加载方法以支持降采样。

---

### 2.3 场景模块 (`src/features/scene/`)

#### SceneManager（场景管理器）

负责 Babylon.js 引擎/场景/相机的初始化、渲染循环、子管理器协调和事件系统。

- **核心方法**：
  - `initialize(canvas)` — 初始化引擎、场景、MmdCamera、子管理器、渲染循环
  - `pauseScreenRender()` / `resumeScreenRender()` — 屏幕渲染暂停（用于离线渲染）
  - `setBackgroundColor(hex)` / `setGridVisible(visible)` — 场景配置
  - `getScene()` / `getEngine()` / `getCamera()` — 获取器
  - `getLightManager()` / `getParticleManager()` / `getGridManager()` — 子管理器获取

#### LightManager（光照管理器）

管理环境光（HemisphericLight）和方向光（DirectionalLight），支持欧拉角旋转方向光。

- **核心方法**：
  - `setAmbientIntensity(intensity)` / `setAmbientColor(r, g, b)` — 环境光控制
  - `setDirectionalIntensity(intensity)` / `setDirectionalColor(r, g, b)` — 方向光控制
  - `rotateDirectionalLight(angleX, angleY, angleZ)` — 通过欧拉角旋转方向光

#### PostProcessManager（后处理管理器）

管理 Babylon.js DefaultRenderingPipeline（FXAA、Bloom、曝光、对比度、饱和度）和自定义景深效果。

- **核心方法**：
  - `initialize(scene, camera, modelProvider?)` — 初始化渲染管线
  - `applyState(state)` — 批量应用后处理状态
  - `setAAEnabled(enabled)` / `setSamples(value)` — 抗锯齿控制
  - `setExposure(value)` / `setSaturation(value)` / `setContrast(value)` — 色彩调整
  - `setBloomEnabled(enabled)` / `setBloomIntensity(value)` / `setBloomThreshold(value)` — Bloom 控制
  - `setDOFEnabled(enabled)` / `setDOFBlurIntensity(value)` / `setDOFFocusDistance(value)` / `setDOFDepth(value)` — 景深控制

#### GridManager（坐标格网管理器）

创建 XYZ 坐标轴正轴使用 RGB 颜色区分的格网。

- **核心方法**：`setVisible(visible)` / `getVisible()`

#### AutoFocusController（自动对焦控制器）

计算相机到目标模型头部骨骼或包围盒中心的距离。

#### CustomDepthOfField（自定义景深）

使用三阶段着色器管线（CoC 计算 → 双向模糊 → 合成）实现景深效果。

#### MediaBackgroundManager（媒体背景管理器）

支持在场景中显示图片或视频作为背景。

- **核心方法**：
  - `setImage(uri, width, height)` / `setVideo(uri, width, height)` — 设置背景
  - `setScale(v)` / `setPosition(x, y, z)` / `setOpacity(v)` — 变换和透明度
  - `play()` / `pause()` / `setVolume(v)` — 视频播放控制

---

### 2.4 音频模块 (`src/features/audio/`)

#### MusicManager（音乐管理器）

管理音频文件的导入、播放、暂停、停止，支持与动画同步。单例模式。

- **核心方法**：
  - `importMusic(filePath, fileName)` — 导入音乐
  - `deleteMusic(musicId)` / `clearAllMusic()` — 删除音乐
  - `play()` / `pause()` / `stop()` / `seek(time)` / `setVolume(volume)` — 播放控制
  - `syncWithAnimation(animationTime)` — 与动画时间同步
  - `getCurrentMusic()` / `getMusicList()` / `getPlaybackState()` — 状态查询

---

### 2.5 粒子模块 (`src/features/particle/`)

#### ParticleManager（粒子系统管理器）

支持预设粒子效果和插件粒子效果的创建、参数更新和生命周期管理。

- **核心方法**：
  - `createPreset(type, name, initialParams?)` — 创建预设粒子系统
  - `createPluginPreset(pluginId, name, initialParams, renderConfig)` — 创建插件粒子系统
  - `updateParams(name, params)` — 更新粒子参数
  - `removeSystem(name)` / `setEnabled(name, enabled)` — 生命周期管理

#### ParticlePresetRegistry（粒子预设注册表）

定义内置预设（雨滴、樱花、雪花、基础），支持插件注册自定义预设。

- **内置预设**：
  - `rain` — 雨滴（向下发射、2000/秒、程序化纹理）
  - `sakura` — 樱花（缓慢飘落、250/秒、旋转）
  - `snow` — 雪花（缓慢飘落、500/秒、旋转）
  - `basic` — 基础（向上发射、100/秒、外部纹理）

#### ProceduralTextureManager（程序化纹理管理器）

使用 GLSL 着色器生成雨滴、樱花和雪花纹理。单例模式。

---

### 2.6 地面模块 (`src/features/ground/`)

#### BasicGround（基础地面）

支持颜色和纹理，内置 4 种纹理（混凝土/标准/木材/粗糙木材），支持法线贴图。

- **核心方法**：`create(scene, scale, height)` / `dispose()` / `setScale(scale)` / `setHeight(height)` / `setColor(r, g, b)` / `setTexturePath(path)` / `createPrivateParams()`

#### ReflectiveGround（反射地面）

使用 Babylon.js MirrorTexture 实现实时镜面反射。

- **核心方法**：`create(scene, scale, height)` / `dispose()` / `setScale(scale)` / `setHeight(height)` / `setReflectionLevel(level)` / `createPrivateParams()`

#### WaterGround（水面地面）

使用多层正弦波叠加 + 平滑噪声模拟动态水波，每帧更新顶点位置。

- **核心方法**：`create(scene, scale, height)` / `dispose()` / `setScale(scale)` / `setHeight(height)` / `setWaveAmplitude/Frequency/Speed()` / `setWaterColor(r,g,b)` / `createPrivateParams()`

---

### 2.7 着色模块 (`src/features/shading/`)

#### MaterialAdapterRegistry（材质适配器注册表）

管理所有已注册的材质适配器，支持按类型 ID 查找和按材质实例自动匹配。

- **单例**：`materialAdapterRegistry`
- **核心方法**：
  - `register(adapter)` — 注册适配器
  - `unregister(typeId)` — 注销适配器
  - `get(typeId)` — 按类型 ID 获取适配器
  - `findAdapter(material)` — 根据材质实例自动查找适配器
  - `getAll()` — 获取所有适配器
  - `hasMaterialCreatingAdapters()` — 是否存在 `createsMaterial=true` 的适配器
  - `getMaterialCreatingAdapters()` — 获取所有 `createsMaterial=true` 的适配器

#### MmdStandardMaterialAdapter（MMD 标准材质适配器）

内置适配器，处理 `MmdStandardMaterial` 的参数读写和控件声明。

- **属性**：`typeId = 'mmd-standard'`、`createsMaterial = false`、`supportsOutline = true`、`supportsMorph = true`
- **控件声明**：扩散色、环境色、反射色+强度、自发光+强度、Alpha+混合模式、单双面、Spa贴图

#### PbrMaterialAdapter（PBR 材质适配器）

内置适配器，将材质风格切换为 PBR（`PBRMaterial`），实现基于物理的渲染。

- **属性**：`typeId = 'pbr-advanced'`、`createsMaterial = true`、`supportsOutline = false`、`supportsMorph = false`
- **集成**：`createsMaterial = true`，会在着色面板顶部"渲染风格"选择器中显示

#### ToonShadingMaterialAdapter（Toon 卡通适配器）

内置适配器，提供卡通（Toon）着色风格的材质创建。

- **属性**：`typeId = 'toon-shading'`、`displayName = 'Toon卡通(Dev)'`、`createsMaterial = true`、`supportsOutline = true`、`supportsMorph = true`
- **集成**：`createsMaterial = true`，会在着色面板顶部"渲染风格"选择器中显示
- **依赖**：自定义 GLSL 实现 `ShaderMaterial`，集成自阴影接收（与项目 `ShadowGenerator` 协同，按 filteringQuality 切换 PCF1/PCF3/PCF5）、边缘光参数（`rimLightWidth`/`rimLightIntensity`，共享全局 `ToonShadingSharedParams`）、`normalMap` 变体贴图（每材质作用域）
- **共享风格参数**：rimLightWidth / rimLightIntensity / ambient / unlit 通过 `ToonShadingSharedParams` 全局单例同步到所有 toon 材质

---

### 2.8 渲染模块 (`src/features/render/`)

#### RenderManager（渲染管理器）

协调实时渲染和离线渲染，管理 UI 面板和进度对话框。

#### RealtimeRenderManager（实时渲染管理器）

使用屏幕录制方式录制动画播放过程。

#### OfflineRenderManager（离线渲染管理器）

逐帧渲染动画并通过 HTTP 服务器保存帧序列，支持 PBO 异步像素读取。仅支持原生平台。

---

### 2.9 状态管理模块 (`src/features/state/`)

所有状态管理器继承自 `StateStore<T>` 抽象基类，提供统一的发布-订阅模式。

#### StateStore\<T\>（抽象状态存储基类）

- **核心方法**：
  - `subscribe(listener)` — 订阅状态变化，返回取消订阅函数
  - `getState()` — 获取只读状态
  - `update(partial, eventName?, eventPayload?)` — 更新状态（浅合并），通知监听器

#### 各状态管理器

| 管理器 | 管理的状态 | 关键事件 |
|--------|-----------|---------|
| BackgroundStateManager | 背景类型、环境贴图、媒体设置 | `background:type_changed`, `background:color_changed` |
| GroundStateManager | 地面类型、缩放、高度 | `ground:type_changed`, `ground:scale_changed`, `ground:height_changed` |
| ModelOptStateManager | 骨骼变换模式/轴向、变形权重、模型可见性 | `model:selected` |
| ParticleStateManager | 粒子系统类型、启用状态、参数 | `particle:system_changed`, `particle:params_changed` |
| PostProcStateManager | 抗锯齿、曝光、饱和度、对比度、Bloom、景深 | `postproc:changed` |
| ShadingStateManager | 材质参数（通用 ParamValue）、渲染风格、描边属性 | `shading:material_changed` |

---

### 2.10 UI 组件模块 (`src/UIComponents/`)

#### MainWindow（主界面）

三段式布局（TopBar 48px + 视口 + NavBar 48px），是整个应用的根容器和协调者。

- **核心方法**：
  - `createPluginContext(pluginId)` — 为插件创建 PluginContext
  - `mountPluginOverlays()` — 挂载 overlay 型插件
  - `registerPluginTabs()` — 注册 tab 型插件到 NavBar
  - `getSceneManager()` / `getModelManager()` / `getAnimationManager()` / `getCameraManager()` / `getMusicManager()` — 获取管理器

#### NavBar（导航栏）

底部导航栏，管理多个功能面板的切换。支持插件动态注册 Tab。

- **核心方法**：
  - `registerPanel(registration)` — 注册面板
  - `unregisterPanel(id)` — 注销面板
  - `registerPluginTab(entry, mainWindow)` — 注册插件 Tab

#### TopBar（顶部工具栏）

包含菜单按钮、性能监测、动画控制按钮（播放/暂停/停止/全屏/渲染）。

#### SidePanel（侧边菜单）

包含性能监测开关、纹理降采样开关、物理模拟开关、物理精度控制、重力控制、插件管理。

#### 共享 UI 组件

所有共享组件实现统一的 `ISharedComponent<TConfig, TValue>` 接口：

| 组件 | 值类型 | 说明 |
|------|--------|------|
| Slider | `number` | 滑块控件 |
| ToggleSwitch | `boolean` | 开关切换 |
| Dropdown | `string` | 下拉选择器 |
| CollapsibleSection | `boolean` | 可折叠区域 |
| RGBColorPicker | `{r,g,b,a}` | RGB 颜色选择器 |
| VectorInput | `number[]` | 向量输入（XYZ 等） |

详见 [02-api-reference.md](02-api-reference.md)。

---

### 2.11 工具模块 (`src/utils/`)

| 工具 | 说明 |
|------|------|
| `generateId(prefix)` | 生成唯一 ID |
| `rgbToHex(r, g, b)` / `hexToRgb(hex)` / `hexToColor4(hex, alpha?)` | 颜色转换 |
| `isValidModelFile(fileName)` / `isValidVmdFile(fileName)` / `isValidMusicFile(fileName)` / `isValidImageFile(fileName)` | 文件验证 |
| `formatFileSize(bytes)` / `formatDuration(seconds)` | 格式化 |
| `lerp(a, b, t)` / `clamp(value, min, max)` / `makeEven(value)` | 数学工具 |
| `checkFullscreenState()` / `enterFullscreen()` / `exitFullscreen()` | 全屏控制 |
| `convertFilePathToUrl(filePath)` | Capacitor 文件路径转 WebView URL |
| `FilePathMemory` | 文件路径记忆管理器 |

---

### 2.12 原生桥接模块 (`src/plugins/`)

| 插件 | 说明 |
|------|------|
| PluginInstaller | 插件安装器，调用 Android 原生端执行 ZIP 解压 |
| FilePicker | 跨平台文件选择器 |
| MediaPicker | 原生平台媒体选择器 |
| OfflineRender | 离线渲染 HTTP 服务器控制 |
| ScreenRecorder | 屏幕录制管理器 |
| VideoComposePlugin | 视频合成（帧序列合成视频 + 背景音乐合成） |

---

### 2.13 样式模块 (`src/styles/`)

采用"CSS-in-JS 字符串 + StyleManager 去重注入"模式，所有样式通过 `theme` 对象统一管理。

#### StyleManager（样式管理器）

- **单例**：`styleManager`
- **方法**：`inject(id, styles)` / `remove(id)` / `has(id)` / `clear()`
- **便捷函数**：`injectStyles(styles, id)`

#### Theme（主题变量）

- **颜色**：`accentColor: '#FF6699'`、`backgroundColor: '#f5f5f5'`、`surfaceColor: '#ffffff'`、`borderColor: '#e0e0e0'`、`textPrimary: '#212121'`、`textSecondary: '#616161'`、`textDisabled: '#bdbdbd'`
- **辅助色**：`hoverBg`、`activeBg`、`focusBg`、`overlayBg`、`errorColor`、`accentHover`
- **坐标轴色**：X 红、Y 绿、Z 蓝、W 黄
- **尺寸**：`topBarHeight: '48px'`、`navBarHeight: '48px'`、`touchTargetMin: '48px'`
- **圆角**：`borderRadius: '12px'`、`borderRadiusSm: '8px'`、`borderRadiusLg: '16px'`
- **动画**：`transitionFast: '0.2s ease'`、`transitionNormal: '0.3s ease'`
- **阴影**：`shadowSm`、`shadowMd`、`shadowLg`
- **工具函数**：`createTransition(properties, duration?)`、`rgba(hex, alpha)`

---

## 三、插件可访问对象总览

本章节汇总插件可访问的所有对象来源（宿主全局命名空间 + window 透传），以便开发时快速查阅。

### 3.1 全局命名空间对象

| 对象路径 | 类型 | 说明 | 来源文件 |
|---------|------|------|---------|
| `context` | `PluginContext` | 插件运行上下文 | `src/core/IPlugin.ts` |
| `context.scene` | `BABYLON.Scene` | Babylon.js 场景实例 | `src/UIComponents/MainWindow.ts` |
| `context.engine` | `BABYLON.Engine` | Babylon.js 引擎实例 | 同上 |
| `context.eventBus` | `EventBus` | 事件总线（与 window.eventBus 同一实例） | 同上 |
| `context.storage` | `PluginStorage` | 插件隔离存储（命名空间为 pluginId） | 同上 |
| `context.assetsDir` | `string` | 插件资源目录 URL（WebView 可访问） | `src/plugins/PluginLoader.ts` |
| `context.app` | `PluginAppContext` | 应用级上下文 | `src/UIComponents/MainWindow.ts` |
| `context.app.getScene()` | `() => Scene` | 获取场景（与 context.scene 一致） | |
| `context.app.getEngine()` | `() => Engine` | 获取引擎（与 context.engine 一致） | |
| `context.app.getAnimationManager()` | `() => AnimationManager \| null` | 获取动画管理器（真实实例） | |
| `context.app.getMusicManager()` | `() => MusicManager \| null` | 获取音乐管理器（真实实例） | |
| `context.app.getModelManager()` | `() => ModelManager \| null` | 获取模型管理器（黑名单模式下返回真实实例，含 mesh/container 引用） | |
| `BABYLON` | `object` | Babylon.js 精简 re-export 模块 | `src/plugins/babylon-reexport.ts` |
| `mp` | `object` | 宿主扩展对象（白名单 API 面） | `src/plugins/PluginApiFactory.ts` |
| `mp.particlePresetRegistry` | `object` | 粒子预设注册表 | 同上 |
| `mp.materialAdapterRegistry` | `object` | 材质适配器注册表 | 同上 |
| `mp.postProcessAdapterRegistry` | `object` | 后处理适配器注册表 | 同上 |
| `mp.model.list/get/count/onChanged` | `PluginModelApi` | 模型读取便利层（返回真实 ModelInfo） | `src/plugins/ModelReadBridge.ts` |
| `mp.file.save` | `function` | 安全文件保存桥（唯一写文件入口） | `src/plugins/PluginFileSaver.ts` |
| `mp.ui.*` | `object` | 共享 UI 组件工厂（共 9 项） | `src/UIComponents/shared/index.ts` |
| `console` | `Console` | 浏览器原生 console（宿主不包装，无前缀） | 宿主 realm |
| `document` | `Document` | DOM 文档对象（浏览器原生全局） | 宿主 realm |
| `window` | `Window` | 窗口对象（浏览器原生全局，含宿主挂载对象） | 宿主 realm |
| `setTimeout/clearTimeout` | `function` | 定时器（浏览器原生全局） | 宿主 realm |
| `setInterval/clearInterval` | `function` | 循环定时器（浏览器原生全局） | 宿主 realm |
| `requestAnimationFrame/cancelAnimationFrame` | `function` | 帧动画（浏览器原生全局） | 宿主 realm |

### 3.2 window 透传对象（宿主挂载）

| `window.xxx` | 说明 | 访问模式 |
|-------------|------|---------|
| `eventBus` | 全局事件总线（与 context.eventBus 相同） | 只读 + 调用方法 |
| `BackgroundStateManager` | 背景状态管理器类（Singleton，`getInstance()`） | 读状态 / 订阅 |
| `GroundStateManager` | 地面状态管理器类 | 读状态 / 订阅 |
| `ParticleStateManager` | 粒子状态管理器类 | 读状态 / 订阅 |
| `PostProcStateManager` | 后处理状态管理器类 | 读状态 / 订阅 |
| `ModelOptStateManager` | 模型操作状态管理器类 | 读状态 / 订阅 |
| `WorldPanel` | 世界面板 UI 类 | 一般无需直接使用 |

> ⚠️ 以上状态管理器对象属于宿主内部 API，虽可访问但**不建议插件调用其 `update()` 方法修改状态**，推荐仅用于读取状态或通过 `subscribe()` 监听变更。若要修改状态，应通过 `context.eventBus.emit()` 发布事件触发宿主侧更新。

### 3.3 BABYLON 模块实际导出清单

`BABYLON` 是精简 re-export（非完整 @babylonjs/core），实际包含以下内容：

| 分类 | 导出项 |
|------|--------|
| 数学类型 | `Vector3`, `Vector2`, `Vector4`, `Matrix`, `Quaternion`, `TmpVectors`, `Color3`, `Color4` |
| 场景核心 | `Scene`, `Engine` |
| 网格/节点 | `Mesh`, `MeshBuilder`, `AbstractMesh`, `TransformNode` |
| 材质/纹理 | `StandardMaterial`, `Material`, `PBRMaterial`, `Texture`, `CubeTexture`, `BaseTexture` |
| 光源 | `Light`, `DirectionalLight`, `HemisphericLight`, `PointLight`, `SpotLight` |
| Gizmo | `GizmoManager` |
| 相机 | `Camera`, `FreeCamera`, `ArcRotateCamera` |
| 粒子 | `ParticleSystem`, `ParticleSystemSet` |
| 动画 | `Animation`, `AnimationGroup` |
| 后处理/着色器 | `PostProcess`, `Effect` |
| 工具/事件 | `Tools`, `Observable`, `PointerEventTypes` |

> ⚠️ **注意**：文档旧版列出的 `BABYLON.GPUParticleSystem` **并未在 re-export 中导出**，插件中不可使用。请使用 `BABYLON.ParticleSystem`。

---

## 四、插件不可访问对象（黑名单边界）

黑名单模式下插件与宿主同 realm，**在技术上几乎能访问一切**。本节说明的是"宿主**没有**暴露、插件**不应**依赖"的对象，以及唯一被真正禁止的能力——文件系统写入。

### 4.1 文件系统写入（唯一被禁止的能力）

插件**不能直接写文件系统**：宿主绝不把 `@capacitor/filesystem` 挂到全局。写文件只能通过 `mp.file.save` 发起请求，由宿主弹窗确认后安全落盘到 `MikuPlay/PluginOutput/<插件ID>/`（只新增、不覆盖/修改/删除）。详见 [02-api-reference.md](02-api-reference.md) 的 `mp.file` 章节。

### 4.2 Node.js 运行时 API

插件运行在浏览器/WebView 环境中，**所有 Node.js 原生 API 均不可用**（这与沙箱无关，是运行环境本身决定的）：

| 类别 | 不可用 API |
|------|-----------|
| 模块系统 | `require()`, `module` |
| 进程 | `process`, `global` |
| 文件系统 | `fs`, `path`, `os`, `crypto` 等 Node 内置模块 |
| Buffer | `Buffer` 类（可用 `Uint8Array` 替代） |
| 包管理 | `__dirname`, `__filename`, `import()`（不可动态导入宿主源码） |

> 文件持久化请使用 `context.storage`；插件资源文件请通过 `context.assetsDir` 拼接 URL 加载。

### 4.3 未暴露的管理器

`PluginAppContext` 通过 getter 暴露了 `Scene/Engine/AnimationManager/MusicManager/ModelManager`。其余管理器未提供访问入口，**不建议依赖**：

| 未暴露对象 | 说明 | 替代方案 |
|-----------|------|---------|
| `CameraManager` | 相机管理器 | 通过 `context.scene.activeCamera` 获取相机实例并操作 |
| `PhysicsManager` | 物理管理器 | 订阅 `physics:toggled`、`gravity:changed` 事件 |
| `BoneManager` | 骨骼管理器 | 必要时直接操作 mesh.skeleton |
| `SceneManager` | 场景管理器 | `context.app.getScene()` / `context.scene` 替代 |
| `LightManager` | 光照管理器 | 通过 `context.scene.lights` 数组访问场景光源 |
| `PostProcessManager` | 后处理管理器 | 使用 `POSTPROC_*` 事件；插件自然后处理走 `IPostProcessAdapter` |
| `ParticleManager` | 粒子管理器 | 粒子插件通过 `preset` + 宿主自动创建，无需直接访问 |
| `GridManager` | 格网管理器 | 通过 `context.scene` 自行查找或创建网格 |
| `ProjectSaveManager` | 项目存档管理器 | 暂无暴露方式 |

### 4.4 Capacitor 原生插件 API

`@capacitor/*` 系列原生插件未挂到全局命名空间：

| 不可用 API | 说明 | 替代方案 |
|-----------|------|---------|
| `@capacitor/filesystem` | 文件系统 | `mp.file.save`（写）、`context.storage`（插件存储）、`context.assetsDir`（只读资源） |
| `@capacitor/dialog` / `toast` | 对话框 | `mp.ui.toast`, `mp.ui.showConfirmDialog` |
| `@capacitor/preferences` | 偏好设置 | `context.storage` |
| 其他 Capacitor 插件 | 网络、设备、剪贴板等 | 通过 `window` 访问可用标准 Web API |

> 若确需 Capacitor 原生能力（如文件选择），应使用宿主暴露的 `mp` 对象功能。

### 4.5 宿主源码模块导入

项目的 TypeScript 源码模块（`src/**/*`）通过编译打包后运行。插件代码中**不支持** `import` / `require` 导入宿主源码：

```javascript
// ❌ 以下写法均无效
import { ModelManager } from './features/mmd/ModelManager';
const mm = require('./features/mmd/ModelManager');
```

> 所有对宿主能力的访问必须通过宿主挂载的 `context`、`BABYLON`、`mp`、`window` 四个入口进行。

---

## 五、变更记录

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | §1.2 表格补充 `target: 'background'` 行（仅类型联合预留，暂无具体导出契约）；§1.3 `mp.ui` 表更新 toast 实际签名（`show/info/success/error/loading` 五个方法，返回 `{dismiss}`）与 `showConfirmDialog` 实际签名（接收 `ConfirmDialogConfig` 对象而非位置参数）；§2.7 Toon 适配器属性校正（`displayName='Toon卡通(Dev)'`、`supportsMorph=true`、`createsMaterial=true`），补充边缘光/共享参数/阴影 PCF 等级（PCF1/PCF3/PCF5）说明 |
| v2.0 | 2026-08-15 | 插件系统重构为**黑名单模式**：放弃沙箱隔离，插件与宿主同 realm 运行、可自由访问场景；仅文件系统写入被禁止（走 `mp.file.save`）。`PluginLoader` 拆分为 `RegistryIO` / `PluginFileSaver` / `ModelReadBridge` / `PluginApiFactory` / `PluginExecutor` 等职责单一组件；`context.app.getModelManager()` 返回真实 `ModelManager`；`mp.model` 返回含 mesh/container 引用的真实 `ModelInfo`（不再做 DTO 伪装）；新增 `PluginRegistry.disposeAll()` 与应用退出时的资源释放 |
| v1.1 | 2026-08-12 | 新增"window 透传全局对象"说明；新增"插件可访问对象总览"与"插件不可访问对象"章节；修正 BABYLON 导出清单（移除不存在的 GPUParticleSystem，补充遗漏导出项）；标注 StateManager 建议只读 |
| v1.0 | - | 初始版本 |
