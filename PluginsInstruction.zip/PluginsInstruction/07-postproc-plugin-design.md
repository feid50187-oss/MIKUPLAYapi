# 后处理插件系统

## 一、实施状态

后处理插件系统已部分实现，核心基础设施已完成，UI 集成部分待完成。

### 实现进度

| 组件 | 状态 | 
|------|------|
| `IPostProcessAdapter` 接口 | ✅ 已实现 | 
| `PostProcessAdapterRegistry` | ✅ 已实现 |
| `PostProcessPluginExports` 类型 | ✅ 已实现 | 
| 事件常量 (`POSTPROC_ADAPTER_REGISTERED` / `UNREGISTERED`) | ✅ 已实现 |
| PluginLoader 集成（注册/注销适配器） | ✅ 已实现 | 
| 宿主暴露 `mp.postProcessAdapterRegistry` | ✅ 已实现 |
| `src/core/index.ts` 导出 | ✅ 已实现 |
| `BuiltinPluginRegistrar` 内置后处理插件注册 | ❌ 未注册（无内置 postproc 适配器，需通过 `installPlugin` 安装外部插件） |
| PostProcPanel 动态插件效果区域 UI | ❌ 待实现 |

---

## 二、架构概述

### 2.1 整体架构

```
插件代码 (index.js)
    │ exports.adapter = new MyPostProcessAdapter()
    ▼
PluginLoader (检测 target === 'postproc')
    │ postProcessAdapterRegistry.register(adapter)
    │ eventBus.emit(POSTPROC_ADAPTER_REGISTERED)
    ▼
PostProcPanel (监听事件) ← 待实现
    │ 动态生成适配器控件区域
    ▼
PostProcessAdapter (插件实现)
    │ initialize(scene, camera) → 创建 PostProcess
    │ writeState(state) → 应用参数
    │ dispose() → 释放资源
```

### 2.2 IPostProcessAdapter 接口

定义在 `src/core/IPostProcessAdapter.ts`：

```typescript
interface IPostProcessAdapter {
    readonly typeId: string;              // 适配器唯一标识
    readonly displayName: string;         // 显示名称
    readonly order: number;               // 管线顺序

    getControlDeclarations(): ControlDeclaration[];
    getDefaultState(): Record<string, ParamValue>;
    readState(): Record<string, ParamValue>;
    writeState(state: Record<string, ParamValue>): void;

    initialize(scene: Scene, camera: Camera): void;
    isInitialized(): boolean;
    setEnabled(enabled: boolean): void;
    isEnabled(): boolean;
    dispose(): void;
}
```

**设计要点**：

- **`order` 属性**：后处理效果有执行顺序依赖，`order` 值越小越先执行。内置效果使用 10 的倍数作为基准，插件可在任意间隙插入
- **无 `canHandle` 方法**：后处理适配器不需要匹配特定对象，注册即生效
- **`initialize` 延迟调用**：仅在用户首次启用效果时创建 GPU 资源
- **`readState` / `writeState` 无 material 参数**：后处理效果是全局的，不绑定到特定材质

### 2.3 内置效果 order 基准值

| 效果 | order | 说明 |
|------|-------|------|
| FXAA / MSAA | 0 | 抗锯齿最先执行 |
| ImageProcessing (曝光/饱和度/对比度) | 10 | 色调调整 |
| Bloom | 20 | 泛光 |
| 插件效果 | 用户定义 | 可在任意间隙插入 |
| DOF | 30 | 景深最后执行 |

---

## 三、插件开发

### 3.1 后处理插件接口

后处理插件使用 `PostProcessPluginExports` 导出接口：

```javascript
exports.adapter = new MyEffectAdapter();

// 可选的生命周期方法
exports.onActivate = function(ctx) { /* 插件激活时调用 */ };
exports.onDeactivate = function(ctx) { /* 插件停用时调用 */ };
exports.dispose = function() { /* 释放资源 */ };
```

宿主在加载后处理插件时会自动将 `adapter` 注册到 `postProcessAdapterRegistry`，卸载时自动注销并调用 `adapter.dispose()`。

### 3.2 manifest.json

```json
{
    "id": "com.author.postproc-effect-name",
    "name": "效果名称",
    "version": "1.0.0",
    "type": "functional",
    "target": "postproc",
    "author": "作者名",
    "description": "后处理效果描述"
}
```

### 3.3 完整示例：自定义后处理效果

#### index.js

```javascript
/**
 * 后处理插件示例
 */

var exports = {};

(function() {

    // ========== 后处理适配器 ==========
    var MyEffectAdapter = function() {
        this.typeId = 'my-effect';           // 全局唯一标识
        this.displayName = '我的效果';        // 显示名称
        this.order = 25;                      // 管线顺序（20=Bloom之后, 30=DOF之前）
        this._scene = null;
        this._camera = null;
        this._postProcess = null;
        this._enabled = false;
        this._initialized = false;
        this._state = {
            intensity: 0.5,
            enabled: false
        };
    };

    /**
     * 声明参数控件
     */
    MyEffectAdapter.prototype.getControlDeclarations = function() {
        return [
            { param: 'enabled', type: 'toggle', label: '启用', group: '我的效果' },
            { param: 'intensity', type: 'slider', label: '强度', min: 0, max: 1, step: 0.01, group: '我的效果' }
        ];
    };

    /**
     * 获取参数默认值
     */
    MyEffectAdapter.prototype.getDefaultState = function() {
        return {
            enabled: false,
            intensity: 0.5
        };
    };

    /**
     * 读取当前参数状态
     */
    MyEffectAdapter.prototype.readState = function() {
        return {
            enabled: this._enabled,
            intensity: this._state.intensity
        };
    };

    /**
     * 写入参数状态
     */
    MyEffectAdapter.prototype.writeState = function(state) {
        if (state.enabled !== undefined) {
            this.setEnabled(state.enabled);
        }
        if (state.intensity !== undefined) {
            this._state.intensity = state.intensity;
            if (this._postProcess) {
                this._postProcess.onApply = function(effect) {
                    effect.setFloat('uIntensity', state.intensity);
                };
            }
        }
    };

    /**
     * 初始化后处理效果（创建 PostProcess 并附加到相机）
     */
    MyEffectAdapter.prototype.initialize = function(scene, camera) {
        if (this._initialized) return;

        this._scene = scene;
        this._camera = camera;

        this._postProcess = new BABYLON.PostProcess(
            'myEffect',
            'myEffectShader',    // 需要先注册着色器到 Effect.ShadersStore
            ['uIntensity'],      // uniforms
            [],                  // samplers
            1.0,                 // 缩放比
            camera,
            BABYLON.Texture.BILINEAR_SAMPLINGMODE,
            scene.getEngine()
        );

        this._postProcess.onApply = function(effect) {
            effect.setFloat('uIntensity', this._state.intensity);
        }.bind(this);

        // 初始状态为禁用
        if (!this._enabled) {
            this._camera.detachPostProcess(this._postProcess);
        }

        this._initialized = true;
    };

    /**
     * 是否已初始化
     */
    MyEffectAdapter.prototype.isInitialized = function() {
        return this._initialized;
    };

    /**
     * 启用/禁用效果
     */
    MyEffectAdapter.prototype.setEnabled = function(enabled) {
        this._enabled = enabled;
        if (!this._initialized || !this._postProcess) return;

        if (enabled) {
            this._camera.attachPostProcess(this._postProcess);
        } else {
            this._camera.detachPostProcess(this._postProcess);
        }
    };

    /**
     * 当前是否启用
     */
    MyEffectAdapter.prototype.isEnabled = function() {
        return this._enabled;
    };

    /**
     * 释放所有资源
     */
    MyEffectAdapter.prototype.dispose = function() {
        if (this._postProcess) {
            if (this._camera) {
                this._camera.detachPostProcess(this._postProcess);
            }
            this._postProcess.dispose(this._camera);
            this._postProcess = null;
        }
        this._scene = null;
        this._camera = null;
        this._initialized = false;
    };

    // ========== 导出 ==========
    exports.adapter = new MyEffectAdapter();

})();
```

### 3.4 完整示例：使用自定义 GLSL 着色器

```javascript
/**
 * 色差后处理插件 - 使用自定义 GLSL 着色器
 */

var exports = {};

(function() {

    // 注册着色器（在 initialize 中完成亦可）
    BABYLON.Effect.ShadersStore['chromaticFragmentShader'] = `
        precision mediump float;
        varying vec2 vUV;
        uniform sampler2D textureSampler;
        uniform float uStrength;
        void main() {
            vec2 offset = (vUV - 0.5) * uStrength;
            float r = texture2D(textureSampler, vUV + offset).r;
            float g = texture2D(textureSampler, vUV).g;
            float b = texture2D(textureSampler, vUV - offset).b;
            gl_FragColor = vec4(r, g, b, 1.0);
        }
    `;

    var ChromaticAdapter = function() {
        this.typeId = 'chromatic-aberration';
        this.displayName = '色差效果';
        this.order = 25;
        this._scene = null;
        this._camera = null;
        this._postProcess = null;
        this._enabled = false;
        this._initialized = false;
        this._strength = 0.01;
    };

    ChromaticAdapter.prototype.getControlDeclarations = function() {
        return [
            { param: 'enabled', type: 'toggle', label: '启用', group: '色差' },
            { param: 'strength', type: 'slider', label: '强度', min: 0, max: 0.05, step: 0.001, group: '色差' }
        ];
    };

    ChromaticAdapter.prototype.getDefaultState = function() {
        return { enabled: false, strength: 0.01 };
    };

    ChromaticAdapter.prototype.readState = function() {
        return { enabled: this._enabled, strength: this._strength };
    };

    ChromaticAdapter.prototype.writeState = function(state) {
        if (state.enabled !== undefined) this.setEnabled(state.enabled);
        if (state.strength !== undefined) {
            this._strength = state.strength;
            if (this._postProcess) {
                this._postProcess.onApply = function(effect) {
                    effect.setFloat('uStrength', state.strength);
                };
            }
        }
    };

    ChromaticAdapter.prototype.initialize = function(scene, camera) {
        if (this._initialized) return;
        this._scene = scene;
        this._camera = camera;

        this._postProcess = new BABYLON.PostProcess(
            'chromatic',
            'chromatic',           // 对应 Effect.ShadersStore 中的 'chromaticFragmentShader'
            ['uStrength'],
            [],
            1.0,
            camera,
            BABYLON.Texture.BILINEAR_SAMPLINGMODE,
            scene.getEngine()
        );

        this._postProcess.onApply = (function(effect) {
            effect.setFloat('uStrength', this._strength);
        }).bind(this);

        if (!this._enabled) {
            this._camera.detachPostProcess(this._postProcess);
        }
        this._initialized = true;
    };

    ChromaticAdapter.prototype.isInitialized = function() { return this._initialized; };
    ChromaticAdapter.prototype.isEnabled = function() { return this._enabled; };

    ChromaticAdapter.prototype.setEnabled = function(enabled) {
        this._enabled = enabled;
        if (!this._initialized || !this._postProcess) return;
        if (enabled) {
            this._camera.attachPostProcess(this._postProcess);
        } else {
            this._camera.detachPostProcess(this._postProcess);
        }
    };

    ChromaticAdapter.prototype.dispose = function() {
        if (this._postProcess) {
            if (this._camera) this._camera.detachPostProcess(this._postProcess);
            this._postProcess.dispose(this._camera);
            this._postProcess = null;
        }
        this._scene = null;
        this._camera = null;
        this._initialized = false;
    };

    exports.adapter = new ChromaticAdapter();

})();
```

---

## 四、开发注意事项

### 4.1 管线顺序

后处理效果的执行顺序至关重要。错误的顺序可能导致：
- 先色调映射再泛光 → 泛光效果被压缩
- 先 DOF 再抗锯齿 → 模糊边缘被抗锯齿平滑

插件开发者应合理设置 `order` 值，参考内置效果的基准值（0=FXAA, 10=ImageProcessing, 20=Bloom, 30=DOF）。

### 4.2 延迟初始化

后处理效果占用 GPU 资源，应遵循延迟初始化原则：
- `initialize()` 仅在用户首次启用效果时调用
- 禁用效果时仅 detach PostProcess，不 dispose
- 仅在插件卸载时调用 `dispose()`

### 4.3 自定义着色器

插件如需使用自定义 GLSL 着色器，需在 `initialize()` 中（或模块级作用域中）注册到 `Effect.ShadersStore`：

```javascript
BABYLON.Effect.ShadersStore['myEffectFragmentShader'] = `
    precision mediump float;
    varying vec2 vUV;
    uniform sampler2D textureSampler;
    uniform float uIntensity;
    void main() {
        vec4 color = texture2D(textureSampler, vUV);
        gl_FragColor = color * uIntensity;
    }
`;
```

着色器命名规则：`${shaderName}FragmentShader`，在 `new BABYLON.PostProcess(name, shaderName, ...)` 中使用 `shaderName` 部分。

### 4.4 资源释放

- `dispose()` 必须从相机 detach 所有 PostProcess 并释放
- 使用 `scene.onBeforeRenderObservable` 等观察者时，务必在 `dispose()` 中取消注册
- 共享纹理（如深度纹理）不要在 `dispose()` 中释放

### 4.5 与内置效果共存

- 插件效果与内置效果（FXAA、Bloom、DOF 等）共存
- 插件效果附加到相机时，Babylon.js 会按附加顺序执行
- 建议插件效果在 DOF 之前执行（order < 30），除非有特殊需求

### 4.6 PostProcPanel UI 集成（待实现）

目前后处理插件的 PostProcPanel 动态插件效果区域尚未实现。待实施的方案：

**改造策略**：保留内置效果的硬编码 UI，在面板底部动态添加插件效果区域。

```
PostProcPanel
├── 内置：FXAA 抗锯齿（保持原样）
├── 内置：风格滤镜（保持原样）
├── 内置：Bloom（保持原样）
├── 内置：景深 (DoF)（保持原样）
└── 动态：插件效果区域
    ├── 插件效果 A（collapsible，控件由 adapter.getControlDeclarations() 生成）
    ├── 插件效果 B（collapsible）
    └── ...
```

**动态控件生成逻辑**（参照 `MaterialParamsSection`）：
1. 监听 `POSTPROC_ADAPTER_REGISTERED` / `POSTPROC_ADAPTER_UNREGISTERED` 事件
2. 收到注册事件时，为该适配器创建折叠区域
3. 根据 `getControlDeclarations()` 生成控件，支持 `group` 分组
4. 控件值变更时调用 `adapter.writeState(state)` 应用参数
5. 收到注销事件时，移除对应区域并调用 `adapter.dispose()`

---

## 五、API 参考

### PostProcessAdapterRegistry

定义在 `src/features/postproc/PostProcessAdapterRegistry.ts`，单例 `postProcessAdapterRegistry`。

| 方法 | 说明 |
|------|------|
| `register(adapter)` | 注册适配器 |
| `unregister(typeId)` | 注销适配器 |
| `get(typeId)` | 按类型 ID 获取适配器 |
| `getAll()` | 获取所有适配器（按 `order` 升序排列，带缓存） |
| `hasAdapters()` | 是否存在已注册适配器 |

### 宿主暴露的 mp.postProcessAdapterRegistry

后处理插件代码中通过 `mp.postProcessAdapterRegistry` 访问该注册表：

```javascript
// 在插件代码中查询已注册的后处理适配器
var allAdapters = mp.postProcessAdapterRegistry.getAll();
var myAdapter = mp.postProcessAdapterRegistry.get('my-effect');
var hasAny = mp.postProcessAdapterRegistry.hasAdapters();
```

### 事件

| 事件常量 | 事件名 | 携带数据 |
|----------|--------|---------|
| `POSTPROC_ADAPTER_REGISTERED` | `postproc:adapter_registered` | `{ typeId: string }` |
| `POSTPROC_ADAPTER_UNREGISTERED` | `postproc:adapter_unregistered` | `{ typeId: string }` |

---

## 六、实施待办

### 待完成：PostProcPanel UI 集成

1. 改造 `PostProcPanel.ts`，添加动态插件效果区域
2. 实现适配器控件的动态生成（复用 `MaterialParamsSection` 的分组渲染逻辑）
3. 插件适配器在面板首次显示时（`onShown`），如果 `PostProcessManager` 已初始化，则自动调用 `adapter.initialize(scene, camera)`
4. 如果 `PostProcessManager` 尚未初始化，则在 `initializePostProcessManager()` 完成后统一初始化所有已注册适配器

---

## 七、文档信息

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | §一"实现进度"表新增一行"`BuiltinPluginRegistrar` 内置后处理插件注册：❌ 未注册（无内置 postproc 适配器，需通过 `installPlugin` 安装外部插件）"，与 `BuiltinPluginRegistrar.ts` 实际仅注册 ground/particle/shading 三类一致；核查确认 `src/UIComponents/featurePanels/` 下**无 `postproc/` 目录**，进一步印证"PostProcPanel UI 集成待实现" |
| v2.0 | 2026-08-15 | 与黑名单模式重构同步 |
| v1.0 | - | 初始版本 |
