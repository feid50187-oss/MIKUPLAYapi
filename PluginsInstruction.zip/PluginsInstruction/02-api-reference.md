# 插件开发 API 参考

本文档列出插件开发中可用的所有类、方法、UI 组件和数据类型。

---

## 一、插件上下文 (PluginContext)

每个插件在运行时通过 `context` 参数接收一个 `PluginContext` 对象，这是插件与宿主交互的核心入口。

### 接口定义

```typescript
interface PluginContext {
    scene: Scene;           // Babylon.js 场景实例
    engine: Engine;         // Babylon.js 引擎实例
    eventBus: EventBus;     // 事件总线
    storage: PluginStorage; // 插件隔离存储
    assetsDir: string;      // 插件资源目录 URL（WebView 可访问）
    app: PluginAppContext;  // 应用级上下文
}
```

### PluginAppContext

```typescript
interface PluginAppContext {
    getScene(): Scene;                          // 获取场景
    getEngine(): Engine;                        // 获取引擎
    getAnimationManager(): AnimationManager | null;  // 获取动画管理器（真实实例）
    getMusicManager(): MusicManager | null;     // 获取音乐管理器（真实实例）
    getModelManager(): ModelManager | null;     // 获取模型管理器（真实实例，插件可自由访问，见第六章 mp.model）
}
```

---

## 二、全局变量（黑名单模式）

插件代码通过 `new Function()` 在**宿主 realm** 中执行（非隔离沙箱），以下变量由宿主挂载到全局命名空间：

| 全局变量 | 说明 |
|---------|------|
| `context` | 插件运行上下文（PluginContext），见第一章 |
| `BABYLON` | Babylon.js 精简 re-export 模块，见第五章 |
| `mp` | 宿主扩展对象（白名单 API 面），见第六章 |
| `console` | 控制台（浏览器原生 console，宿主不包装、无前缀） |
| `document` | DOM 文档对象 |
| `window` | 窗口对象（宿主原生） |
| `setTimeout` / `clearTimeout` | 定时器 |
| `setInterval` / `clearInterval` | 循环定时器 |
| `requestAnimationFrame` / `cancelAnimationFrame` | 帧动画 |

插件代码以严格模式执行，最终返回 `exports` 对象作为插件导出。**黑名单边界**：宿主不暴露 `@capacitor/filesystem` 等写文件能力，写文件只能走 `mp.file.save`（见第六章）。

> 💡 **关于 window 的补充说明**：黑名单模式下插件直接运行在宿主全局作用域中，宿主在 `main.ts` 中挂载到 `window` 的全局对象（如 `BackgroundStateManager`、`GroundStateManager`、`ParticleStateManager`、`PostProcStateManager`、`ModelOptStateManager`、`WorldPanel`、`eventBus`）均可被插件访问。详见 [01-overview.md](01-overview.md) 中的"window 透传的全局对象"章节。

---

## 三、事件系统

### EventBus

| 方法 | 签名 | 说明 |
|------|------|------|
| `on` | `on<T>(event: string, handler: (...args: T) => void): () => void` | 订阅事件，返回取消订阅函数 |
| `emit` | `emit<T>(event: string, ...args: T): void` | 发布事件 |
| `removeAll` | `removeAll(event?: string): void` | 移除指定事件或所有事件的订阅 |

**使用示例**：

```javascript
// 订阅事件
var unsub = context.eventBus.on('model:loaded', function(modelInfo) {
    console.log('模型已加载:', modelInfo);
});

// 取消订阅
unsub();

// 发布事件
context.eventBus.emit('camera:reset', { position: { x: 0, y: 10, z: -30 } });
```

**使用示例**：

```javascript
// 订阅事件
var unsub = context.eventBus.on('model:loaded', function(modelInfo) {
    console.log('模型已加载:', modelInfo);
});

// 取消订阅
unsub();

// 发布事件
context.eventBus.emit('camera:reset', { position: { x: 0, y: 10, z: -30 } });
```

### 事件常量

以下事件可通过 `context.eventBus` 订阅或发布：

#### 模型事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `model:loaded` | `MODEL_LOADED` | 模型加载完成 |
| `model:removed` | `MODEL_REMOVED` | 模型被移除 |
| `model:selected` | `MODEL_SELECTED` | 模型被选中 |
| `model:visibility_changed` | `MODEL_VISIBILITY_CHANGED` | 模型可见性变更 |

#### 动画事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `animation:loaded` | `ANIMATION_LOADED` | 动画加载完成 |
| `animation:removed` | `ANIMATION_REMOVED` | 动画被移除 |
| `animation:ended` | `ANIMATION_ENDED` | 动画播放结束 |
| `frame:updated` | `FRAME_UPDATED` | 帧更新 |

#### 音乐事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `music:loaded` | `MUSIC_LOADED` | 音乐加载完成 |
| `music:removed` | `MUSIC_REMOVED` | 音乐被移除 |
| `music:changed` | `MUSIC_CHANGED` | 音乐变更 |
| `music:list_changed` | `MUSIC_LIST_CHANGED` | 音乐列表变更 |
| `music:state_changed` | `MUSIC_STATE_CHANGED` | 播放状态变更 |
| `music:time_updated` | `MUSIC_TIME_UPDATED` | 播放时间更新 |

#### 相机动画事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `camera_animation:loaded` | `CAMERA_ANIMATION_LOADED` | 相机动画加载完成 |
| `camera_animation:removed` | `CAMERA_ANIMATION_REMOVED` | 相机动画被移除 |

#### 地面事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `ground:type_changed` | `GROUND_TYPE_CHANGED` | 地面类型变更 |
| `ground:scale_changed` | `GROUND_SCALE_CHANGED` | 地面缩放变更 |
| `ground:height_changed` | `GROUND_HEIGHT_CHANGED` | 地面高度变更 |

#### 灯光事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `light:ambient_changed` | `LIGHT_AMBIENT_CHANGED` | 环境光变更 |
| `light:directional_changed` | `LIGHT_DIRECTIONAL_CHANGED` | 方向光变更 |

#### 背景事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `background:type_changed` | `BACKGROUND_TYPE_CHANGED` | 背景类型变更 |
| `background:color_changed` | `BACKGROUND_COLOR_CHANGED` | 背景颜色变更 |

#### 粒子事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `particle:system_changed` | `PARTICLE_SYSTEM_CHANGED` | 粒子系统变更 |
| `particle:params_changed` | `PARTICLE_PARAMS_CHANGED` | 粒子参数变更 |

#### 后处理/着色事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `postproc:changed` | `POSTPROC_CHANGED` | 后处理参数变更 |
| `postproc:adapter_registered` | `POSTPROC_ADAPTER_REGISTERED` | 后处理适配器注册 |
| `postproc:adapter_unregistered` | `POSTPROC_ADAPTER_UNREGISTERED` | 后处理适配器注销 |
| `shading:material_changed` | `SHADING_MATERIAL_CHANGED` | 材质变更 |
| `shading:adapter_registered` | `SHADING_ADAPTER_REGISTERED` | 材质适配器注册 |
| `shading:adapter_unregistered` | `SHADING_ADAPTER_UNREGISTERED` | 材质适配器注销 |

#### 物理/纹理事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `physics:toggled` | `PHYSICS_TOGGLED` | 物理模拟开关 |
| `gravity:changed` | `GRAVITY_CHANGED` | 重力变更 |
| `texture:downsample_toggled` | `TEXTURE_DOWNSAMPLE_TOGGLED` | 纹理降采样开关 |

#### 面板/渲染/全屏事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `panel:opened` | `PANEL_OPENED` | 面板打开 |
| `panel:closed` | `PANEL_CLOSED` | 面板关闭 |
| `render:started` | `RENDER_STARTED` | 渲染开始 |
| `render:finished` | `RENDER_FINISHED` | 渲染完成 |
| `fullscreen:changed` | `FULLSCREEN_CHANGED` | 全屏状态变更 |
| `theme:changed` | `THEME_CHANGED` | 主题变更 |

#### 插件事件

| 事件名 | 常量 | 说明 |
|--------|------|------|
| `plugin:installed` | `PLUGIN_INSTALLED` | 插件安装完成 |
| `plugin:uninstalled` | `PLUGIN_UNINSTALLED` | 插件卸载完成 |
| `plugin:updated` | `PLUGIN_UPDATED` | 插件更新完成 |
| `plugin:enabledChanged` | `PLUGIN_ENABLED_CHANGED` | 插件启用状态变更 |

---

## 四、插件存储 (PluginStorage)

每个插件拥有独立的持久化键值对存储，基于 Capacitor Filesystem 实现。

| 方法 | 签名 | 说明 |
|------|------|------|
| `set` | `set(key: string, value: unknown): Promise<void>` | 写入值（JSON 序列化） |
| `get` | `get<T>(key: string): Promise<T \| undefined>` | 读取值（JSON 反序列化） |
| `remove` | `remove(key: string): Promise<void>` | 删除指定 key |
| `clear` | `clear(): Promise<void>` | 清空所有存储 |

**使用示例**：

```javascript
// 保存设置
await context.storage.set('mySetting', { enabled: true, value: 42 });

// 读取设置
var setting = await context.storage.get('mySetting');
// setting = { enabled: true, value: 42 }

// 删除设置
await context.storage.remove('mySetting');

// 清空所有存储
await context.storage.clear();
```

---

## 五、Babylon.js API

插件通过全局变量 `BABYLON` 访问 Babylon.js 核心模块。以下是插件开发中常用的类和方法：

### 常用类

`BABYLON` 模块是精简 re-export（非完整 `@babylonjs/core`），实际可用类如下：

| 分类 | 类 | 说明 |
|------|----|------|
| 数学类型 | `BABYLON.Vector3` / `Vector2` / `Vector4` | 2D / 3D / 4D 向量 |
| | `BABYLON.Matrix` | 4x4 矩阵 |
| | `BABYLON.Quaternion` | 四元数 |
| | `BABYLON.TmpVectors` | 临时向量池（避免频繁 GC） |
| | `BABYLON.Color3` / `Color4` | RGB / RGBA 颜色（0-1 范围） |
| 场景核心 | `BABYLON.Scene` | 场景，3D 内容的容器 |
| | `BABYLON.Engine` | 渲染引擎 |
| 网格/节点 | `BABYLON.Mesh` | 3D 网格对象 |
| | `BABYLON.AbstractMesh` | 抽象网格基类 |
| | `BABYLON.MeshBuilder` | 网格构建工具（CreateGround, CreateBox, CreateSphere 等） |
| | `BABYLON.TransformNode` | 变换节点 |
| 材质/纹理 | `BABYLON.Material` | 材质基类 |
| | `BABYLON.StandardMaterial` | 标准材质 |
| | `BABYLON.PBRMaterial` | PBR 材质 |
| | `BABYLON.Texture` | 2D 纹理 |
| | `BABYLON.CubeTexture` | 立方体贴图（环境贴图） |
| | `BABYLON.BaseTexture` | 纹理基类 |
| 光源 | `BABYLON.Light` | 光源基类 |
| | `BABYLON.DirectionalLight` | 方向光 |
| | `BABYLON.HemisphericLight` | 半球光（环境光） |
| | `BABYLON.PointLight` | 点光源 |
| | `BABYLON.SpotLight` | 聚光灯 |
| Gizmo | `BABYLON.GizmoManager` | Gizmo 管理器（UI 插件常用） |
| 相机 | `BABYLON.Camera` | 相机基类 |
| | `BABYLON.FreeCamera` | 自由相机 |
| | `BABYLON.ArcRotateCamera` | 环绕相机 |
| 粒子 | `BABYLON.ParticleSystem` | 粒子系统 |
| | `BABYLON.ParticleSystemSet` | 粒子系统集 |
| 动画 | `BABYLON.Animation` | 单个动画曲线 |
| | `BABYLON.AnimationGroup` | 动画组 |
| 后处理/着色器 | `BABYLON.PostProcess` | 自定义后处理（着色插件常用） |
| | `BABYLON.Effect` | 着色器包装（含 `Effect.ShadersStore`） |
| 工具/事件 | `BABYLON.Tools` | 通用工具函数 |
| | `BABYLON.Observable` | 观察者模式事件（Babylon 内部事件） |
| | `BABYLON.PointerEventTypes` | 指针事件类型常量 |

> ⚠️ **过时/错误项修正**：旧版文档列出的 `BABYLON.GPUParticleSystem` **并未在 re-export 中导出**，插件中不可使用。请使用 `BABYLON.ParticleSystem`。

### 常用方法

```javascript
// 创建地面
var ground = BABYLON.MeshBuilder.CreateGround('myGround', { width: 100, height: 100 }, scene);

// 创建标准材质
var mat = new BABYLON.StandardMaterial('myMat', scene);
mat.diffuseColor = new BABYLON.Color3(0.5, 0.8, 0.5);

// 创建 PBR 材质
var pbr = new BABYLON.PBRMaterial('myPbr', scene);
pbr.albedoColor = new BABYLON.Color3(0.8, 0.8, 0.8);
pbr.metallic = 0.0;
pbr.roughness = 0.5;

// 加载纹理
var tex = new BABYLON.Texture('path/to/texture.png', scene);

// 获取场景中的活动相机
var camera = scene.activeCamera;

// 遍历场景中的所有网格
scene.meshes.forEach(function(mesh) { ... });
```

---

## 六、宿主扩展对象 (mp)

通过全局变量 `mp` 访问宿主提供的扩展功能。

### mp.particlePresetRegistry

粒子预设注册表，用于查询和注册粒子预设。

| 方法 | 签名 | 说明 |
|------|------|------|
| `getAll()` | `getAll(): ParticlePresetConfig[]` | 获取所有预设 |
| `get(type)` | `get(type: string): ParticlePresetConfig \| undefined` | 按类型获取预设 |
| `register(config)` | `register(config: ParticlePresetConfig): void` | 注册自定义预设 |
| `getTypes()` | `getTypes(): { value: string; label: string }[]` | 获取所有预设类型（用于 UI 下拉选择） |
| `unregister(type)` | `unregister(type: string): void` | 注销预设 |

### mp.materialAdapterRegistry

材质适配器注册表，用于查询和注册材质适配器。着色插件通过此注册表管理材质适配器。

| 方法 | 签名 | 说明 |
|------|------|------|
| `register(adapter)` | `register(adapter: IMaterialAdapter): void` | 注册适配器 |
| `unregister(typeId)` | `unregister(typeId: string): void` | 注销适配器 |
| `get(typeId)` | `get(typeId: string): IMaterialAdapter \| undefined` | 按类型 ID 获取适配器 |
| `findAdapter(material)` | `findAdapter(material: Material): IMaterialAdapter \| undefined` | 根据材质实例自动查找适配器 |
| `getAll()` | `getAll(): IMaterialAdapter[]` | 获取所有适配器 |
| `hasMaterialCreatingAdapters()` | `hasMaterialCreatingAdapters(): boolean` | 是否存在 `createsMaterial=true` 的适配器 |
| `getMaterialCreatingAdapters()` | `getMaterialCreatingAdapters(): IMaterialAdapter[]` | 获取所有 `createsMaterial=true` 的适配器 |

### mp.postProcessAdapterRegistry

后处理适配器注册表，用于查询和注册后处理适配器。后处理插件通过此注册表管理适配器。

| 方法 | 签名 | 说明 |
|------|------|------|
| `register(adapter)` | `register(adapter: IPostProcessAdapter): void` | 注册适配器 |
| `unregister(typeId)` | `unregister(typeId: string): void` | 注销适配器 |
| `get(typeId)` | `get(typeId: string): IPostProcessAdapter \| undefined` | 按类型 ID 获取适配器 |
| `getAll()` | `getAll(): IPostProcessAdapter[]` | 获取所有适配器（按 `order` 升序排列） |
| `hasAdapters()` | `hasAdapters(): boolean` | 是否存在已注册适配器 |

### mp.ui

宿主提供的共享 UI 组件工厂，插件可用于创建与主应用风格一致的 UI 元素。

| 属性 | 类型 | 说明 |
|------|------|------|
| `mp.ui.Slider` | `class` | 滑块组件构造函数 |
| `mp.ui.ToggleSwitch` | `class` | 开关组件构造函数 |
| `mp.ui.Dropdown` | `class` | 下拉选择组件构造函数 |
| `mp.ui.RGBColorPicker` | `class` | RGB 颜色选择器组件构造函数 |
| `mp.ui.VectorInput` | `class` | 向量输入组件构造函数 |
| `mp.ui.CollapsibleSection` | `class` | 折叠区域组件构造函数 |
| `mp.ui.toast` | `object`（`ToastService` 单例） | Toast 消息服务：`show(message, type?, duration?)`，`type` ∈ `'info' \| 'success' \| 'error' \| 'loading'`，默认 `'info'` / `3000ms`（loading 持续到手动 dismiss）；快捷方法 `info/success/error(message, duration?)`、`loading(message)`；均返回 `{ dismiss }` 可手动关闭 |
| `mp.ui.showConfirmDialog` | `function` | 确认对话框函数 `(config: ConfirmDialogConfig) => Promise<boolean>`，入参 `{ title, message, confirmText?, cancelText?, danger? }` |
| `mp.ui.icons` | `object` | SVG 图标对象集合（`IconRegistry`，按 `IconName` 调用；同名方法返回 `SVGElement`，支持 `options: { size?, color? }`） |

**使用示例**：

```javascript
// 使用宿主 Slider 组件（构造函数接收 config 对象，通过 .element 访问 DOM）
var slider = new mp.ui.Slider({
    label: '强度',
    min: 0,
    max: 1,
    step: 0.01,
    value: 0.5
});
slider.onChange(function(value) {
    console.log('滑块值:', value);
});
container.appendChild(slider.element);

// 使用宿主 ToggleSwitch 组件
var toggle = new mp.ui.ToggleSwitch({
    label: '启用',
    initialState: true
});
toggle.onChange(function(enabled) {
    console.log('开关状态:', enabled);
});
container.appendChild(toggle.element);

// 使用宿主 Dropdown 组件
var dropdown = new mp.ui.Dropdown({
    label: '选项',
    options: [
        { label: '选项 A', value: 'a' },
        { label: '选项 B', value: 'b' }
    ],
    selectedValue: 'a'
});
dropdown.onChange(function(value) {
    console.log('选中值:', value);
});
container.appendChild(dropdown.element);

// 使用宿主 CollapsibleSection 组件
var section = new mp.ui.CollapsibleSection({
    title: '分组标题',
    initiallyExpanded: true
});
var content = section.getContentContainer();   // 内容容器（mp-collapsible-inner）
content.appendChild(slider.element);
container.appendChild(section.element);

// 使用宿主 RGBColorPicker 组件
var picker = new mp.ui.RGBColorPicker({
    label: '颜色',
    color: { r: 1, g: 0, b: 0 },
    mode: 'inline'   // 或 'popup'
});
picker.onChange(function(color) {
    // color = { r, g, b, a }，分量范围 0-1
    console.log(color);
});
container.appendChild(picker.element);

// 使用提示消息（快捷方法）
mp.ui.toast.success('操作成功', 2000);
// 或使用 show 方法指定类型与自定义持续时间
mp.ui.toast.show('出错了', 'error', 3000);
// Loading 消息（无超时，需手动 dismiss；返回 { dismiss } 可立即关闭）
var loading = mp.ui.toast.loading('处理中...');
loading.dismiss();

// 使用确认对话框（实际签名：接收 ConfirmDialogConfig 对象）
mp.ui.showConfirmDialog({
    title: '确认',
    message: '确定要执行此操作吗？',
    confirmText: '确认',
    cancelText: '取消',
    danger: false,       // 可选：危险操作标红
}).then(function (confirmed) {
    if (confirmed) { /* 用户点击确认 */ }
});
```

> 💡 **组件通用约定**：
> - 所有组件均为 **配置对象构造**（`new mp.ui.Xxx(config)`），不再接受位置参数。
> - 组件通过 `component.element`（HTMLElement 属性，非方法）获取 DOM，旧版 `getElement()` 已废弃。
> - `onChange(callback)` 返回一个取消订阅函数；组件需在 `dispose()` 时调用 `component.dispose()` 释放监听器（特别是 `Dropdown`、`RGBColorPicker` 等注册了全局文档事件的组件）。
> - `CollapsibleSection` 使用 `getContentContainer()` 获取内部容器以放置子元素。

### mp.file

宿主提供的**安全文件保存桥**。设计理念：**插件无文件系统权限**，仅能发起保存请求；宿主先弹窗询问，用户同意后插件上交文件，由宿主以"只新增、绝不覆盖/修改/删除"的安全方式写入外部共享存储的 `MikuPlay/PluginOutput/<插件ID>/` 目录（用户可通过文件管理器直接访问）。

| 属性 | 类型 | 说明 |
|------|------|------|
| `mp.file.save` | `function` | 请求保存文件 `(options: PluginFileSaveOptions) => Promise<PluginFileSaveResult>` |

#### 入参 PluginFileSaveOptions

| 字段 | 类型 | 说明 |
|------|------|------|
| `data` | `Blob \| string` | 文件内容（推荐传 `Blob`；也可传裸 base64 字符串）。与 `dataProducer` 二选一 |
| `dataProducer` | `() => Blob \| string \| Promise<...>` | **惰性数据生成器**：宿主确认后才调用，用于避免昂贵的编码（如 8K 图 `toBlob`）阻塞确认框弹出。与 `data` 二选一 |
| `filename` | `string` | 建议文件名（宿主会做安全化处理） |
| `mime` | `string` | MIME 类型，用于文件名缺扩展名时兜底补全，如 `image/png` |

#### 返回值 PluginFileSaveResult

| 字段 | 类型 | 说明 |
|------|------|------|
| `ok` | `boolean` | 是否保存成功 |
| `canceled` | `boolean` | 用户拒绝保存时为 `true` |
| `path` | `string` | 保存后的相对路径（原生平台） |
| `uri` | `string` | 可访问的 URI（原生平台经 `convertFileSrc`） |
| `filename` | `string` | 实际落盘/下载的文件名 |
| `reason` | `string` | 失败原因（`ok` 为 `false` 时） |

**使用示例**：

```javascript
// 先准备（惰性）数据，再请求保存；确认框会在昂贵编码之前弹出
mp.file.save({
    dataProducer: function () {
        return new Promise(function (resolve) {
            canvas.toBlob(function (blob) { resolve(blob); }, 'image/png');
        });
    },
    filename: 'bake-result.png',
    mime: 'image/png'
}).then(function (res) {
    if (res.ok) {
        console.log('已保存:', res.filename, res.path);
    } else if (res.canceled) {
        console.log('用户拒绝保存');
    } else {
        console.error('保存失败:', res.reason);
    }
});
```

> 💡 **安全说明**：
> - 插件只能**新增**文件，无法覆盖/修改/删除已有文件；同名冲突时宿主自动追加 `_1`、`_2`… 序号。
> - 文件写入仅限定在 `MikuPlay/PluginOutput/<插件ID>/` 下，不会写到其他位置。
> - Web 开发环境在用户确认后直接触发浏览器下载；原生平台写入外部共享存储。

### mp.model

宿主提供的**模型读取便利层**。黑名单模式下不再做"只读 DTO 伪装"——通过 `context.app.getModelManager()` 插件本就能拿到完整 mesh 引用，这里只是更便捷的"模型列表 + 变更订阅"封装。`list/get/count` 返回**真实的 `ModelInfo`**（含 `mesh`/`container` 引用，插件可自由访问模型数据）。

| 方法 | 签名 | 说明 |
|------|------|------|
| `list` | `list(): ModelInfo[]` | 返回当前全部模型（含 mesh/container 内部引用） |
| `get` | `get(id: string): ModelInfo \| undefined` | 按 ModelId 查询单个模型，不存在返回 `undefined` |
| `count` | `count(): number` | 当前模型数量 |
| `onChanged` | `onChanged(cb: (model: ModelInfo, added: boolean) => void): () => void` | 订阅模型增删，返回取消订阅函数 |

#### 数据类型 ModelInfo

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | `string` | 模型唯一标识（ModelId） |
| `name` | `string` | 模型名称（文件名） |
| `filePath` | `string` | 模型文件路径 |
| `fileType` | `'pmx' \| 'pmd' \| 'bpmx'` | MMD 模型文件类型 |
| `mesh` | `AbstractMesh \| null` | 模型根网格（可据此直接操纵场景中的模型） |
| `container` | `AssetContainer \| null` | 模型资源容器 |

**使用示例**：

```javascript
// 读取全部模型（返回真实 ModelInfo，含 mesh/container 引用）
var models = mp.model.list();
models.forEach(function (m) {
    console.log('模型:', m.name, 'ID:', m.id, '类型:', m.fileType);
    // m.mesh / m.container 可直接访问
});

// 按 ID 查询单个模型
var target = mp.model.get('model_1715xxxx');
if (target) { console.log('找到模型:', target.name); }

// 订阅模型增删（返回取消函数，dispose 时应调用）
var unsub = mp.model.onChanged(function (model, added) {
    console.log(added ? '新增模型:' : '移除模型:', model.name);
});
```

> 💡 **说明**：
> - `mp.model` 返回真实 `ModelInfo`，含 `mesh`/`container` 引用——黑名单模式下插件**可以**据此操纵场景中的模型，这正是设计意图。
> - 该 API 仅提供"读取 + 订阅"，不包含导入/删除方法；模型导入/删除仍由用户在宿主界面完成，插件通过 `onChanged` 感知变化。
> - 订阅后记得在 `dispose()` 中调用返回的取消函数，避免泄漏。

---

## 七、材质适配器 (IMaterialAdapter)

材质适配器是着色插件的核心接口，每种材质类型对应一个适配器实现。详见 [06-shading-plugin-guide.md](06-shading-plugin-guide.md)。

### ParamValue 类型

```typescript
type ParamValue = number | string | boolean | { r: number; g: number; b: number } | number[];
```

### IMaterialAdapter 接口

```typescript
interface IMaterialAdapter {
    readonly typeId: string;              // 适配器唯一标识（如 'mmd-standard'）
    readonly displayName: string;         // 显示名称（如 'MMD 标准'）
    readonly supportsOutline: boolean;    // 是否支持轮廓线
    readonly supportsMorph: boolean;      // 是否支持材质变形
    readonly createsMaterial: boolean;    // 是否需要创建新材质替换原始材质

    canHandle(material: Material): boolean;
    readState(material: Material): Record<string, ParamValue>;
    writeState(material: Material, state: Record<string, ParamValue>): void;
    getControlDeclarations(): ControlDeclaration[];
    getDefaultState(): Record<string, ParamValue>;
    convertFromMmd?(mmdMaterial: Material, scene: Scene, textureMap?: Map<string, Texture>): Material;
    convertToMmd?(material: Material, scene: Scene): Material;
    disposeMaterial(material: Material): void;
}
```

### 属性说明

| 属性 | 类型 | 说明 |
|------|------|------|
| `typeId` | `string` | 适配器唯一标识，全局唯一，用于风格选择器和状态管理 |
| `displayName` | `string` | 用户可见的显示名称，出现在风格选择器中 |
| `supportsOutline` | `boolean` | 该材质类型是否支持轮廓线（描边），影响着色面板描边区域的显示 |
| `supportsMorph` | `boolean` | 该材质类型是否支持 VMD 材质变形动画 |
| `createsMaterial` | `boolean` | 是否需要创建新材质替换原始 `MmdStandardMaterial`。`true` 时着色面板显示"渲染风格"选择器 |

### 方法说明

| 方法 | 必填 | 说明 |
|------|------|------|
| `canHandle(material)` | 是 | 判定给定材质是否由该适配器处理，通常使用 `instanceof` |
| `readState(material)` | 是 | 从材质实例读取参数状态，返回键值对 |
| `writeState(material, state)` | 是 | 将参数状态写入材质实例 |
| `getControlDeclarations()` | 是 | 声明该材质类型的参数控件，宿主据此动态生成 UI |
| `getDefaultState()` | 是 | 获取参数默认值 |
| `convertFromMmd(mmdMaterial, scene, textureMap?)` | 否 | 将 `MmdStandardMaterial` 转换为该适配器的材质类型，`createsMaterial=true` 时建议实现 |
| `convertToMmd(material, scene)` | 否 | 将该适配器的材质转换回 `MmdStandardMaterial` |
| `disposeMaterial(material)` | 是 | 释放该适配器创建的材质资源 |

---

## 八、后处理适配器 (IPostProcessAdapter)

后处理适配器是后处理插件的核心接口，每种后处理效果对应一个适配器实现。详见 [07-postproc-plugin-design.md](07-postproc-plugin-design.md)。

### 接口定义

```typescript
interface IPostProcessAdapter {
    readonly typeId: string;              // 适配器唯一标识
    readonly displayName: string;         // 显示名称
    readonly order: number;               // 管线顺序（值越小越先执行）

    getControlDeclarations(): ControlDeclaration[];
    getDefaultState(): Record<string, ParamValue>;
    readState(): Record<string, ParamValue>;
    writeState(state: Record<string, ParamValue>): void;

    initialize(scene: Scene, camera: Camera): void;
    isInitialized(): boolean;
    setEnabled(enabled: boolean): void;
    isEnabled(): boolean;
    dispose(): void;
}
```

### 属性说明

| 属性 | 类型 | 说明 |
|------|------|------|
| `typeId` | `string` | 适配器唯一标识，全局唯一 |
| `displayName` | `string` | 用户可见的显示名称 |
| `order` | `number` | 管线执行顺序。内置效果基准：0=FXAA, 10=ImageProcessing, 20=Bloom, 30=DOF |

### 方法说明

| 方法 | 说明 |
|------|------|
| `getControlDeclarations()` | 声明参数控件，宿主据此生成 UI |
| `getDefaultState()` | 获取参数默认值 |
| `readState()` | 读取当前参数状态（无 material 参数，后处理是全局的） |
| `writeState(state)` | 写入参数状态 |
| `initialize(scene, camera)` | 创建 PostProcess 并附加到相机 |
| `isInitialized()` | 是否已初始化 |
| `setEnabled(enabled)` | 启用/禁用效果 |
| `isEnabled()` | 当前是否启用 |
| `dispose()` | 释放所有资源 |

---

## 九、共享 UI 组件

插件可以通过 `document.createElement` 创建 DOM 元素，也可以使用宿主提供的共享 UI 组件样式类。这些样式类已在宿主应用中注入，插件可直接使用。

### 7.1 通用样式类

| CSS 类名 | 说明 |
|----------|------|
| `.mp-btn` | 通用按钮 |
| `.mp-btn.primary` | 主要按钮（粉色） |
| `.mp-btn.danger` | 危险按钮（红色） |
| `.mp-btn.small` | 小尺寸按钮 |
| `.mp-input` | 通用输入框 |

### 7.2 CSS 自定义属性

宿主通过 `:root` 注入了以下 CSS 自定义属性，插件可直接引用：

| 变量名 | 值 | 说明 |
|--------|-----|------|
| `--color-accent` | `#FF6699` | 主题强调色 |
| `--color-bg` | `#f5f5f5` | 背景色 |
| `--color-surface` | `#ffffff` | 表面色 |
| `--color-border` | `#e0e0e0` | 边框色 |
| `--text-primary` | `#212121` | 主要文本色 |
| `--text-secondary` | `#616161` | 次要文本色 |
| `--text-disabled` | `#bdbdbd` | 禁用文本色 |
| `--radius-md` | `12px` | 中等圆角 |
| `--radius-sm` | `8px` | 小圆角 |
| `--radius-lg` | `16px` | 大圆角 |
| `--transition-fast` | `0.2s ease` | 快速过渡 |
| `--transition-normal` | `0.3s ease` | 正常过渡 |

### 7.3 共享组件样式类

以下样式类对应宿主的共享 UI 组件，插件可直接在 DOM 中使用：

#### Slider（滑块）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-slider-item` | 滑块项容器 |
| `.mp-slider-label-row` | 标签行（标签 + 值） |
| `.mp-slider-label` | 标签文本 |
| `.mp-slider-value` | 值文本 |
| `.mp-slider-container` | 滑块容器 |
| `.mp-slider` | 滑块输入元素 |

#### ToggleSwitch（开关）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-toggle-item` | 开关项容器 |
| `.mp-toggle-label` | 开关标签 |
| `.mp-toggle-switch` | 开关轨道 |
| `.mp-toggle-switch.active` | 激活状态 |

#### Dropdown（下拉选择器）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-dropdown` | 下拉选择器容器 |
| `.mp-dropdown-display` | 显示区域 |
| `.mp-dropdown-text` | 选中值文本 |
| `.mp-dropdown-arrow` | 箭头图标 |
| `.mp-dropdown-options` | 选项列表 |
| `.mp-dropdown-option` | 单个选项 |
| `.mp-dropdown-option.selected` | 选中状态 |

#### CollapsibleSection（折叠区域）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-collapsible-section` | 折叠区域容器 |
| `.mp-collapsible-header` | 可点击标题栏 |
| `.mp-collapsible-title` | 标题文本 |
| `.mp-collapsible-content` | 内容区 |

#### RGBColorPicker（颜色选择器）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-rgb-slider-item` | RGB 滑块项 |
| `.mp-rgb-slider-label` | 通道标签 |
| `.mp-rgb-slider-track` | 轨道 |
| `.mp-rgb-slider-track-fill` | 填充 |
| `.mp-rgb-thumb` | 拖拽手柄 |

#### VectorInput（向量输入）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-vector-input` | 向量输入容器 |
| `.mp-vector-input-label` | 标签 |
| `.mp-vector-input-row` | 分量行 |
| `.mp-vector-component` | 单个分量 |
| `.mp-vector-comp-label` | 分量标签（`data-axis="x/y/z"` 应用轴颜色） |
| `.mp-vector-comp-input` | 分量输入框 |

#### Overlay（遮罩层）

| CSS 类名 | 说明 |
|----------|------|
| `.mp-overlay` | 全屏遮罩层 |
| `.mp-overlay-dialog` | 居中对话框 |
| `.mp-overlay-in` | 入场动画类 |
| `.mp-overlay-out` | 退场动画类 |

---

## 十、插件清单 (PluginManifest)

每个插件必须包含一个 `manifest.json` 文件，定义插件的基本信息。

### 接口定义

```typescript
interface PluginManifest {
    id: string;                          // 插件唯一标识符（推荐格式：com.author.plugin-name）
    name: string;                        // 插件显示名称
    version: string;                     // 版本号（语义化版本，如 "1.0.0"）
    type: 'functional' | 'ui';          // 插件类型
    target?: 'ground' | 'particle' | 'shading' | 'postproc' | 'background'; // 功能型插件的作用模块（联合类型）
    mount?: 'tab' | 'overlay';          // UI 型插件的挂载方式
    author?: string;                     // 作者
    description?: string;                // 描述
}
```

### 字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `id` | 是 | 全局唯一标识符。内置插件使用 `builtin.` 前缀，建议外部插件使用反向域名格式 |
| `name` | 是 | 用户可见的插件名称 |
| `version` | 是 | 语义化版本号 |
| `type` | 是 | `functional`（功能型）或 `ui`（UI 型） |
| `target` | 功能型必填 | 作用模块，支持：`ground`、`particle`、`shading`、`postproc`、`background`（`background` 当前仅在 `PluginTarget` 联合类型中预留，无对应导出契约与宿主集成） |
| `mount` | UI 型必填 | 挂载方式：`tab`（标签页）或 `overlay`（叠加层） |
| `author` | 否 | 作者名称 |
| `description` | 否 | 插件描述 |

---

## 十一、插件导出接口

插件必须通过 `exports` 对象导出对应类型所需的功能。各类型插件的导出接口如下：

### 功能型插件导出 (FunctionalPluginExports)

地面插件和粒子插件使用此导出接口：

```typescript
interface FunctionalPluginExports {
    preset: PluginPreset;                              // 预设信息
    createInstance?: () => IGroundPluginInstance;      // 实例工厂（地面插件必须）
    onActivate?: (ctx: PluginContext) => void | Promise<void>;   // 激活回调
    onDeactivate?: (ctx: PluginContext) => void | Promise<void>; // 停用回调
    dispose?: () => void | Promise<void>;              // 释放资源
}
```

### 着色插件导出 (ShadingPluginExports)

着色插件使用此导出接口，核心是提供材质适配器实例：

```typescript
interface ShadingPluginExports {
    adapter: IMaterialAdapter;                                      // 材质适配器实例
    onActivate?: (ctx: PluginContext) => void | Promise<void>;      // 激活回调
    onDeactivate?: (ctx: PluginContext) => void | Promise<void>;    // 停用回调
    dispose?: () => void | Promise<void>;                           // 释放资源
}
```

**与 FunctionalPluginExports 的区别**：着色插件没有 `preset` 和 `createInstance`，而是通过 `adapter` 提供材质适配器。宿主在加载着色插件时会自动将 `adapter` 注册到 `materialAdapterRegistry`。

### 后处理插件导出 (PostProcessPluginExports)

后处理插件使用此导出接口，核心是提供后处理适配器实例：

```typescript
interface PostProcessPluginExports {
    adapter: IPostProcessAdapter;                                   // 后处理适配器实例
    onActivate?: (ctx: PluginContext) => void | Promise<void>;      // 激活回调
    onDeactivate?: (ctx: PluginContext) => void | Promise<void>;    // 停用回调
    dispose?: () => void | Promise<void>;                           // 释放资源
}
```

宿主在加载后处理插件时会自动将 `adapter` 注册到 `postProcessAdapterRegistry`。

### UI 型插件导出 (UIPluginExports)

```typescript
interface UIPluginExports {
    createPanel: (ctx: PluginContext) => HTMLElement;  // 创建面板 UI
    onShown?: () => void;                              // 面板显示时调用
    onHidden?: () => void;                             // 面板隐藏时调用
    dispose?: () => void | Promise<void>;              // 释放资源
}
```

---

## 十二、控件声明 (ControlDeclaration)

控件声明用于功能型插件（地面/粒子）的 `preset.controls` 和着色插件的 `adapter.getControlDeclarations()`，宿主据此自动生成参数编辑 UI。

所有控件声明都支持可选的 `group` 字段，用于将多个控件合并到一个分组容器中显示。

### SliderControlDeclaration（滑块控件）

```typescript
interface SliderControlDeclaration {
    param: string;      // 参数名（对应 defaultParams 中的 key）
    type: 'slider';     // 控件类型
    label: string;      // 显示标签
    min: number;        // 最小值
    max: number;        // 最大值
    step: number;       // 步进值
    group?: string;     // 分组名（可选）
}
```

### ColorControlDeclaration（颜色控件）

```typescript
interface ColorControlDeclaration {
    param: string;      // 参数名
    type: 'color';      // 控件类型
    label: string;      // 显示标签
    group?: string;     // 分组名（可选）
}
```

颜色值格式为 `{ r: number, g: number, b: number }`，各分量范围 0-1。

### VectorControlDeclaration（向量控件）

```typescript
interface VectorControlDeclaration {
    param: string;      // 参数名
    type: 'vector';     // 控件类型
    label: string;      // 显示标签
    group?: string;     // 分组名（可选）
}
```

向量值格式为 `number[]`，如 `[x, y, z]`。

### DropdownControlDeclaration（下拉选择控件）

```typescript
interface DropdownControlDeclaration {
    param: string;          // 参数名
    type: 'dropdown';       // 控件类型
    label: string;          // 显示标签
    options: string[];      // 选项值数组
    optionLabels?: string[]; // 选项显示名（可选，默认与 options 相同）
    group?: string;         // 分组名（可选）
}
```

### ToggleControlDeclaration（开关控件）

```typescript
interface ToggleControlDeclaration {
    param: string;      // 参数名
    type: 'toggle';     // 控件类型
    label: string;      // 显示标签
    group?: string;     // 分组名（可选）
}
```

开关值类型为 `boolean`。

### TextureControlDeclaration（纹理控件）

```typescript
interface TextureControlDeclaration {
    param: string;      // 参数名
    type: 'texture';    // 控件类型
    label: string;      // 显示标签
    group?: string;     // 分组名（可选）
}
```

纹理控件用于选择纹理贴图（如材质的 diffuse / specular / toon 纹理）。参数值类型为纹理对象引用或纹理路径字符串（取决于具体适配器实现）。

### 联合类型

```typescript
type ControlDeclaration =
    | SliderControlDeclaration
    | ColorControlDeclaration
    | VectorControlDeclaration
    | DropdownControlDeclaration
    | ToggleControlDeclaration
    | TextureControlDeclaration;
```

---

## 十三、功能型插件相关类型

### PluginPreset（插件预设）

```typescript
interface PluginPreset {
    name: string;                       // 预设名称
    defaultParams: Record<string, unknown>;  // 默认参数
    controls: ControlDeclaration[];     // 控件声明数组
    renderConfig?: ParticleRenderConfig; // 粒子渲染配置（仅粒子插件）
}
```

### ParticleRenderConfig（粒子渲染配置）

```typescript
interface ParticleRenderConfig {
    textureSource: string;       // 纹理来源：'procedural' | 'builtin' | 'external'
    texture: string;             // 纹理路径或类型名
    blendMode: string;           // 混合模式：'oneOne' | 'standard'
    depthWrite: boolean;         // 是否写入深度
    enableRotation: boolean;     // 是否启用旋转
    defaultMaxParticles: number; // 默认最大粒子数
}
```

### IGroundPluginInstance（地面插件实例）

```typescript
interface IGroundPluginInstance {
    create(scene: Scene, scale: number, height: number): void;  // 创建地面
    dispose(): void;                                             // 销毁地面
    setScale(scale: number): void;                               // 设置缩放
    setHeight(height: number): void;                             // 设置高度
    createPrivateParams?(): HTMLElement;                         // 创建自定义参数 UI
}
```

---

## 十四、插件注册表条目 (PluginEntry)

```typescript
interface PluginEntry {
    manifest: PluginManifest;   // 插件清单
    data: PluginExports;        // 插件导出对象
    enabled: boolean;           // 是否启用
    builtIn?: boolean;          // 是否为内置插件
}
```

---

## 十五、面板接口 (IPanel)

UI 型插件创建的面板会被适配为 `IPanel` 接口，由 NavBar 或视口管理。

```typescript
interface IPanel {
    readonly id: string;                        // 面板 ID
    readonly tabLabel: string;                  // 标签文本
    readonly tabIcon: string;                   // 标签图标（SVG 字符串）
    readonly element: HTMLElement;              // 面板 DOM 元素
    mount(container: HTMLElement): void;        // 挂载到容器
    unmount(): void;                            // 从容器卸载
    dispose(): void;                            // 释放资源
    onShown?(): void;                           // 面板显示时调用
    onHidden?(): void;                          // 面板隐藏时调用
}
```

---

## 十六、注册表持久化 (RegistryEntry)

```typescript
interface RegistryEntry {
    version: string;        // 插件版本
    enabled: boolean;       // 是否启用
    installedAt: string;    // 安装时间（ISO 8601）
}

interface PluginRegistryData {
    plugins: Record<string, RegistryEntry>;  // 插件 ID → 注册条目
}
```

---

## 十七、变更记录

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | 第六章 `mp.ui.toast` 表格修正实际签名（`show(message, type?, duration?)` 五个方法均为实例方法，loading 不自动消失）；`mp.ui.showConfirmDialog` 实际签名（接收 `ConfirmDialogConfig` 对象 `{ title, message, confirmText?, cancelText?, danger? }`，非文档中位置参数 `(title, message)`）；`mp.ui.icons` 补充 `IconRegistry` 实际 API（`IconName` 导出、`options: { size?, color? }`）；第十章 `PluginManifest.target` 联合类型已包含 `background`（联合预留，**当前无对应导出契约与宿主集成**）；§11 / §17 同步落地上述变更 |
| v2.0 | 2026-08-15 | 插件系统重构为黑名单模式：第二章改为"全局变量（黑名单模式）"，说明插件在宿主 realm 执行、仅文件写入被禁止；第一章 `getModelManager()` 返回真实 `ModelManager`；第六章 `mp.model` 不再返回只读 DTO，改为返回真实 `ModelInfo`（含 `mesh`/`container` 引用），移除 `PluginModelInfo` 文档 |
| v1.4 | 2026-08-13 | 第一章 `PluginAppContext` 新增 `getModelManager()`；第六章新增 `mp.model`（模型只读桥）：`list/get/count/onChanged`，文档化只读 DTO `PluginModelInfo`（id/name/fileType）及安全模型（仅元数据、不暴露 mesh/container 等内部引用、不可导入/删除/修改模型） |
| v1.3 | 2026-08-13 | 第六章新增 `mp.file`（安全文件保存桥）：文档化 `mp.file.save` 的入参 `PluginFileSaveOptions`（含惰性 `dataProducer`）、返回值 `PluginFileSaveResult` 及安全模型（只新增不覆盖、写入 `MikuPlay/PluginOutput/<插件ID>/`、宿主确认后落盘） |
| v1.2 | 2026-08-13 | 第六章 `mp.ui` 示例改为 config 对象构造（`new mp.ui.Slider({label,min,max,step,value})` 等），统一使用 `component.element` 属性替代旧版 `getElement()`；补充 `Dropdown`、`CollapsibleSection`、`RGBColorPicker` 的完整示例与组件通用约定（dispose/onChange 返回取消订阅函数等） |
| v1.1 | 2026-08-12 | 沙箱全局变量章节新增 window 透传对象提示；修正第五章 BABYLON 模块分类清单（移除不存在的 `GPUParticleSystem`，补充 `Vector2/4`、`Quaternion`、`TmpVectors`、`AbstractMesh`、`CubeTexture/BaseTexture`、各类光源、`GizmoManager`、`FreeCamera/ArcRotateCamera`、`ParticleSystemSet`、`Animation/AnimationGroup`、`PostProcess/Effect`、`Tools/Observable/PointerEventTypes`）；第十二章控件声明新增 `TextureControlDeclaration`（`type: 'texture'`）及联合类型更新 |
| v1.0 | - | 初始版本 |
