# 插件格式规范（.mkp）

## 一、概述

MikuPlay Reburn 插件统一使用 `.mkp` 格式分发。`.mkp` 文件本质上是一个内容物正确的 ZIP 压缩文件，扩展名为 `.mkp`。

> 插件系统实际支持任何内容物正确的 ZIP 压缩文件，无论扩展名如何。`.mkp` 是官方推荐的统一扩展名。

---

## 二、文件结构

### 2.1 基本结构

一个 `.mkp` 文件解压后必须包含以下文件：

```
plugin.mkp (ZIP)
├── manifest.json    # 必需 - 插件清单
├── index.js         # 必需 - 插件代码
└── assets/          # 可选 - 资源文件目录
    ├── texture.png
    ├── data.json
    └── ...
```

### 2.2 manifest.json（必需）

插件清单文件，定义插件的基本信息和类型。详见 [02-api-reference.md](02-api-reference.md) 中的 PluginManifest 章节。

**功能型插件示例（地面/粒子）**：

```json
{
    "id": "com.author.ground-custom",
    "name": "自定义地面",
    "version": "1.0.0",
    "type": "functional",
    "target": "ground",
    "author": "Author Name",
    "description": "一个自定义地面插件"
}
```

**功能型插件示例（着色）**：

```json
{
    "id": "com.author.shading-pbr",
    "name": "PBR 材质",
    "version": "1.0.0",
    "type": "functional",
    "target": "shading",
    "author": "Author Name",
    "description": "基于物理的渲染材质风格"
}
```

**功能型插件示例（后处理）**：

```json
{
    "id": "com.author.postproc-chromatic",
    "name": "色差效果",
    "version": "1.0.0",
    "type": "functional",
    "target": "postproc",
    "author": "Author Name",
    "description": "添加色差后处理效果"
}
```

**UI 型插件示例**：

```json
{
    "id": "com.author.my-tool",
    "name": "我的工具",
    "version": "1.0.0",
    "type": "ui",
    "mount": "tab",
    "author": "Author Name",
    "description": "一个工具面板插件"
}
```

### 2.3 index.js（必需）

插件代码文件，必须通过 `exports` 对象导出插件功能。

- 地面/粒子插件 → 详见 [03-functional-plugin-guide.md](03-functional-plugin-guide.md)
- 着色插件 → 详见 [06-shading-plugin-guide.md](06-shading-plugin-guide.md)
- 后处理插件 → 详见 [07-postproc-plugin-design.md](07-postproc-plugin-design.md)
- UI 型插件 → 详见 [04-ui-plugin-guide.md](04-ui-plugin-guide.md)

**关键要求**：
- 必须声明 `var exports = {};`
- 代码执行后 `exports` 对象必须包含对应类型所需的导出内容
- 代码以严格模式执行（`"use strict"`）

### 2.4 assets/（可选）

资源文件目录，可包含纹理、数据文件等。插件通过 `context.assetsDir` 访问此目录。

```
assets/
├── textures/
│   ├── ground_diffuse.png
│   └── ground_normal.png
├── data/
│   └── config.json
└── icons/
    └── tool.svg
```

在插件代码中访问资源：

```javascript
// context.assetsDir 是插件目录的 WebView URL
var textureUrl = context.assetsDir + '/textures/ground_diffuse.png';
var texture = new BABYLON.Texture(textureUrl, scene);
```

---

## 三、打包方法

### 3.1 手动打包

使用系统自带的 ZIP 工具打包：

**Windows (PowerShell)**：

```powershell
# 进入插件目录
cd path\to\my-plugin

# 创建 .mkp 文件（ZIP 格式）
Compress-Archive -Path manifest.json, index.js, assets -DestinationPath my-plugin.mkp -Force
```

**macOS / Linux**：

```bash
# 进入插件目录
cd path/to/my-plugin

# 创建 .mkp 文件（ZIP 格式）
zip -r my-plugin.mkp manifest.json index.js assets/
```

### 3.2 打包注意事项

1. **根目录结构**：`manifest.json` 和 `index.js` 必须在 ZIP 文件的根目录，不能嵌套在子目录中

   ```
   ✅ 正确：
   my-plugin.mkp
   ├── manifest.json
   └── index.js

   ❌ 错误：
   my-plugin.mkp
   └── my-plugin/
       ├── manifest.json
       └── index.js
   ```

2. **文件编码**：`manifest.json` 和 `index.js` 必须使用 UTF-8 编码

3. **压缩方式**：使用标准 ZIP 压缩（Store 或 Deflate 均可）

4. **文件大小**：建议单个插件包不超过 50MB

---

## 四、安装方法

### 4.1 通过应用内安装

1. 打开 MikuPlay Reburn 应用
2. 点击顶部工具栏的菜单按钮（☰）
3. 在侧边菜单中找到"插件管理"区域
4. 点击"安装插件"按钮
5. 选择 `.mkp` 文件

### 4.2 安装流程

安装过程由 `PluginInstaller` 处理：

1. 用户选择 `.mkp` 文件
2. Android 原生端使用 `ZipInputStream` 解压到 `plugins/${pluginId}/` 目录
3. 读取 `manifest.json`，验证必需字段
4. 更新 `plugins/registry.json` 注册表
5. 应用重启后，`PluginLoader.loadFromDisk()` 加载并注册插件

### 4.3 安装后行为

- 安装/卸载/更新插件后，应用会**强制退出**，需要重新打开
- 启用/禁用插件仅修改状态标记，**重启后生效**

---

## 五、插件 ID 规范

### 5.1 命名规则

- 使用反向域名格式：`com.author.plugin-name`
- 仅允许小写字母、数字、点号（`.`）和连字符（`-`）
- 必须全局唯一

### 5.2 保留前缀

| 前缀 | 说明 |
|------|------|
| `builtin.` | 内置插件保留前缀，外部插件禁止使用 |

### 5.3 示例

| ID | 说明 |
|----|------|
| `com.example.custom-ground` | 示例作者的自定义地面插件 |
| `com.mikuplay.snow-particles` | mikuplay 的雪花粒子插件 |
| `net.user.camera-tools` | 用户的相机工具插件 |

---

## 六、版本规范

采用语义化版本（SemVer）格式：`MAJOR.MINOR.PATCH`

| 版本号 | 说明 |
|--------|------|
| MAJOR | 不兼容的 API 变更 |
| MINOR | 向后兼容的功能新增 |
| PATCH | 向后兼容的问题修复 |

示例：`1.0.0`、`1.2.3`、`2.0.0`

---

## 七、插件目录结构（安装后）

插件安装后，文件存储在应用数据目录下：

```
plugins/
├── registry.json                           # 全局注册表
├── com.example.my-plugin/                  # 插件目录（以 ID 命名）
│   ├── manifest.json                       # 插件清单
│   ├── index.js                            # 插件代码
│   └── assets/                             # 资源目录
│       └── ...
├── com.example.another-plugin/
│   ├── manifest.json
│   └── index.js
└── _storage/                               # 插件存储目录
    ├── com.example.my-plugin/              # 每个插件独立命名空间
    │   ├── settings.json
    │   └── cache.json
    └── com.example.another-plugin/
        └── data.json
```

---

## 八、注册表格式 (registry.json)

```json
{
    "plugins": {
        "com.example.my-plugin": {
            "version": "1.0.0",
            "enabled": true,
            "installedAt": "2025-01-15T10:30:00.000Z"
        },
        "com.example.another-plugin": {
            "version": "2.1.0",
            "enabled": false,
            "installedAt": "2025-02-20T14:00:00.000Z"
        }
    }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `version` | `string` | 插件版本号 |
| `enabled` | `boolean` | 是否启用 |
| `installedAt` | `string` | 安装时间（ISO 8601 格式） |

---

## 九、调试技巧

### 9.1 查看插件日志

插件的控制台输出为浏览器原生 console（宿主不包装、无自动前缀），可通过浏览器开发者工具或 Android Logcat 查看；建议插件日志自行添加标签（如 `[MyPlugin]`）便于过滤。

### 9.2 手动安装插件（开发模式）

在开发阶段，可以手动将插件文件放入应用数据目录：

1. 使用 Android Studio 的 Device File Explorer
2. 导航到应用数据目录：`/data/data/com.akusera.mikuplayreburn/files/plugins/`
3. 创建以插件 ID 命名的目录
4. 将 `manifest.json` 和 `index.js` 放入该目录
5. 更新 `registry.json` 添加插件条目
6. 重启应用

### 9.3 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| 插件未加载 | manifest.json 缺少必需字段 | 检查 `id`、`type` 字段是否存在 |
| 插件代码报错 | index.js 语法错误 | 在浏览器中先验证 JS 语法 |
| 纹理加载失败 | 资源路径错误 | 使用 `context.assetsDir + '/...'` 拼接路径 |
| 事件不触发 | 事件名拼写错误 | 参照 [02-api-reference.md](02-api-reference.md) 中的事件列表 |
| 样式不生效 | CSS 类名或变量名错误 | 使用宿主提供的样式类和 CSS 自定义属性 |
| ZIP 解压失败 | ZIP 结构不正确 | 确保 manifest.json 和 index.js 在 ZIP 根目录 |

---

## 十、文档信息

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v3.0 | 2026-08-21 | 与 [03-functional-plugin-guide.md](03-functional-plugin-guide.md) §1.1 同步：target 联合类型已包含 `background`（仅预留，**当前无 `PluginExecutor` shape 校验**，外部插件暂勿使用） |
| v2.0 | 2026-08-15 | 与黑名单模式重构同步，描述保持一致 |
| v1.0 | - | 初始版本 |
