# MikuPlay Reburn 插件开发指南

欢迎阅读 MikuPlay Reburn 插件开发指南。本指南将帮助你了解插件系统的设计理念、项目架构，以及如何开发自己的插件。

| 项目 | 信息 |
|------|------|
| **文档版本** | v3.0 |
| **最后更新** | 2026-08-21 |
| **适用项目版本** | mikuplay-reburn-1 |

## 文档目录

| 文件 | 内容 |
|------|------|
| [01-overview.md](01-overview.md) | 系统设计理念与项目模块简介 |
| [02-api-reference.md](02-api-reference.md) | 插件开发 API 参考（类、方法、UI 组件、数据类型） |
| [03-functional-plugin-guide.md](03-functional-plugin-guide.md) | 功能型插件开发指南与模板（地面、粒子、着色、后处理） |
| [04-ui-plugin-guide.md](04-ui-plugin-guide.md) | UI 型插件开发指南与模板 |
| [05-plugin-format.md](05-plugin-format.md) | 插件格式规范（.mkp） |
| [06-shading-plugin-guide.md](06-shading-plugin-guide.md) | 着色插件开发指南（材质适配器） |
| [07-postproc-plugin-design.md](07-postproc-plugin-design.md) | 后处理插件系统设计（已部分实现） |

## 快速开始

1. 阅读 [01-overview.md](01-overview.md) 了解系统架构
2. 根据你要开发的插件类型，阅读对应指南：
   - 功能型插件（地面、粒子）→ [03-functional-plugin-guide.md](03-functional-plugin-guide.md)
   - 着色插件（材质适配器）→ [06-shading-plugin-guide.md](06-shading-plugin-guide.md)
   - 后处理插件 → [07-postproc-plugin-design.md](07-postproc-plugin-design.md)
   - UI 型插件（面板、叠加层等）→ [04-ui-plugin-guide.md](04-ui-plugin-guide.md)
3. 参考 [02-api-reference.md](02-api-reference.md) 查询可用的 API
4. 按照 [05-plugin-format.md](05-plugin-format.md) 打包和安装插件
