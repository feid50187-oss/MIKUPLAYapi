/**
 * Light Aim Tracker - 灯光方向追踪器
 * ---------------------------------------------------------------
 * 核心思路：
 *  - 灯光位置保持不动（你自己摆好），每帧只更新 light.direction；
 *  - 目标点 = 模型某个骨骼的世界坐标（默认自动选"胸部"骨骼）；
 *  - 效果类似舞台追光灯：灯在原地，光束始终指向人物胸口；
 *  - 也支持把灯光挂到"模型中心"作为兜底（模型无骨骼时）。
 *
 * 特点：
 *  - 位置不动，从根本上避免"绑定后灯消失"的问题；
 *  - 只列 SpotLight / PointLight（Point / Hemispheric 无方向语义）；
 *  - 支持在骨骼世界坐标上叠加瞄准偏移，微调瞄准点高低；
 *  - 拖动灯位置（如灯光管理器 Gizmo）后，方向下一帧自动重新计算；
 *  - 支持多绑定并存，独立启用/解绑；
 *  - 解绑时恢复灯光原始方向；提供"恢复全部方向"按钮；
 *  - 灯光被外部 dispose 时自动解绑；scene:reset 清空全部绑定；
 *  - tick 每绑定 try/catch + 数值校验，异常不写入、不阻断其它绑定。
 *
 * v2 修复：
 *  - 关键：每帧主动调用 Skeleton.prepare()，强制刷新骨骼世界矩阵，
 *    解决"能追踪但数值不实时跟随动画"的问题；
 *  - 绑定项新增实时目标坐标显示（每 10 帧刷新一次 DOM）；
 *  - onAfterRenderObservable 兜底（若宿主暂停 onBeforeRender，可换）；
 *  - 更严格的数值校验（NaN / 超大值 / 距离过近）。
 */

var exports = {};

(function () {
    'use strict';

    var TAG = '[LightAimTrackerV6]';
    var toast = mp.ui.toast;
    var Dropdown = mp.ui.Dropdown;
    var VectorInput = mp.ui.VectorInput;

    // ---------- 状态 ----------
    var scene = null;
    var ctx = null;
    var container = null;
    var disposed = false;

    var bindings = new Map();      // id -> binding
    var bindingCounter = 0;
    var frameObserver = null;
    var unsubscribers = [];
    var bonesCache = { modelId: null, list: null };
    var frameCount = 0;
    var mmdCache = new Map();
    var lastTickTime = 0;
    var actionTrackingCheck = null;
    var smoothRange = null;
    var smoothValue = null;
    var angleRange = null;
    var angleValue = null;

    // ---------- 复用缓冲 ----------
    var _tmpDir = null;
    var _tmpScale = null;
    var _tmpQuat = null;
    var _tmpTrans = null;
    var _tmpSmooth = null;

    var MIN_DISTANCE = 0.001;

    var CHEST_KEYWORDS = [
        '上半身2', '上半身２', '胸', 'chest', '上半身',
        'spine2', 'spine1', 'spine', '首', 'neck', 'センター', 'center'
    ];

    // V6 动作追踪：优先寻找真正承担身体平移/重心的腰部、骨盆、Center。
    var WAIST_KEYWORDS = [
        '腰', 'waist', 'pelvis', 'hip', 'hips', 'lowerbody', 'lower_body',
        '下半身', 'センター', 'center'
    ];
    var ROOT_KEYWORDS = ['全ての親', '全親', 'root', '親', 'センター', 'center'];

    // ---------- UI 引用 ----------
    var lightHost = null;
    var lightDropdown = null;
    var modelHost = null;
    var modelDropdown = null;
    var boneHost = null;
    var boneDropdown = null;
    var offsetInput = null;
    var listContainer = null;
    var countLabel = null;
    var bindBtn = null;
    var bindAllBtn = null;
    var resetAllBtn = null;
    var lightTypeLabel = null;
    var pointHint = null;
    var actionHint = null;

    // ============================================================
    // 一、基础工具
    // ============================================================
    function safeCall(fn, fallback) {
        try { return fn(); } catch (e) { return fallback; }
    }

    function safeDisposeDropdown(dd) {
        if (dd && typeof dd.dispose === 'function') {
            try { dd.dispose(); } catch (e) {}
        }
    }

    function makeSectionTitle(text) {
        var el = document.createElement('div');
        el.style.cssText = 'font-size:13px;font-weight:600;color:var(--text-primary);padding-top:3px;border-top:1px solid var(--color-border);';
        el.textContent = text;
        return el;
    }

    function ensureBuffers() {
        if (!_tmpDir)   _tmpDir   = new BABYLON.Vector3(0, -1, 0);
        if (!_tmpScale) _tmpScale = new BABYLON.Vector3(1, 1, 1);
        if (!_tmpQuat)  _tmpQuat  = new BABYLON.Quaternion();
        if (!_tmpTrans) _tmpTrans = new BABYLON.Vector3(0, 0, 0);
    }

    function isVecFinite(v) {
        return !!v && isFinite(v.x) && isFinite(v.y) && isFinite(v.z);
    }

    function isAimableLight(light) {
        if (!light) return false;
        var cls = light.getClassName ? light.getClassName() : '';
        return cls === 'SpotLight' || cls === 'PointLight';
    }

    function getLightType(light) {
        var cls = light && light.getClassName ? light.getClassName() : '';
        if (cls === 'SpotLight') return 'spot';
        if (cls === 'PointLight') return 'point';
        return '';
    }

    function getLightTypeLabel(light) {
        var type = getLightType(light);
        return type === 'spot' ? '聚光灯' : (type === 'point' ? '点光灯' : '不可追踪');
    }

    function getAimableLights() {
        if (!scene || !scene.lights) return [];
        var out = [];
        for (var i = 0; i < scene.lights.length; i++) {
            var l = scene.lights[i];
            if (isAimableLight(l)) out.push(l);
        }
        out.sort(function (a, b) {
            return String(a.name || '').localeCompare(String(b.name || ''), 'zh-Hans');
        });
        return out;
    }

    // V6 聚光灯总控：只返回 SpotLight，不依赖绑定列表。
    function getAllSpotLights() {
        if (!scene || !scene.lights) return [];
        var out = [];
        for (var i = 0; i < scene.lights.length; i++) {
            var l = scene.lights[i];
            var cls = l && l.getClassName ? l.getClassName() : '';
            if (cls === 'SpotLight') out.push(l);
        }
        return out;
    }

    var globalSpotAngleRad = null;

    function applyGlobalSpotAngle() {
        if (globalSpotAngleRad === null || !isFinite(globalSpotAngleRad)) return;
        getAllSpotLights().forEach(function (l) {
            try { l.angle = globalSpotAngleRad; } catch (e) {}
        });
    }

    function syncGlobalSpotAngleFromScene() {
        var spots = getAllSpotLights();
        if (!spots.length) {
            if (globalSpotAngleRad === null) globalSpotAngleRad = 30 * Math.PI / 180;
            return;
        }
        var a = Number(spots[0].angle);
        if (isFinite(a) && a > 0) globalSpotAngleRad = a;
        if (angleRange) {
            var deg = Math.max(5, Math.min(120, globalSpotAngleRad * 180 / Math.PI));
            angleRange.value = String(Math.round(deg));
            if (angleValue) angleValue.textContent = Math.round(deg) + '°';
        }
    }

    function isLightAlive(light) {
        if (!light || !scene || !scene.lights) return false;
        return scene.lights.indexOf(light) !== -1;
    }

    function getModels() {
        try { return (mp.model.list && mp.model.list()) || []; } catch (e) { return []; }
    }

    function findModelById(id) {
        if (!id) return null;
        var list = getModels();
        for (var i = 0; i < list.length; i++) {
            if (String(list[i].id) === String(id)) return list[i];
        }
        return null;
    }

    function findLightByUid(uid) {
        if (!uid) return null;
        var list = getAimableLights();
        for (var i = 0; i < list.length; i++) {
            if (String(list[i].uniqueId) === String(uid)) return list[i];
        }
        return null;
    }

    // ============================================================
    // 二、骨骼枚举
    // ============================================================
    function collectBones(model) {
        var result = [];
        var seen = {};
        if (!model || !model.mesh) return result;
        var root = model.mesh;

        function walkMesh(mesh) {
            if (!mesh) return;
            var sk = mesh.skeleton;
            if (sk && sk.bones && sk.bones.length) {
                for (var i = 0; i < sk.bones.length; i++) {
                    var bone = sk.bones[i];
                    if (!bone) continue;
                    if (seen[bone.uniqueId]) continue;
                    seen[bone.uniqueId] = true;
                    result.push({
                        key: 'sk_' + bone.uniqueId,
                        bone: bone,
                        boneType: 'skeleton',
                        name: String(bone.name || ('骨 ' + bone.uniqueId))
                    });
                }
            }
            var kids = safeCall(function () { return mesh.getChildMeshes(false) || []; }, []);
            for (var j = 0; j < kids.length; j++) walkMesh(kids[j]);
        }
        walkMesh(root);

        if (result.length === 0) {
            var descs = safeCall(function () { return root.getDescendants(true) || []; }, []);
            for (var k = 0; k < descs.length; k++) {
                var n = descs[k];
                if (!n || !n.name) continue;
                if (n instanceof BABYLON.AbstractMesh) continue;
                if (seen[n.uniqueId]) continue;
                seen[n.uniqueId] = true;
                result.push({
                    key: 'tn_' + n.uniqueId,
                    bone: n,
                    boneType: 'transform',
                    name: String(n.name)
                });
            }
        }

        result.sort(function (a, b) {
            return String(a.name).localeCompare(String(b.name), 'ja');
        });
        return result;
    }

    function collectBonesForSelectedModel() {
        var model = getSelectedModel();
        if (!model) return [];
        var key = String(model.id);
        if (bonesCache.modelId === key && bonesCache.list) return bonesCache.list;
        var list = collectBones(model);
        bonesCache = { modelId: key, list: list };
        return list;
    }

    function pickDefaultChestBoneKey(bones) {
        if (!bones || !bones.length) return '';
        for (var p = 0; p < CHEST_KEYWORDS.length; p++) {
            var kw = CHEST_KEYWORDS[p];
            for (var i = 0; i < bones.length; i++) {
                var n = String(bones[i].name || '');
                if (n.indexOf(kw) !== -1) return bones[i].key;
            }
        }
        return '';
    }

    // ============================================================
    // V6 动作数据穿透：ModelManager -> MmdModel -> runtimeBones
    // ============================================================
    function getMmdModel(modelId) {
        var key = String(modelId || '');
        if (!key || !ctx || !ctx.app) return null;
        if (mmdCache.has(key)) return mmdCache.get(key);
        var manager = safeCall(function () { return ctx.app.getModelManager(); }, null);
        if (!manager || typeof manager.getMmdModel !== 'function') return null;
        var mmd = safeCall(function () { return manager.getMmdModel(modelId); }, null);
        if (mmd) mmdCache.set(key, mmd);
        return mmd;
    }

    function scoreWaistName(name) {
        var n = String(name || '').toLowerCase();
        for (var i = 0; i < WAIST_KEYWORDS.length; i++) {
            var kw = WAIST_KEYWORDS[i].toLowerCase();
            if (n === kw) return 10000 - i * 10;
            if (n.indexOf(kw) !== -1) return 5000 - i * 10;
        }
        for (var j = 0; j < ROOT_KEYWORDS.length; j++) {
            var rk = ROOT_KEYWORDS[j].toLowerCase();
            if (n === rk) return 1000 - j * 10;
            if (n.indexOf(rk) !== -1) return 500 - j * 10;
        }
        return -1;
    }

    function getRuntimeBones(mmd) {
        if (!mmd) return [];
        var rb = safeCall(function () { return mmd.runtimeBones; }, null);
        if (!rb) return [];
        if (Array.isArray(rb)) return rb;
        if (typeof rb.length === 'number') {
            var out = [];
            for (var i = 0; i < rb.length; i++) out.push(rb[i]);
            return out;
        }
        return [];
    }

    function findRuntimeWaist(mmd) {
        var bones = getRuntimeBones(mmd);
        if (!bones.length) return null;
        var best = null, bestScore = -1;
        for (var i = 0; i < bones.length; i++) {
            var b = bones[i];
            if (!b) continue;
            var score = scoreWaistName(b.name || b.boneName || b._name);
            if (score > bestScore) { bestScore = score; best = b; }
        }
        return best;
    }

    function getMmdRootCandidates(mmd, model) {
        var roots = [], seen = [];
        function add(x) {
            if (!x || seen.indexOf(x) !== -1) return;
            seen.push(x); roots.push(x);
        }
        if (mmd) {
            add(safeCall(function () { return mmd.mesh; }, null));
            add(safeCall(function () { return mmd.rootMesh; }, null));
            add(safeCall(function () { return mmd._rootMesh; }, null));
            add(safeCall(function () { return mmd.modelRoot; }, null));
            var meshes = safeCall(function () { return mmd.meshes; }, null);
            if (meshes && typeof meshes.length === 'number') {
                for (var i = 0; i < meshes.length; i++) add(meshes[i]);
            }
        }
        if (model) {
            add(model.mesh);
            add(model.root);
        }
        return roots;
    }

    function computeRuntimeBoneWorldPosition(mmd, runtimeBone, model, out) {
        if (!runtimeBone) return false;
        var roots = getMmdRootCandidates(mmd, model);

        // Babylon Bone 的标准世界坐标接口。不同宿主版本可能接受不同参数，因此逐个安全尝试。
        if (typeof runtimeBone.getAbsolutePositionToRef === 'function') {
            for (var i = 0; i < roots.length; i++) {
                if (!roots[i]) continue;
                var ok = safeCall(function () {
                    runtimeBone.getAbsolutePositionToRef(roots[i], out);
                    return true;
                }, false);
                if (ok && isVecFinite(out)) return true;
            }
            var okNoRoot = safeCall(function () {
                runtimeBone.getAbsolutePositionToRef(null, out);
                return true;
            }, false);
            if (okNoRoot && isVecFinite(out)) return true;
        }

        if (typeof runtimeBone.getAbsolutePosition === 'function') {
            for (var j = 0; j < roots.length; j++) {
                var p = safeCall(function () { return runtimeBone.getAbsolutePosition(roots[j]); }, null);
                if (p && isVecFinite(p)) { out.copyFrom(p); return true; }
            }
            var p0 = safeCall(function () { return runtimeBone.getAbsolutePosition(); }, null);
            if (p0 && isVecFinite(p0)) { out.copyFrom(p0); return true; }
        }

        // 某些运行时骨骼会暴露 TransformNode。
        var tn = safeCall(function () {
            return typeof runtimeBone.getTransformNode === 'function' ? runtimeBone.getTransformNode() : null;
        }, null);
        if (tn && typeof tn.getAbsolutePosition === 'function') {
            safeCall(function () { tn.computeWorldMatrix(true); }, null);
            var tp = safeCall(function () { return tn.getAbsolutePosition(); }, null);
            if (tp && isVecFinite(tp)) { out.copyFrom(tp); return true; }
        }

        // 最后尝试 runtimeBone 本身作为 TransformNode 的世界矩阵。
        if (runtimeBone.computeWorldMatrix && runtimeBone.getWorldMatrix) {
            safeCall(function () { runtimeBone.computeWorldMatrix(true); }, null);
            var wm = safeCall(function () { return runtimeBone.getWorldMatrix(); }, null);
            if (wm && wm.decompose) {
                _tmpScale.set(1,1,1); _tmpQuat.set(0,0,0,1); _tmpTrans.set(0,0,0);
                try { wm.decompose(_tmpScale, _tmpQuat, _tmpTrans); } catch (e) { return false; }
                if (isVecFinite(_tmpTrans)) { out.copyFrom(_tmpTrans); return true; }
            }
        }
        return false;
    }

    // ============================================================
    // V6.1 内部修正版：直接读取当前 MMD Runtime 的「全ての親」动画轨道。
    // 不改变插件 ID / manifest version；这是同一个 V6 的内部实现更新。
    // ============================================================
    function isMmdAnimationObject(x) {
        return !!x && (Array.isArray(x.boneTracks) || Array.isArray(x.movableBoneTracks) ||
            (x.boneTracks && typeof x.boneTracks.length === 'number'));
    }

    function getRuntimeAnimations(mmd) {
        var out = [];
        var map = safeCall(function () { return mmd && mmd.runtimeAnimations; }, null);
        if (!map) return out;
        if (typeof map.forEach === 'function') {
            safeCall(function () { map.forEach(function (v) { if (v) out.push(v); }); }, null);
        } else if (typeof map.length === 'number') {
            for (var i = 0; i < map.length; i++) if (map[i]) out.push(map[i]);
        }
        return out;
    }

    function findMmdAnimationInObject(obj, depth, seen) {
        if (!obj || depth < 0) return null;
        if (isMmdAnimationObject(obj)) return obj;
        if (typeof obj !== 'object') return null;
        if (!seen) seen = [];
        if (seen.indexOf(obj) !== -1) return null;
        seen.push(obj);
        var keys = ['animation', 'mmdAnimation', 'source', 'container', 'runtimeAnimation', '_animation', '_source'];
        for (var i = 0; i < keys.length; i++) {
            var v = safeCall(function () { return obj[keys[i]]; }, null);
            var found = findMmdAnimationInObject(v, depth - 1, seen);
            if (found) return found;
        }
        return null;
    }

    function findCurrentMmdAnimation(mmd) {
        // 官方 RuntimeAnimation API：runtimeAnimations Map 中的运行时动画持有绑定信息。
        var candidates = [];
        var current = safeCall(function () { return mmd.currentAnimation; }, null);
        if (current) candidates.push(current);
        var list = getRuntimeAnimations(mmd);
        for (var i = 0; i < list.length; i++) candidates.push(list[i]);
        for (var j = 0; j < candidates.length; j++) {
            var a = findMmdAnimationInObject(candidates[j], 3, []);
            if (a) return a;
        }
        return null;
    }

    function getMmdRuntimeCandidates() {
        var out = [];
        function add(x) { if (x && out.indexOf(x) === -1) out.push(x); }
        if (ctx && ctx.app) {
            var names = ['getMmdRuntime', 'getMMDRuntime', 'getRuntime', 'getAnimationRuntime', 'mmdRuntime', 'MmdRuntime', 'runtime'];
            for (var i = 0; i < names.length; i++) {
                var name = names[i];
                var x = safeCall(function () {
                    return typeof ctx.app[name] === 'function' ? ctx.app[name]() : ctx.app[name];
                }, null);
                add(x);
            }
        }
        if (scene) {
            add(safeCall(function () { return scene.mmdRuntime; }, null));
            add(safeCall(function () { return scene.__mmdRuntime; }, null));
        }
        return out;
    }

    function getCurrentFrameTime(mmd) {
        var runtimes = getMmdRuntimeCandidates();
        for (var i = 0; i < runtimes.length; i++) {
            var r = runtimes[i];
            var f = safeCall(function () { return Number(r.currentFrameTime); }, NaN);
            if (isFinite(f)) return f;
            var sec = safeCall(function () { return Number(r.currentTime); }, NaN);
            if (isFinite(sec)) return sec * 30;
        }
        // 某些宿主把时间直接挂在 MmdModel 上。
        var mf = safeCall(function () { return Number(mmd.currentFrameTime); }, NaN);
        if (isFinite(mf)) return mf;
        var ms = safeCall(function () { return Number(mmd.currentTime); }, NaN);
        if (isFinite(ms)) return ms * 30;
        return NaN;
    }

    function findTrackByName(animation, name) {
        if (!animation) return null;
        var groups = [animation.boneTracks, animation.movableBoneTracks];
        var names = ['全ての親', '全亲', '全ての親 ', '全親', 'All Parent', 'AllParent'];
        for (var g = 0; g < groups.length; g++) {
            var tracks = groups[g];
            if (!tracks || typeof tracks.length !== 'number') continue;
            for (var i = 0; i < tracks.length; i++) {
                var t = tracks[i];
                var tn = String(t && (t.name || t.boneName || t.targetName) || '');
                if (tn === name) return t;
                for (var n = 0; n < names.length; n++) if (tn === names[n]) return t;
            }
        }
        return null;
    }

    function getTrackFrames(track) {
        if (!track) return null;
        return track.frameNumbers || track.frames || track.frameTimes || track.keyframes || null;
    }

    function getTrackPositions(track) {
        if (!track) return null;
        return track.positions || track.positionValues || track.position || null;
    }

    function getScalar(arr, i) {
        if (!arr || i < 0 || i >= arr.length) return NaN;
        return Number(arr[i]);
    }

    // VMD/babylon-mmd 的全ての親位移是局部平移量；这里先做位置轨道采样。
    // 对没有公开插值数组的宿主，使用相邻关键帧线性插值，确保不会因为内部结构差异而失效。
    function sampleParentTrack(track, frame, out) {
        var frames = getTrackFrames(track);
        var positions = getTrackPositions(track);
        if (!frames || !positions || frames.length < 1) return false;
        var count = frames.length;
        var first = Number(frames[0]);
        if (!isFinite(first)) return false;
        if (frame <= first) {
            out.x = getScalar(positions, 0); out.y = getScalar(positions, 1); out.z = getScalar(positions, 2);
            return isVecFinite(out);
        }
        var lastIndex = count - 1;
        var lastFrame = Number(frames[lastIndex]);
        if (frame >= lastFrame) {
            out.x = getScalar(positions, lastIndex * 3); out.y = getScalar(positions, lastIndex * 3 + 1); out.z = getScalar(positions, lastIndex * 3 + 2);
            return isVecFinite(out);
        }
        var hi = 1;
        while (hi < count && Number(frames[hi]) < frame) hi++;
        var lo = hi - 1;
        var f0 = Number(frames[lo]), f1 = Number(frames[hi]);
        var t = (f1 > f0) ? (frame - f0) / (f1 - f0) : 0;
        var i0 = lo * 3, i1 = hi * 3;
        var x0 = getScalar(positions, i0), y0 = getScalar(positions, i0 + 1), z0 = getScalar(positions, i0 + 2);
        var x1 = getScalar(positions, i1), y1 = getScalar(positions, i1 + 1), z1 = getScalar(positions, i1 + 2);
        out.x = x0 + (x1 - x0) * t;
        out.y = y0 + (y1 - y0) * t;
        out.z = z0 + (z1 - z0) * t;
        return isVecFinite(out);
    }

    function getRuntimeBoneIndexByName(mmd, name) {
        var bones = getRuntimeBones(mmd);
        var target = String(name || '');
        for (var i = 0; i < bones.length; i++) {
            var b = bones[i];
            var bn = String(b && (b.name || b.boneName || b._name) || '');
            if (bn === target) return i;
        }
        // 中文/英文别名兜底
        var lower = target.toLowerCase();
        for (var j = 0; j < bones.length; j++) {
            var rb = bones[j];
            var rn = String(rb && (rb.name || rb.boneName || rb._name) || '').toLowerCase();
            if (rn === lower) return j;
        }
        return -1;
    }

    function readRuntimeMatrixTarget(mmd, model, runtimeIndex, out) {
        if (!mmd || runtimeIndex < 0) return false;
        var mats = safeCall(function () { return mmd.worldTransformMatrices; }, null);
        if (!mats) return false;

        var mat = null;
        // Float32Array / typed array：每个矩阵 16 个 float。
        if (typeof mats.length === 'number' && mats.length >= (runtimeIndex + 1) * 16) {
            try {
                if (typeof BABYLON.Matrix.FromArray === 'function') {
                    mat = BABYLON.Matrix.FromArray(mats, runtimeIndex * 16);
                } else if (typeof BABYLON.Matrix.FromArrayToRef === 'function') {
                    mat = new BABYLON.Matrix();
                    BABYLON.Matrix.FromArrayToRef(mats, runtimeIndex * 16, mat);
                }
            } catch (e) {
                mat = null;
            }
        } else if (mats[runtimeIndex]) {
            mat = mats[runtimeIndex];
        }
        if (!mat) return false;

        // MikuEngine / Babylon-MMD 的运行时骨骼矩阵属于模型空间。
        // 必须再乘模型的 WorldMatrix，才能得到真正的场景世界坐标。
        var root = safeCall(function () { return mmd.mesh || model.mesh; }, null);
        if (!root) return false;
        safeCall(function () { root.computeWorldMatrix(true); }, null);
        var modelWorld = safeCall(function () { return root.getWorldMatrix(); }, null);
        if (!modelWorld) return false;

        var world = null;
        try {
            world = mat.multiply(modelWorld);
        } catch (e) {
            return false;
        }

        if (!world || !world.decompose) return false;
        _tmpScale.set(1, 1, 1);
        _tmpQuat.set(0, 0, 0, 1);
        _tmpTrans.set(0, 0, 0);
        try { world.decompose(_tmpScale, _tmpQuat, _tmpTrans); } catch (e) { return false; }
        if (!isVecFinite(_tmpTrans)) return false;

        out.copyFrom(_tmpTrans);
        return true;
    }

    function computeModelWorldPosition(model, mmd, out) {
        var root = safeCall(function () { return (mmd && mmd.mesh) || (model && model.mesh); }, null);
        if (!root) return false;
        safeCall(function () { root.computeWorldMatrix(true); }, null);
        var wm = safeCall(function () { return root.getWorldMatrix(); }, null);
        if (wm && wm.decompose) {
            _tmpScale.set(1, 1, 1);
            _tmpQuat.set(0, 0, 0, 1);
            _tmpTrans.set(0, 0, 0);
            try { wm.decompose(_tmpScale, _tmpQuat, _tmpTrans); } catch (e) { return false; }
            if (isVecFinite(_tmpTrans)) {
                out.copyFrom(_tmpTrans);
                return true;
            }
        }
        var p = safeCall(function () { return root.getAbsolutePosition ? root.getAbsolutePosition() : null; }, null);
        if (p && isVecFinite(p)) {
            out.copyFrom(p);
            return true;
        }
        return false;
    }

    function computeActionTargetWorldPosition(binding, out) {
        var model = findModelById(binding.modelId);
        if (!model) return false;

        var mmd = getMmdModel(binding.modelId);
        if (!mmd) return false;

        /*
         * V6 核心修正：
         * 不读取 bone.position，也不计算“上一帧/当前帧”的骨骼坐标变化量。
         *
         * 按 babylon-mmd 官方开发指南，MmdRuntimeBone 的 worldMatrix
         * 是模型空间中的骨骼世界变换；要得到真正的场景世界坐标，
         * 必须：
         *
         *   bone.getWorldMatrixToRef(boneWorldMatrix)
         *       .multiplyToRef(meshWorldMatrix, boneWorldMatrix)
         *   boneWorldMatrix.getTranslationToRef(worldPosition)
         *
         * 这样当 MikuEngine 的模型根 Transform 移动模型，而骨骼自身
         * 的局部坐标变化为 0 时，模型 mesh 的 WorldMatrix 仍然会把
         * 这次整体移动带入最终世界坐标。
         */

        var bones = getRuntimeBones(mmd);
        if (!bones || !bones.length) return false;

        var targetName = String(binding.targetName || '');
        var targetBone = null;

        // 如果当前绑定已有明确的骨骼目标，优先使用它。
        if (targetName) {
            for (var i = 0; i < bones.length; i++) {
                var b = bones[i];
                if (String(b && b.name || '') === targetName) {
                    targetBone = b;
                    break;
                }
            }
        }

        // 动作追踪没有明确骨骼时，优先 Center；再退到全ての親/根。
        if (!targetBone) {
            var preferred = ['センター', 'Center', 'センター先', '全ての親', '全亲', '全親', 'All Parent', 'AllParent'];
            for (var p = 0; p < preferred.length && !targetBone; p++) {
                for (var j = 0; j < bones.length; j++) {
                    var pb = bones[j];
                    if (String(pb && pb.name || '') === preferred[p]) {
                        targetBone = pb;
                        break;
                    }
                }
            }
        }

        if (!targetBone) return false;

        // 官方推荐路径：直接读取 MmdRuntimeBone 的 WorldMatrix。
        var boneWorldMatrix = safeCall(function () {
            return new BABYLON.Matrix();
        }, null);
        if (!boneWorldMatrix) return false;

        var mesh = safeCall(function () { return mmd.mesh || model.mesh; }, null);
        if (!mesh) return false;

        safeCall(function () { mesh.computeWorldMatrix(true); }, null);
        var meshWorldMatrix = safeCall(function () { return mesh.getWorldMatrix(); }, null);
        if (!meshWorldMatrix) return false;

        var gotMatrix = false;

        if (typeof targetBone.getWorldMatrixToRef === 'function') {
            try {
                targetBone.getWorldMatrixToRef(boneWorldMatrix);
                boneWorldMatrix.multiplyToRef(meshWorldMatrix, boneWorldMatrix);
                gotMatrix = true;
            } catch (e) {
                gotMatrix = false;
            }
        }

        // 官方 API 直接提供的 WorldTranslation 作为兼容兜底。
        // 注意：优先仍然使用上面的“骨骼 WorldMatrix × Mesh WorldMatrix”路径。
        if (gotMatrix && typeof boneWorldMatrix.getTranslationToRef === 'function') {
            try {
                boneWorldMatrix.getTranslationToRef(out);
                if (isVecFinite(out)) {
                    binding.actionSource = 'MikuEngine:MmdRuntimeBone.worldMatrix';
                    binding.runtimeBone = targetBone;
                    binding.runtimeBoneName = String(targetBone.name || '');
                    return true;
                }
            } catch (e) {}
        }

        if (typeof targetBone.getWorldTranslationToRef === 'function') {
            try {
                targetBone.getWorldTranslationToRef(out);
                if (isVecFinite(out)) {
                    // 某些宿主实现可能已经把 Mesh WorldMatrix 纳入此 API。
                    binding.actionSource = 'MikuEngine:MmdRuntimeBone.getWorldTranslationToRef';
                    binding.runtimeBone = targetBone;
                    binding.runtimeBoneName = String(targetBone.name || '');
                    return true;
                }
            } catch (e) {}
        }

        return false;
    }

    function getSmoothResponse() {
        var v = smoothRange ? Number(smoothRange.value) : 0.35;
        if (!isFinite(v)) v = 0.35;
        return Math.max(0.05, Math.min(1, v));
    }

    function smoothTarget(binding, target, dt) {
        if (!binding._smoothPos) binding._smoothPos = target.clone();
        if (!isVecFinite(binding._smoothPos)) binding._smoothPos.copyFrom(target);
        var response = getSmoothResponse();
        var alpha = 1 - Math.exp(-response * 12 * Math.max(0.001, Math.min(dt, 0.1)));
        alpha = Math.max(0.001, Math.min(1, alpha));
        binding._smoothPos.x += (target.x - binding._smoothPos.x) * alpha;
        binding._smoothPos.y += (target.y - binding._smoothPos.y) * alpha;
        binding._smoothPos.z += (target.z - binding._smoothPos.z) * alpha;
        return binding._smoothPos;
    }

    // ============================================================
    // 三、当前选中项
    // ============================================================
    function getSelectedModel() {
        if (!modelDropdown) return null;
        return findModelById(modelDropdown.getValue());
    }

    function getSelectedLight() {
        if (!lightDropdown) return null;
        return findLightByUid(lightDropdown.getValue());
    }

    function getSelectedBoneEntry() {
        if (!boneDropdown) return null;
        var key = boneDropdown.getValue();
        if (!key) return null;
        var list = collectBonesForSelectedModel();
        for (var i = 0; i < list.length; i++) {
            if (list[i].key === key) return list[i];
        }
        return null;
    }

    // ============================================================
    // 四、骨骼世界矩阵 / 世界坐标
    // ============================================================
    /**
     * 关键：主动刷新骨架，让 _absoluteMatrix 反映当前动画帧。
     * 只对用到的骨架调用一次（去重）。
     */
    function prepareAllBoundSkeletons() {
        var seen = {};
        bindings.forEach(function (b) {
            if (!b.enabled) return;
            if (b.boneType !== 'skeleton' || !b.root) return;
            var sk = safeCall(function () { return b.root.skeleton; }, null);
            if (!sk || seen[sk.uniqueId]) return;
            seen[sk.uniqueId] = true;
            safeCall(function () { sk.prepare(); }, null);
        });
    }

    function computeBoneWorldMatrix(binding) {
        var bone = binding.bone;
        var rootMesh = binding.root;
        if (!bone) return null;

        if (binding.boneType === 'skeleton') {
            var am = safeCall(function () {
                return (typeof bone.getAbsoluteMatrix === 'function') ? bone.getAbsoluteMatrix() : null;
            }, null);
            if (!am) return null;

            var wm = null;
            if (rootMesh) {
                safeCall(function () { rootMesh.computeWorldMatrix(true); }, null);
                wm = safeCall(function () { return rootMesh.getWorldMatrix(); }, null);
            }
            if (wm) {
                // 行向量约定：v_world = (0,0,0,1) × am × wm
                return am.multiply(wm);
            }
            return am.clone ? am.clone() : am;
        }

        if (bone.computeWorldMatrix && bone.getWorldMatrix) {
            safeCall(function () { bone.computeWorldMatrix(true); }, null);
            return safeCall(function () { return bone.getWorldMatrix(); }, null);
        }
        return null;
    }

    function computeTargetWorldPosition(binding, out) {
        ensureBuffers();

        // V6：勾选动作数据追踪后，读取 MmdRuntimeBone 的最终 WorldMatrix。
        if (binding.actionTracking) {
            if (computeActionTargetWorldPosition(binding, out)) return true;
        }

        if (binding.useRoot || !binding.bone) {
            var root = binding.root;
            if (!root) return false;
            safeCall(function () { root.computeWorldMatrix(true); }, null);
            var ap = safeCall(function () { return root.getAbsolutePosition(); }, null);
            if (!ap || !isVecFinite(ap)) return false;
            out.x = ap.x; out.y = ap.y; out.z = ap.z;
            return true;
        }

        var wm = computeBoneWorldMatrix(binding);
        if (!wm) return false;

        _tmpScale.set(1, 1, 1);
        _tmpQuat.set(0, 0, 0, 1);
        _tmpTrans.set(0, 0, 0);
        try {
            wm.decompose(_tmpScale, _tmpQuat, _tmpTrans);
        } catch (e) {
            return false;
        }
        if (!isVecFinite(_tmpTrans)) return false;

        out.x = _tmpTrans.x;
        out.y = _tmpTrans.y;
        out.z = _tmpTrans.z;
        return true;
    }

    // ============================================================
    // 五、每帧更新
    //    - SpotLight：位置不动，只更新 direction
    //    - PointLight：位置跟随目标 + X/Y/Z 偏移，不更新 direction
    // ============================================================
    function tick() {
        if (disposed) return;
        if (!bindings.size) return;
        if (!scene || !scene.lights) return;

        ensureBuffers();
        frameCount++;
        var now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
        var dt = lastTickTime ? (now - lastTickTime) / 1000 : (1 / 60);
        lastTickTime = now;
        if (!isFinite(dt) || dt <= 0) dt = 1 / 60;
        dt = Math.min(dt, 0.1);
        prepareAllBoundSkeletons();

        var invalidIds = null;

        bindings.forEach(function (b, id) {
            if (!b.enabled) return;
            if (!b.light || !b.light.position) return;
            if (!isLightAlive(b.light)) {
                if (!invalidIds) invalidIds = [];
                invalidIds.push(id);
                return;
            }

            try {
                if (!b._targetPos) b._targetPos = new BABYLON.Vector3(0, 0, 0);
                if (!computeTargetWorldPosition(b, b._targetPos)) {
                    b._badCount = (b._badCount || 0) + 1;
                    if (b._badCount === 30 && !b._warned) {
                        b._warned = true;
                        toast.info('目标位置读取异常，该绑定暂不生效：' + b.modelName, 2600);
                    }
                    return;
                }
                b._badCount = 0;
                b._warned = false;

                var targetPos = b.actionTracking ? smoothTarget(b, b._targetPos, dt) : b._targetPos;
                var tx = targetPos.x + b.offset.x;
                var ty = targetPos.y + b.offset.y;
                var tz = targetPos.z + b.offset.z;
                if (!isFinite(tx) || !isFinite(ty) || !isFinite(tz)) return;

                if (b.lightType === 'point') {
                    // 点光灯没有方向语义：直接跟随目标世界位置。
                    b.light.position.x = tx;
                    b.light.position.y = ty;
                    b.light.position.z = tz;
                    return;
                }

                // 聚光灯：位置保持原地，只改变方向。
                if (b.lightType === 'spot' && b.light.direction) {
                    var dx = tx - b.light.position.x;
                    var dy = ty - b.light.position.y;
                    var dz = tz - b.light.position.z;
                    var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (!isFinite(len) || len < MIN_DISTANCE) return;
                    _tmpDir.set(dx / len, dy / len, dz / len);
                    if (!isVecFinite(_tmpDir)) return;
                    b.light.direction.copyFrom(_tmpDir);
                }
            } catch (e) {
                console.warn(TAG, 'tick 单绑定异常，已跳过:', b.lightName, e);
            }
        });

        // 总控角度独立于绑定列表，确保未绑定的 SpotLight 也能受控。
        applyGlobalSpotAngle();

        if (invalidIds && invalidIds.length) {
            setTimeout(function () {
                if (disposed) return;
                var names = [];
                invalidIds.forEach(function (id) {
                    var b = bindings.get(id);
                    if (b) {
                        names.push(b.lightName);
                        unbind(id, { silent: true, restore: false });
                    }
                });
                if (names.length) {
                    toast.info('灯光已被删除，自动解绑 ' + names.length + ' 项', 2400);
                }
            }, 0);
        }
    }

    // ============================================================
    // 六、下拉刷新
    // ============================================================
    function refreshLightDropdown() {
        if (!lightHost) return;
        var prev = lightDropdown ? safeCall(function () { return lightDropdown.getValue(); }, '') : '';

        var lights = getAimableLights();
        var options = lights.map(function (l) {
            return {
                value: String(l.uniqueId),
                label: l.name || ('灯 ' + l.uniqueId)
            };
        });
        if (options.length === 0) {
            options = [{ value: '', label: '— 无可追踪灯光 —' }];
        }

        safeDisposeDropdown(lightDropdown);
        lightHost.innerHTML = '';
        var keep = prev && options.some(function (o) { return o.value === prev; }) ? prev : options[0].value;
        lightDropdown = new Dropdown({
            options: options,
            selectedValue: keep,
            placeholder: '选择灯光'
        });
        lightDropdown.onChange(function () { updateSelectedLightUI(); });
        lightHost.appendChild(lightDropdown.element);
        updateSelectedLightUI();
        syncGlobalSpotAngleFromScene();
    }

    function refreshModelDropdown() {
        if (!modelHost) return;
        var prev = modelDropdown ? safeCall(function () { return modelDropdown.getValue(); }, '') : '';

        var models = getModels().filter(function (m) { return m && m.mesh; });
        var options = models.map(function (m) {
            return { value: String(m.id), label: m.name || String(m.id) };
        });
        if (options.length === 0) {
            options = [{ value: '', label: '— 场景中暂无模型 —' }];
        }

        safeDisposeDropdown(modelDropdown);
        modelHost.innerHTML = '';
        var keep = prev && options.some(function (o) { return o.value === prev; }) ? prev : options[0].value;
        modelDropdown = new Dropdown({
            options: options,
            selectedValue: keep,
            placeholder: '选择模型'
        });
        modelDropdown.onChange(function () {
            bonesCache = { modelId: null, list: null };
            refreshBoneDropdown();
        });
        modelHost.appendChild(modelDropdown.element);
    }

    function refreshBoneDropdown() {
        if (!boneHost) return;
        var prevKey = boneDropdown ? safeCall(function () { return boneDropdown.getValue(); }, '') : null;

        var bones = collectBonesForSelectedModel();

        var options = [{ value: '', label: '【模型中心】' }];
        for (var i = 0; i < bones.length; i++) {
            options.push({ value: bones[i].key, label: bones[i].name });
        }

        var keep;
        if (prevKey !== null && options.some(function (o) { return o.value === prevKey; })) {
            keep = prevKey;
        } else {
            keep = pickDefaultChestBoneKey(bones);
        }

        safeDisposeDropdown(boneDropdown);
        boneHost.innerHTML = '';
        boneDropdown = new Dropdown({
            options: options,
            selectedValue: keep,
            placeholder: '选择瞄准目标'
        });
        boneHost.appendChild(boneDropdown.element);
    }

    // ============================================================
    // 七、绑定 / 解绑
    // ============================================================
    function hasBindingForLight(light) {
        var found = null;
        bindings.forEach(function (b, id) {
            if (b.light === light) found = id;
        });
        return found;
    }

    function createBinding(light, model, boneEntry, offset) {
        if (!light || !model) return false;
        var lightType = getLightType(light);
        if (!lightType) return false;
        if (hasBindingForLight(light)) return false;

        bindingCounter++;
        var id = 'la_' + Date.now() + '_' + bindingCounter;
        var useRoot = !boneEntry;
        var binding = {
            id: id,
            light: light,
            lightName: light.name || ('灯 ' + light.uniqueId),
            lightType: lightType,
            modelId: model.id,
            modelName: model.name || String(model.id),
            root: model.mesh,
            bone: boneEntry ? boneEntry.bone : null,
            boneType: boneEntry ? boneEntry.boneType : null,
            targetName: boneEntry ? boneEntry.name : '模型中心',
            useRoot: useRoot,
            offset: {
                x: Number(offset[0]) || 0,
                y: Number(offset[1]) || 0,
                z: Number(offset[2]) || 0
            },
            enabled: true,
            uiElement: null,
            _targetPos: new BABYLON.Vector3(0, 0, 0),
            _badCount: 0,
            _warned: false,
            actionTracking: !!(actionTrackingCheck && actionTrackingCheck.checked),
            runtimeBone: null,
            runtimeBoneName: '',
            _smoothPos: null,
            originalDirection: light.direction ? light.direction.clone() : null
        };

        try {
            if (!computeTargetWorldPosition(binding, binding._targetPos)) {
                toast.error('目标位置读取异常，绑定已取消。', 2600);
                return false;
            }
        } catch (e) {
            toast.error('目标位置读取异常，绑定已取消。', 2600);
            return false;
        }

        bindings.set(id, binding);
        addBindingToUI(binding);
        updateCount();
        return true;
    }

    function doBind() {
        var light = getSelectedLight();
        var model = getSelectedModel();
        var boneEntry = getSelectedBoneEntry();
        var offset = offsetInput ? offsetInput.getValue() : [0, 0, 0];

        if (!light) { toast.info('请先选择一个灯光', 1800); return; }
        if (!model) { toast.info('请先选择一个模型', 1800); return; }
        if (hasBindingForLight(light)) {
            toast.info('该灯光已存在绑定，请先解除', 2000);
            return;
        }

        if (createBinding(light, model, boneEntry, offset)) {
            tick();
            toast.success('已绑定：' + light.name + ' → ' + model.name, 2200);
        }
    }

    function bindAllSpotlights() {
        var model = getSelectedModel();
        var boneEntry = getSelectedBoneEntry();
        var offset = offsetInput ? offsetInput.getValue() : [0, 0, 0];
        if (!model) { toast.info('请先选择一个模型', 1800); return; }

        var lights = getAimableLights();
        var added = 0;
        for (var i = 0; i < lights.length; i++) {
            if (getLightType(lights[i]) !== 'spot') continue;
            if (createBinding(lights[i], model, boneEntry, offset)) added++;
        }
        tick();
        refreshBindingList();
        toast.success(added ? ('已将 ' + added + ' 个聚光灯绑定到 ' + model.name) : '没有新的聚光灯可绑定', 2200);
    }

    function unbind(id, opts) {
        opts = opts || {};
        var b = bindings.get(id);
        if (!b) return;

        if (opts.restore !== false && b.light && b.lightType === 'spot' && b.light.direction && b.originalDirection) {
            try { b.light.direction.copyFrom(b.originalDirection); } catch (e) {}
        }

        if (b.uiElement && b.uiElement.parentNode) b.uiElement.parentNode.removeChild(b.uiElement);
        b.uiElement = null;
        b.light = null;
        b.bone = null;
        b.root = null;
        bindings.delete(id);
        updateCount();

        if (!opts.silent) toast.info('已解除绑定：' + b.lightName, 1800);
    }

    function resetAllDirections() {
        var n = 0;
        bindings.forEach(function (b) {
            if (b.light && b.lightType === 'spot' && b.light.direction) {
                try {
                    b.light.direction.set(0, -1, 0);
                    n++;
                } catch (e) {}
            }
        });

        // 恢复默认方向后必须停止追踪，否则下一帧会立即被追踪逻辑覆盖。
        Array.from(bindings.keys()).forEach(function (id) {
            var b = bindings.get(id);
            if (b && b.lightType === 'spot') {
                unbind(id, { silent: true, restore: false });
            }
        });
        refreshBindingList();

        if (n) toast.success('已停止聚光灯追踪，并将 ' + n + ' 盏聚光灯恢复为默认向下方向', 2600);
        else toast.info('当前没有正在追踪的聚光灯', 1800);
    }

    function setBindingEnabled(id, enabled) {
        var b = bindings.get(id);
        if (!b) return;
        b.enabled = !!enabled;
    }

    function setBindingOffset(id, arr) {
        var b = bindings.get(id);
        if (!b) return;
        b.offset = {
            x: Number(arr[0]) || 0,
            y: Number(arr[1]) || 0,
            z: Number(arr[2]) || 0
        };
    }

    // ============================================================
    // 八、绑定列表 UI（紧凑三列）
    // ============================================================
    function addBindingToUI(b) {
        if (!listContainer) return;

        var item = document.createElement('div');
        item.className = 'lat-binding-item';
        item.style.cssText = [
            'min-height:34px','box-sizing:border-box','display:grid',
            'grid-template-columns:minmax(0,1fr) minmax(0,1fr) auto',
            'align-items:center','gap:6px','padding:4px 6px',
            'border-bottom:1px solid var(--color-border)',
            'font-size:12px'
        ].join(';');

        var lightEl = document.createElement('div');
        lightEl.style.cssText = 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-primary);';
        lightEl.textContent = b.lightName;
        lightEl.title = b.lightName + ' · ' + getLightTypeLabel(b.light);
        item.appendChild(lightEl);

        var modelEl = document.createElement('div');
        modelEl.style.cssText = 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-secondary);';
        modelEl.textContent = b.modelName;
        modelEl.title = b.modelName + ' · ' + b.targetName;
        item.appendChild(modelEl);

        var delBtn = document.createElement('button');
        delBtn.className = 'mp-btn danger small';
        delBtn.textContent = '解除';
        delBtn.style.cssText = 'min-width:42px;height:26px;padding:2px 7px;font-size:11px;flex:0 0 auto;';
        delBtn.addEventListener('click', function () { unbind(b.id); });
        item.appendChild(delBtn);

        b.uiElement = item;
        listContainer.appendChild(item);
    }

    function refreshBindingList() {
        if (!listContainer) return;
        listContainer.innerHTML = '';
        bindings.forEach(function (b) { addBindingToUI(b); });
        updateCount();
    }

    function updateCount() {
        if (countLabel) countLabel.textContent = '(' + bindings.size + ')';
    }

    // ============================================================
    // 九、UI 构建
    // ============================================================
    function buildUI() {
        container = document.createElement('div');
        container.style.cssText = [
            'padding:12px','display:flex','flex-direction:column','gap:9px',
            'height:100%','overflow-y:auto','box-sizing:border-box',
            'color:var(--text-primary)'
        ].join(';');

        var title = document.createElement('div');
        title.style.cssText = 'font-size:16px;font-weight:700;color:var(--text-primary);';
        title.textContent = '灯光方向追踪器';
        container.appendChild(title);

        var tip = document.createElement('div');
        tip.style.cssText = 'font-size:11px;line-height:1.5;color:var(--text-secondary);';
        tip.textContent = '聚光灯追踪方向；点光灯跟随人物位置。方向光和环境光不参与绑定。';
        container.appendChild(tip);

        var lightLabel = document.createElement('div');
        lightLabel.style.cssText = 'font-size:12px;color:var(--text-secondary);';
        lightLabel.textContent = '灯光';
        container.appendChild(lightLabel);
        lightHost = document.createElement('div');
        container.appendChild(lightHost);

        lightTypeLabel = document.createElement('div');
        lightTypeLabel.style.cssText = 'font-size:11px;color:var(--text-secondary);min-height:16px;';
        container.appendChild(lightTypeLabel);

        var modelLabel = document.createElement('div');
        modelLabel.style.cssText = 'font-size:12px;color:var(--text-secondary);';
        modelLabel.textContent = '目标人物';
        container.appendChild(modelLabel);
        modelHost = document.createElement('div');
        container.appendChild(modelHost);

        var boneLabel = document.createElement('div');
        boneLabel.style.cssText = 'font-size:12px;color:var(--text-secondary);';
        boneLabel.textContent = '追踪目标（默认自动选择胸部骨骼）';
        container.appendChild(boneLabel);
        boneHost = document.createElement('div');
        container.appendChild(boneHost);

        offsetInput = new VectorInput({
            label: '位置 / 瞄准偏移（世界坐标）',
            components: [
                { name: 'X', value: 0, min: -200, max: 200, step: 0.1 },
                { name: 'Y', value: 0, min: -200, max: 200, step: 0.1 },
                { name: 'Z', value: 0, min: -200, max: 200, step: 0.1 }
            ]
        });
        container.appendChild(offsetInput.element);

        pointHint = document.createElement('div');
        pointHint.style.cssText = 'display:none;font-size:10px;line-height:1.4;color:var(--text-secondary);';
        pointHint.textContent = '点光灯会跟随目标位置；X/Y/Z 为相对目标的位置偏移，例如 Y=4 表示位于人物上方 4 个单位。';
        container.appendChild(pointHint);

        bindBtn = document.createElement('button');
        bindBtn.className = 'mp-btn primary';
        bindBtn.style.cssText = 'width:100%;min-height:40px;font-size:14px;font-weight:600;';
        bindBtn.textContent = '＋ 瞄准 / 跟随该目标';
        bindBtn.addEventListener('click', doBind);
        container.appendChild(bindBtn);

        bindAllBtn = document.createElement('button');
        bindAllBtn.className = 'mp-btn';
        bindAllBtn.style.cssText = 'width:100%;min-height:36px;font-size:13px;';
        bindAllBtn.textContent = '所有聚光灯瞄准该目标';
        bindAllBtn.addEventListener('click', bindAllSpotlights);
        container.appendChild(bindAllBtn);

        var allHint = document.createElement('div');
        allHint.style.cssText = 'font-size:10px;color:var(--text-secondary);margin-top:-5px;';
        allHint.textContent = '仅适用于聚光灯';
        container.appendChild(allHint);

        resetAllBtn = document.createElement('button');
        resetAllBtn.className = 'mp-btn';
        resetAllBtn.style.cssText = 'width:100%;min-height:36px;font-size:12px;';
        resetAllBtn.textContent = '↺ 停止追踪并恢复聚光灯默认方向 ↓';
        resetAllBtn.addEventListener('click', resetAllDirections);
        container.appendChild(resetAllBtn);

        // ================= V6 增量功能 =================
        var v6Title = makeSectionTitle('V6 动作数据追踪');
        container.appendChild(v6Title);

        var actionWrap = document.createElement('label');
        actionWrap.style.cssText = 'display:flex;align-items:center;gap:7px;min-height:30px;font-size:12px;color:var(--text-primary);cursor:pointer;';
        actionTrackingCheck = document.createElement('input');
        actionTrackingCheck.type = 'checkbox';
        actionWrap.appendChild(actionTrackingCheck);
        var actionText = document.createElement('span');
        actionText.textContent = '解析动作数据追踪';
        actionWrap.appendChild(actionText);
        container.appendChild(actionWrap);
        actionTrackingCheck.addEventListener('change', function () {
            bindings.forEach(function (b) {
                b.actionTracking = !!actionTrackingCheck.checked;
                b._smoothPos = null;
                b.runtimeBone = null;
            });
        });

        actionHint = document.createElement('div');
        actionHint.style.cssText = 'font-size:10px;line-height:1.4;color:var(--text-secondary);margin-top:-4px;';
        actionHint.textContent = '读取 MikuEngine/MMD Runtime 的最终模型/骨骼世界变换；不修改根节点、模型和物理数据。';
        container.appendChild(actionHint);

        var smooth = document.createElement('div');
        smooth.style.cssText = 'display:flex;align-items:center;gap:8px;min-height:28px;';
        var smoothLabel = document.createElement('span');
        smoothLabel.textContent = '动作惯性';
        smoothLabel.style.cssText = 'font-size:11px;color:var(--text-secondary);min-width:52px;';
        smooth.appendChild(smoothLabel);
        smoothRange = document.createElement('input');
        smoothRange.type = 'range';
        smoothRange.min = '0.05'; smoothRange.max = '1'; smoothRange.step = '0.05'; smoothRange.value = '0.35';
        smoothRange.style.cssText = 'flex:1;min-width:80px;';
        smoothValue = document.createElement('span');
        smoothValue.textContent = '0.35';
        smoothValue.style.cssText = 'font-size:10px;color:var(--text-secondary);width:30px;text-align:right;';
        smooth.appendChild(smoothRange); smooth.appendChild(smoothValue);
        smoothRange.addEventListener('input', function () { smoothValue.textContent = Number(smoothRange.value).toFixed(2); });
        container.appendChild(smooth);

        var smoothHint = document.createElement('div');
        smoothHint.style.cssText = 'font-size:10px;color:var(--text-secondary);margin-top:-4px;';
        smoothHint.textContent = '数值越低惯性越强、动作越柔和；数值越高跟随越快。';
        container.appendChild(smoothHint);

        var angleTitle = document.createElement('div');
        angleTitle.style.cssText = 'font-size:12px;font-weight:600;color:var(--text-primary);margin-top:2px;';
        angleTitle.textContent = '聚光灯总控制器';
        container.appendChild(angleTitle);

        var angleRow = document.createElement('div');
        angleRow.style.cssText = 'display:flex;align-items:center;gap:8px;min-height:28px;';
        var angleLabel = document.createElement('span');
        angleLabel.textContent = '照射角度';
        angleLabel.style.cssText = 'font-size:11px;color:var(--text-secondary);min-width:52px;';
        angleRange = document.createElement('input');
        angleRange.type = 'range'; angleRange.min = '5'; angleRange.max = '120'; angleRange.step = '1';
        angleRange.value = '30'; angleRange.style.cssText = 'flex:1;min-width:80px;';
        angleValue = document.createElement('span');
        angleValue.textContent = '30°';
        angleValue.style.cssText = 'font-size:10px;color:var(--text-secondary);width:32px;text-align:right;';
        angleRow.appendChild(angleLabel); angleRow.appendChild(angleRange); angleRow.appendChild(angleValue);
        angleRange.addEventListener('input', function () {
            var d = Number(angleRange.value);
            if (!isFinite(d)) return;
            d = Math.max(5, Math.min(120, d));
            angleValue.textContent = Math.round(d) + '°';
            globalSpotAngleRad = d * Math.PI / 180;
            applyGlobalSpotAngle();
        });
        syncGlobalSpotAngleFromScene();
        container.appendChild(angleRow);
        var angleHint = document.createElement('div');
        angleHint.style.cssText = 'font-size:10px;color:var(--text-secondary);margin-top:-4px;';
        angleHint.textContent = '统一修改场景内全部聚光灯的照射角度，不改变位置和追踪方向。';
        container.appendChild(angleHint);

        var listTitle = document.createElement('div');
        listTitle.style.cssText = 'display:flex;justify-content:space-between;align-items:center;font-size:13px;font-weight:600;color:var(--text-primary);margin-top:3px;';
        var listTitleText = document.createElement('span');
        listTitleText.textContent = '当前绑定';
        listTitle.appendChild(listTitleText);
        countLabel = document.createElement('span');
        countLabel.style.cssText = 'font-size:11px;color:var(--text-secondary);';
        countLabel.textContent = '(0)';
        listTitle.appendChild(countLabel);
        container.appendChild(listTitle);

        var header = document.createElement('div');
        header.style.cssText = 'display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr) auto;gap:6px;padding:2px 6px;font-size:10px;color:var(--text-secondary);';
        header.innerHTML = '<span>灯光</span><span>绑定人物</span><span>操作</span>';
        container.appendChild(header);

        listContainer = document.createElement('div');
        listContainer.style.cssText = 'display:flex;flex-direction:column;border-top:1px solid var(--color-border);';
        container.appendChild(listContainer);

        refreshLightDropdown();
        refreshModelDropdown();
        refreshBoneDropdown();
        updateSelectedLightUI();

        return container;
    }

    function updateSelectedLightUI() {
        var light = getSelectedLight();
        var type = getLightType(light);
        if (lightTypeLabel) lightTypeLabel.textContent = light ? ('灯光类型：' + getLightTypeLabel(light)) : '灯光类型：未选择';
        if (pointHint) pointHint.style.display = type === 'point' ? 'block' : 'none';
        if (bindBtn) bindBtn.textContent = type === 'point' ? '＋ 跟随该目标' : '＋ 瞄准该目标';
        if (bindAllBtn) {
            bindAllBtn.style.display = 'block';
            bindAllBtn.disabled = type !== 'spot';
            bindAllBtn.style.opacity = type === 'spot' ? '1' : '0.5';
        }
    }

    // ============================================================
    // 十、生命周期
    // ============================================================
    exports.createPanel = function (context) {
        ctx = context;
        scene = context.scene;

        buildUI();

        // ★ 用 onBeforeRender 触发；tick 内主动刷新骨架
        frameObserver = scene.onBeforeRenderObservable.add(tick);

        try {
            var unModel = mp.model.onChanged(function () {
                setTimeout(function () {
                    if (disposed) return;
                    refreshModelDropdown();
                    refreshBoneDropdown();
                }, 0);
            });
            if (typeof unModel === 'function') unsubscribers.push(unModel);
        } catch (e) {
            console.warn(TAG, 'mp.model.onChanged 订阅失败:', e);
        }

        try {
            var unLoaded = context.eventBus.on('model:loaded', function () {
                setTimeout(function () {
                    if (disposed) return;
                    refreshModelDropdown();
                    refreshBoneDropdown();
                }, 0);
            });
            if (typeof unLoaded === 'function') unsubscribers.push(unLoaded);

            var unRemoved = context.eventBus.on('model:removed', function () {
                setTimeout(function () {
                    if (disposed) return;
                    refreshModelDropdown();
                    refreshBoneDropdown();
                    var toRemove = [];
                    bindings.forEach(function (b, id) {
                        if (!findModelById(b.modelId)) toRemove.push(id);
                    });
                    toRemove.forEach(function (id) {
                        unbind(id, { silent: true, restore: true });
                    });
                }, 0);
            });
            if (typeof unRemoved === 'function') unsubscribers.push(unRemoved);

            var unReset = context.eventBus.on('scene:reset', function () {
                setTimeout(function () {
                    if (disposed) return;
                    var had = bindings.size;
                    Array.from(bindings.keys()).forEach(function (id) {
                        unbind(id, { silent: true, restore: false });
                    });
                    refreshLightDropdown();
                    if (had > 0) toast.info('场景已重置，' + had + ' 项追踪已清除', 2400);
                }, 0);
            });
            if (typeof unReset === 'function') unsubscribers.push(unReset);
        } catch (e) {
            console.warn(TAG, 'eventBus 订阅失败:', e);
        }

        return container;
    };

    exports.onShown = function () {
        refreshLightDropdown();
        refreshModelDropdown();
        refreshBoneDropdown();
    };

    exports.onHidden = function () {
        // 面板切走但追踪继续。
    };

    exports.dispose = function () {
        disposed = true;
        if (frameObserver) {
            try { scene.onBeforeRenderObservable.remove(frameObserver); } catch (e) {}
            frameObserver = null;
        }
        unsubscribers.forEach(function (fn) { try { fn(); } catch (e) {} });
        unsubscribers = [];

        bindings.forEach(function (b) {
            if (b.uiElement && b.uiElement.parentNode) b.uiElement.parentNode.removeChild(b.uiElement);
            b.uiElement = null;
            b.light = null;
            b.bone = null;
            b.root = null;
            b._debugEl = null;
        });
        bindings.clear();
        bonesCache = { modelId: null, list: null };

        safeDisposeDropdown(lightDropdown);
        safeDisposeDropdown(modelDropdown);
        safeDisposeDropdown(boneDropdown);
        lightDropdown = null;
        modelDropdown = null;
        boneDropdown = null;
        offsetInput = null;
        listContainer = null;
        countLabel = null;
        lightHost = null;
        modelHost = null;
        boneHost = null;
        bindBtn = null;
        bindAllBtn = null;
        resetAllBtn = null;
        lightTypeLabel = null;
        pointHint = null;
        actionTrackingCheck = null;
        actionHint = null;
        smoothRange = null;
        smoothValue = null;
        angleRange = null;
        angleValue = null;
        mmdCache.clear();
        container = null;
        scene = null;
        ctx = null;

        _tmpDir = null;
        _tmpScale = null;
        _tmpQuat = null;
        _tmpTrans = null;
    };

    console.log(TAG, '已注册');
})();